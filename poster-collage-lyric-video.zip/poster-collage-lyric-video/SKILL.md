---
name: poster-collage-lyric-video
description: Make a poster-collage kinetic-typography lyric video from a song and its lyrics. Every lyric line becomes its own editorial poster made of photoreal object cutouts, pushpins, stickers, numbered badges, and a high-contrast serif paired with an ultra-heavy condensed grotesk. Words fly, slam, scatter and run in on their exact sung timestamps. Repeated words (like "Kyu, Kyu, Kyu") stack on ONE slide, never across several. Storyboard page first, then a HyperFrames build at 1440×1080 (4:3), then the MP4. Use whenever someone gives a song or lyrics and asks for a lyric video, a storyboard for a song, "Pinterest / editorial poster style", "cutout collage animation", "the Toxic style", "fast flying type", or shares poster references like these and asks to animate a song in that style.
---

# Poster-collage lyric video

A song becomes a run of 4:3 editorial posters. Each poster is one lyric line: real objects cut out and pinned to paper, the line set in big type, and every word arriving on the beat it is sung. The look comes from Pinterest-style design posters (Inspo Keywords, Gift Guide, AntiCaos, Picco, Alinhamento). `references/style.md` holds the full analysis and the token scale.

Built and approved on "Toxic" by arya (16 shots, 42.4 s). `templates/build.py` is that real build. Copy it and swap in the scenes for the new song.

## Order of work (stop for approval where marked)

1. **Song + lyrics + timings.**
   - Find the audio file and the lyrics; the person usually gives both.
   - Get word-level timestamps:
     - words: `npx hyperframes transcribe <audio>`;
     - beats: `npx hyperframes beats <audio>`;
     - sections: `npx hyperframes audio <audio> --only sections,onsets,moments --json`.
   - Correct the transcript against the lyrics the person gave. Their spelling wins.
   - Write `tools/plan.json` (schema in `templates/plan.example.json`):
     - `shots`: one per lyric line, plus intro and instrumental shots;
     - `captions`: the words, each with its sung time;
     - `beats`.
   - A repeated-word line (Kyu, Kyu, Kyu) is ONE shot, with `hits` set to the time of each word.
   - If the track is longer than the lyrics given, animate the lyric section and say so.
2. **Analyse the references → scale.**
   - If the person gives new reference images, redo the analysis in `references/style.md`: what each reference contributes, then what they all share.
   - Otherwise reuse the existing tokens as they are.
3. **Storyboard first** (`templates/storyboard.html`). STOP for approval.
   - Sections: style analysis, scale, shot timeline, then one frame per shot built at real canvas size, then the asset list.
   - Each frame comes with notes: timecode, lyric, rough English translation, a word-sync beat list and the assets it needs.
   - Serve it from the scratchpad if the app's server can't read `~/Downloads` (see gotchas).
4. **Cutouts.**
   - Generate about 12 props, one per line's image (prompts and costs in `references/cutouts.md`).
   - Strip the white backgrounds with `scripts/cutout.py`.
   - Split moving parts onto their own layers with `scripts/split_layers.py`: flames, two-piece objects, a disc out of its sleeve.
   - Check them on a contact sheet before using them.
5. **Build** (HyperFrames).
   - Read the `/hyperframes` skill first.
   - Make a new project folder (never overwrite an earlier render) and copy `templates/build.py` to `tools/`.
   - Write one `scene(...)` per shot from the storyboard, re-cut for landscape 1440×1080.
   - Run `python3 tools/build.py`. It writes `index.html` plus `compositions/sNN.html` and reads the word times from `plan.json`.
6. **Check → look → fix.**
   - Run `npx hyperframes check --json` and fix every error.
   - Snapshot each scene just before its exit with `snapshot --no-end --at ...`. Then snapshot mid-motion moments too, to check the motion blur and the transitions.
   - Read the contact sheets and fix overlaps; `references/gotchas.md` lists the usual ones.
7. **Render.**
   - Run `npx hyperframes render --output renders/<name>-4x3.mp4`, in the background.
   - Verify with ffprobe: 1440×1080, 30 fps, audio stream present, correct duration.
   - Send the file.

## Hard rules

- **Canvas**: 1440×1080, 4:3 landscape, 30 fps. Margins 72 px; key text stays inside the 80% title-safe box.
- **Repeated words**: all repetitions stay on one slide. Each hit adds its word to the stack: a colour band, a sticker on a pile, or a line in a column. Never cut to a new slide per repetition. If the same line returns later (a chorus), escalate it with a new treatment; don't copy it.
- **Every word lands on its sung time.**
  - A move that must land on a hit starts 40–190 ms early.
  - The hit itself is a 0 ms `tl.set` or a ≤0.2 s `power4.out`.
- **Fast type, never the same twice in a row.** Pick from the technique bank in `references/motion.md` (FLY, SLAM, SCATTER, RUN, drip, slot-machine roll, typewriter, ink-write, breath, ignite flicker, orbit). Give each line a technique that acts out its meaning: "runnin" runs, "around" circles, "saasen" breathes, "aatish" flickers like a struck match.
- **Motion principles**:
  - Arrivals land slowly on a long tail (`expo.out` / `power4.out`). Exits are about half as long and accelerate (`power3.in`).
  - Overlap moves by 30–50%. Stagger words 60–120 ms apart and letters one frame apart.
  - Titles hold still once landed; no floating or breathing loops on type.
  - Props act instead: a clock ticks on the beat, a record spins, a heart beats, a flame flickers.
  - `data-motion-blur="on"` goes on the root.
- **Transitions come from an object on screen.**
  - Use 3–5 kinds: object becomes the world (a clip-path flood from its rectangle), colour flood, whip, iris, zoom through a lens or label, dip cut.
  - At most a third of the seams are hard cuts, and those go on hits only.
- **Design principles**:
  - One loud accent colour per frame, and two type voices only (serif + grotesk), with mono only for frame chrome.
  - Each frame has one hero prop at 50–65% of its height, 1–3 secondary props, and pins or badges as tertiary details.
  - Never cover lyric type with a prop.
  - Hold the last line for at least 2 s before the fade.

## Files

- `references/style.md`: the reference analysis, tokens (palette, type scale, layout, shadows) and per-frame layout patterns.
- `references/motion.md`: motion presets with exact durations and eases, the type-technique bank, the transition recipes, and how each was built in GSAP.
- `references/cutouts.md`: the prop list, prompt template, model and cost, background removal, layer splitting.
- `references/gotchas.md`: every problem hit while building the first one, and its fix.
- `scripts/cutout.py`: white background → transparent PNG (flood fill from the edges, feathered, cropped).
- `scripts/split_layers.py`: split a cutout into layers by colour, by column (tear line) or by a top band (flame).
- `templates/build.py`: the full generator (shared CSS, motion helpers, 16 scene recipes, root composition).
- `templates/storyboard.html`: the approved storyboard page (style analysis, scale, timeline, frames).
- `templates/plan.example.json`: the timing schema.
