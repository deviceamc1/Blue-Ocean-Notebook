# TEMPLATE (the approved "Toxic" build). Copy to <project>/tools/build.py, keep CSS + JS helpers,
# rewrite the scene(...) blocks for the new song. Builds index.html + compositions/sNN.html (1440x1080, 4:3).
# Word times come from tools/plan.json, so every word lands on its sung time.
# Re-run after editing this file:  python3 tools/build.py
import json, os

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
plan = json.load(open(os.path.join(ROOT, "tools/plan.json")))
SHOTS, CAPS = plan["shots"], plan["captions"]
W, H, TOTAL = 1440, 1080, 42.4

# ---------- shared look (tokens from the storyboard scale, re-cut for 1440x1080) ----------
CSS = """
#root{position:absolute;inset:0;overflow:hidden}
#@P@-st{position:absolute;inset:0;overflow:hidden;font-family:'Inter',sans-serif;color:#151311;
  --paper:#F2EDE2;--cream:#F6F1D8;--ink:#151311;--blue:#93B0CB;--cobalt:#2348C8;--signal:#EF5122;--lime:#C9F23F;--khaki:#E6DBB8;--char:#1C1D21}
#@P@-st .a{position:absolute}
#@P@-st .full{position:absolute;left:0;top:0;width:1440px;height:1080px}
#@P@-st .w,#@P@-st .l{display:inline-block;white-space:pre}
#@P@-st .mk{display:inline-block;overflow:hidden;vertical-align:top;padding:0 .04em .1em}
#@P@-st .serif{font-family:'Playfair Display',serif;font-weight:400;letter-spacing:-.03em;line-height:.9;white-space:nowrap}
#@P@-st .it{font-style:italic}
#@P@-st .hv{font-family:'Oswald',sans-serif;font-weight:700;text-transform:uppercase;line-height:.92;letter-spacing:-.005em;white-space:nowrap}
#@P@-st .sans{font-family:'Inter',sans-serif;white-space:nowrap}
#@P@-st .mono{font-family:'JetBrains Mono',monospace;font-weight:600;font-size:16px;letter-spacing:.22em;text-transform:uppercase;white-space:nowrap}
#@P@-st .cut{position:absolute;filter:drop-shadow(0 4px 3px rgba(20,15,10,.2)) drop-shadow(0 22px 26px rgba(20,15,10,.24))}
#@P@-st .cut img{display:block;width:100%;height:100%}
#@P@-st .pin{position:absolute;width:40px;height:40px;border-radius:50%;background:radial-gradient(circle at 35% 30%,#ff8a6a,#EF5122 45%,#8f2208);box-shadow:0 9px 11px rgba(0,0,0,.3)}
#@P@-st .pin.steel{background:radial-gradient(circle at 35% 30%,#f4f4f4,#9a9a9a 50%,#4a4a4a)}
#@P@-st .badge{position:absolute;width:60px;height:60px;border-radius:50%;background:#EF5122;color:#fff;font:700 28px/60px 'Inter',sans-serif;text-align:center;box-shadow:0 6px 10px rgba(0,0,0,.18)}
#@P@-st .pill{position:absolute;border-radius:999px;font:700 40px/1 'Inter',sans-serif;padding:20px 36px;white-space:nowrap}
#@P@-st .note{position:absolute;background:#FBF8EE;box-shadow:0 14px 20px rgba(0,0,0,.2);padding:26px 30px;font-family:'Playfair Display',serif;font-size:50px;line-height:1;white-space:nowrap}
#@P@-st .torn{clip-path:polygon(0 4%,8% 0,17% 3%,27% 0,38% 3%,49% 1%,60% 3%,71% 0,82% 2%,92% 0,100% 3%,100% 100%,0 100%)}
#@P@-st .mat{background-color:#EF5122;background-image:linear-gradient(rgba(255,255,255,.28) 2px,transparent 2px),linear-gradient(90deg,rgba(255,255,255,.28) 2px,transparent 2px);background-size:36px 36px}
#@P@-st .check{position:absolute;background:repeating-conic-gradient(#151311 0 25%,#fff 0 50%) 0 0/64px 64px}
#@P@-st .stripes{background-color:#F1F0EE;background-image:linear-gradient(90deg,#E4E2DE 2px,transparent 2px);background-size:96px 100%;background-position:48px 0}
#@P@-st .halftone{background-image:radial-gradient(rgba(0,0,0,.32) 1.2px,transparent 1.6px);background-size:8px 8px}
#@P@-st .grain{position:absolute;left:0;top:0;width:1440px;height:1080px;pointer-events:none;opacity:.16;mix-blend-mode:multiply;z-index:90;
  background-image:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='220' height='220'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='.9' numOctaves='2' seed='4'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23n)'/%3E%3C/svg%3E")}
#@P@-st .hdr{position:absolute;left:72px;right:72px;top:46px;display:flex;align-items:center;gap:18px;justify-content:center}
#@P@-st .hdr i{flex:1;height:1.5px;background:currentColor;opacity:.55;display:block}
#@P@-st .ftr{position:absolute;left:72px;right:72px;bottom:40px;display:flex;justify-content:space-between}
"""

# ---------- motion vocabulary (every scene uses only these) ----------
JS = """
const tl = gsap.timeline({ paused: true });
let _s = @SEED@;
const rnd = () => (_s = (_s * 16807) % 2147483647) / 2147483647;
const Q = (s) => gsap.utils.toArray(s);
const T = @T@;
// FLY: word thrown in from far off-frame on a seeded heading, spinning, lands on a long tail
const FLY = (el, t, o = {}) => { const a = o.a ?? rnd() * 6.283, d = o.d ?? 1500;
  tl.fromTo(el, { x: Math.cos(a) * d, y: Math.sin(a) * d * 0.7, rotation: o.r0 ?? (rnd() - 0.5) * 90, scale: o.s0 ?? 1.7, opacity: 0 },
    { x: 0, y: 0, rotation: o.r ?? 0, scale: 1, opacity: 1, duration: o.dur ?? 0.34, ease: o.ease ?? "expo.out" }, t - (o.lead ?? 0.1)); };
// SLAM: arrives huge and hits the page
const SLAM = (el, t, o = {}) => tl.fromTo(el, { scale: o.s0 ?? 3.2, opacity: 0, rotation: o.r0 ?? 0 },
    { scale: 1, opacity: 1, rotation: o.r ?? 0, duration: o.dur ?? 0.2, ease: "power4.out" }, t - 0.06);
// RISE: up from a baseline mask
const RISE = (el, t, o = {}) => tl.fromTo(el, { yPercent: o.y0 ?? 118 }, { yPercent: 0, duration: o.dur ?? 0.26, ease: "power4.out" }, t - 0.07);
// BLUR: blur-in in place
const BLUR = (el, t, o = {}) => tl.fromTo(el, { opacity: 0, filter: "blur(10px)" }, { opacity: 1, filter: "blur(0px)", duration: o.dur ?? 0.15, ease: "power2.out" }, t - 0.03);
// INK: grey -> ink colour, no movement
const INK = (el, t, c = "#151311") => tl.fromTo(el, { color: "rgba(21,19,17,.16)" }, { color: c, duration: 0.12, ease: "none" }, t);
// SCATTER: letters gather from all over the frame, one frame apart
const SCATTER = (els, t, o = {}) => Q(els).forEach((e, i) => tl.fromTo(e,
    { x: (rnd() - 0.5) * (o.w ?? 1500), y: (rnd() - 0.5) * (o.h ?? 1100), rotation: (rnd() - 0.5) * 260, scale: o.s0 ?? 0.35, opacity: 0 },
    { x: 0, y: 0, rotation: 0, scale: 1, opacity: 1, duration: o.dur ?? 0.42, ease: "expo.out" }, t - 0.14 + i * (o.st ?? 0.033)));
// RUN: letters streak in from one side, a frame apart
const RUN = (els, t, o = {}) => Q(els).forEach((e, i) => tl.fromTo(e, { x: o.x0 ?? -1300, opacity: 0 },
    { x: 0, opacity: 1, duration: o.dur ?? 0.3, ease: "expo.out" }, t - 0.1 + i * (o.st ?? 0.033)));
// TYPE: characters appear one by one (typewriter)
const TYPE = (els, t, rate = 0.03) => Q(els).forEach((e, i) => tl.fromTo(e, { opacity: 0 }, { opacity: 1, duration: 0.001 }, t + i * rate));
// DROP: a prop lands on the desk and settles
const DROP = (el, t, o = {}) => tl.fromTo(el, { x: o.x0 ?? 0, y: o.y0 ?? -900, rotation: (o.r ?? 0) + (o.dr ?? 16), scale: o.s0 ?? 1.08 },
    { x: 0, y: 0, rotation: o.r ?? 0, scale: 1, duration: o.dur ?? 0.55, ease: o.ease ?? "back.out(1.25)" }, t - 0.12);
// POP: pins, badges, stickers
const POP = (el, t, o = {}) => tl.fromTo(el, { scale: 0, rotation: o.r0 ?? -24 }, { scale: 1, rotation: o.r ?? 0, duration: o.dur ?? 0.22, ease: o.ease ?? "back.out(3)" }, t - 0.04);
// WIPE: highlight block grows behind a word
const WIPE = (el, t, o = {}) => tl.fromTo(el, { scaleX: 0 }, { scaleX: 1, duration: o.dur ?? 0.24, ease: "power3.inOut", transformOrigin: o.from ?? "0% 50%" }, t);
// DRAW: a stroke draws on (pathLength=100)
const DRAW = (el, t, dur = 0.32) => tl.fromTo(el, { strokeDashoffset: 110 }, { strokeDashoffset: 0, duration: dur, ease: "power2.inOut" }, t);
// SHAKE: the page reacts to a hit (one per scene element)
const SHAKE = (el, t, a = 10) => tl.fromTo(el, { x: 0, y: 0 }, { keyframes: [{ x: a, y: -a * 0.6, duration: 0.03 }, { x: -a * 0.7, y: a * 0.5, duration: 0.03 }, { x: a * 0.35, y: -a * 0.2, duration: 0.03 }, { x: 0, y: 0, duration: 0.04 }] }, t);
// OUT: everything leaves in one motion (exits are ~half the entrance)
const OUT = (els, t, o = {}) => tl.to(els, { x: o.x ?? 0, y: o.y ?? 0, rotation: o.r ?? 0, scale: o.s ?? 1, opacity: o.o ?? 0, duration: o.dur ?? 0.18, ease: o.ease ?? "power3.in", stagger: o.st ?? 0.012 }, t);
// FLOOD: a coloured layer grows from a rectangle to the full frame (object becomes the world)
const FLOOD = (el, t, from, o = {}) => tl.fromTo(el, { clipPath: from }, { clipPath: "inset(0px 0px 0px 0px)", duration: o.dur ?? 0.42, ease: o.ease ?? "power3.in" }, t);
// UNFLOOD: the arriving scene's ground recedes from full frame to reveal what is under it
const UNFLOOD = (el, t, to, o = {}) => tl.fromTo(el, { clipPath: "inset(0px 0px 0px 0px)" }, { clipPath: to, duration: o.dur ?? 0.4, ease: o.ease ?? "power3.out" }, t);
"""

def w(P, k, text, cls=""):
    return f'<span class="w {cls}" id="{P}-{k}">{text}</span>'

def mk(P, k, text, cls=""):
    return f'<span class="mk"><span class="w {cls}" id="{P}-{k}">{text}</span></span>'

def ls(P, k, text, cls=""):
    """one span per letter, selectable as .{P}-{k}"""
    out = []
    for c in text:
        c = "&nbsp;" if c == " " else c
        out.append(f'<span class="l {P}-{k} {cls}">{c}</span>')
    return "".join(out)

def cut(P, k, img, x, y, wpx, hpx, z=5, extra=""):
    return (f'<div class="cut" id="{P}-{k}" style="left:{x}px;top:{y}px;width:{wpx}px;height:{hpx}px;z-index:{z};{extra}">'
            f'<img src="assets/img/{img}" alt=""></div>')

def chrome(P, top, l, m, r, color="#151311"):
    return (f'<div class="hdr mono" data-layout-ignore id="{P}-hdr" style="color:{color};z-index:40"><i></i><span>{top}</span><i></i></div>'
            f'<div class="ftr mono" data-layout-ignore id="{P}-ftr" style="color:{color};z-index:40"><span>{l}</span><span>{m}</span><span>{r}</span></div>')

SCENES = []
def scene(idx, html, js, seed, cap=None):
    s = SHOTS[idx]
    times = []
    if cap is not None:
        times = [round(t - s["start"], 3) for _, t in CAPS[cap]["words"]]
    SCENES.append(dict(P=f"s{idx+1:02d}", start=s["start"], dur=round(s["end"] - s["start"], 3),
                       html=html, js=js, seed=seed, T=times, hits=[round(h - s["start"], 3) for h in s.get("hits", [])]))

# =====================================================================================
# S01 INTRO 0-5.22  — title poster
P = "s01"
scene(0, f"""
<div class="full" style="background:var(--paper)"></div>
{chrome(P, "arya · side a · 01", "arya", "toxic — the lyric video", "2026")}
<div class="a serif it" id="{P}-kick" style="left:124px;top:150px;font-size:60px;z-index:6">{w(P,'k0','a ')}{w(P,'k1','love ')}{w(P,'k2','song, ')}{w(P,'k3','labelled')}</div>
<div class="a" id="{P}-hl" style="left:104px;top:262px;width:812px;height:262px;background:var(--lime);z-index:4"></div>
<div class="a hv" style="left:120px;top:236px;font-size:300px;z-index:6;letter-spacing:.01em">{ls(P,'t','TOXIC')}</div>
<div class="a sans" id="{P}-tag" style="left:124px;top:590px;font-size:34px;font-weight:700;z-index:6">{w(P,'g0','Handle ')}{w(P,'g1','with ')}{w(P,'g2','care. ')}{w(P,'g3','Contents ')}{w(P,'g4','may ')}{w(P,'g5','burn.')}</div>
<div class="a mono" data-layout-ignore id="{P}-cta" style="left:124px;top:860px;width:520px;height:58px;line-height:54px;text-align:center;border:2px solid #151311;z-index:6">save for your next heartbreak</div>
<div class="a mat" id="{P}-mat" style="left:930px;top:300px;width:420px;height:600px;border-radius:60px 0 0 0;z-index:3"></div>
<div class="a" id="{P}-bottle" style="left:1010px;top:250px;width:262px;height:622px;z-index:5">
  <div class="cut" style="left:0;top:0;width:262px;height:622px"><img src="assets/img/poison.png" alt=""></div>
  <div class="a serif" style="left:0;right:0;top:330px;text-align:center;font-size:46px">Toxic<div class="mono" data-layout-ignore style="font-size:12px;margin-top:8px">no. 01</div></div>
</div>
<div class="pin" id="{P}-pin" style="left:1121px;top:250px;z-index:7"></div>
<div class="cut" id="{P}-wine" style="left:830px;top:700px;width:170px;height:395px;z-index:2;opacity:.9"><img src="assets/img/wine.png" alt="" style="filter:blur(5px)"></div>
<div class="cut" id="{P}-clock" style="left:1250px;top:60px;width:190px;height:270px;z-index:2"><img src="assets/img/clock.png" alt="" style="filter:blur(5px)"></div>
<div class="check" id="{P}-chk" style="left:1290px;top:930px;width:200px;height:200px;z-index:2"></div>
<div class="a" id="{P}-flood" style="left:0;top:0;width:1440px;height:1080px;background:var(--lime);z-index:80;clip-path:inset(262px 524px 556px 104px)"></div>
""", """
tl.fromTo("#@P@-hdr i", { scaleX: 0 }, { scaleX: 1, duration: 0.5, ease: "expo.out" }, 0.04);
tl.fromTo("#@P@-ftr", { opacity: 0 }, { opacity: 1, duration: 0.3 }, 0.1);
SCATTER(".@P@-t", 0.3, { st: 0.04, dur: 0.5 });
WIPE("#@P@-hl", 0.71);
tl.fromTo("#@P@-flood", { opacity: 0 }, { opacity: 0, duration: 0.01 }, 0);
["#@P@-k0","#@P@-k1","#@P@-k2","#@P@-k3"].forEach((s, i) => BLUR(s, 1.28 + i * 0.067));
tl.fromTo("#@P@-mat", { x: 620 }, { x: 0, duration: 0.6, ease: "expo.out" }, 1.25);
DROP("#@P@-bottle", 1.91, { r: -6, dr: 22 });
POP("#@P@-pin", 2.54);
tl.to("#@P@-bottle", { keyframes: [{ rotation: -8, duration: 0.06 }, { rotation: -6, duration: 0.2, ease: "back.out(3)" }] }, 2.56);
tl.fromTo("#@P@-wine", { x: -500 }, { x: 0, duration: 0.8, ease: "power3.out" }, 3.2);
tl.fromTo("#@P@-clock", { y: -400 }, { y: 0, duration: 0.8, ease: "power3.out" }, 3.3);
tl.fromTo("#@P@-chk", { x: 300, rotation: 30 }, { x: 0, rotation: -8, duration: 0.7, ease: "power3.out" }, 3.4);
["#@P@-g0","#@P@-g1","#@P@-g2","#@P@-g3","#@P@-g4","#@P@-g5"].forEach((s, i) => INK(s, 3.96 + i * 0.08));
tl.fromTo("#@P@-cta", { clipPath: "inset(0px 520px 0px 0px)" }, { clipPath: "inset(0px 0px 0px 0px)", duration: 0.4, ease: "power3.inOut" }, 4.2);
// exit: the lime label swallows the frame -> next scene starts lime
tl.set("#@P@-flood", { opacity: 1 }, 4.76);
FLOOD("#@P@-flood", 4.76, "inset(262px 524px 556px 104px)", { dur: 0.44 });
""", 11, cap=0)

# =====================================================================================
# S02 HOUR 5.22-10.4 — numbered night objects around a clock (instrumental)
P = "s02"
B = [round(b - 5.22, 2) for b in plan["beats"] if 5.22 <= b < 10.4]   # local beats
scene(1, f"""
<div class="full stripes"></div>
{chrome(P, "before the first line", "02", "objects of the night", "5.22")}
<div class="a hv" style="left:120px;top:110px;font-size:120px;color:var(--signal);z-index:6;line-height:.9">{w(P,'h0','THE')} {w(P,'h1','HOUR')}<br>{w(P,'h2','BEFORE')}</div>
{cut(P,'candle','candle.png',190,470,64,400)}
{cut(P,'quill','quill.png',330,610,214,300)}
<div class="a" id="{P}-clock" style="left:540px;top:240px;width:365px;height:518px;z-index:6">
  <div class="cut" style="left:0;top:0;width:365px;height:518px"><img src="assets/img/clock.png" alt=""></div>
  <div class="a" id="{P}-hand" style="left:181px;top:174px;width:3px;height:118px;background:#C0392B;border-radius:2px;transform-origin:50% 100%"></div>
</div>
{cut(P,'wine','wine.png',990,130,121,280)}
<div class="cut" id="{P}-vinyl" style="left:1130px;top:250px;width:230px;height:177px;z-index:5"><img src="assets/img/vinyl.png" alt=""></div>
<svg class="a" style="left:0;top:0;z-index:4" width="1440" height="1080" fill="none">
  <defs>{"".join(f'<mask id="{P}-m{i}"><path id="{P}-mp{i}" d="{d}" stroke="#fff" stroke-width="8" pathLength="100" stroke-dasharray="100 120" stroke-dashoffset="110"/></mask>' for i,d in enumerate(["M180 430 C 150 380, 200 330, 250 360 L 226 470","M470 590 C 520 560, 500 640, 440 660","M980 120 C 940 80, 900 140, 1010 180","M1330 180 C 1360 220, 1320 250, 1260 260"]))}</defs>
  {"".join(f'<path d="{d}" stroke="#EF5122" stroke-width="3" stroke-dasharray="8 9" mask="url(#{P}-m{i})"/>' for i,d in enumerate(["M180 430 C 150 380, 200 330, 250 360 L 226 470","M470 590 C 520 560, 500 640, 440 660","M980 120 C 940 80, 900 140, 1010 180","M1330 180 C 1360 220, 1320 250, 1260 260"]))}
</svg>
<div class="badge" id="{P}-b1" style="left:150px;top:400px;z-index:7">1</div>
<div class="badge" id="{P}-b2" style="left:450px;top:560px;z-index:7">2</div>
<div class="badge" id="{P}-b3" style="left:930px;top:90px;z-index:7">3</div>
<div class="badge" id="{P}-b4" style="left:1310px;top:150px;z-index:7">4</div>
<div class="a serif" style="left:990px;top:560px;font-size:170px;z-index:6">{mk(P,'r0','Raat')}</div>
<div class="a serif it" style="left:1040px;top:710px;font-size:170px;color:var(--signal);z-index:6">{w(P,'r1','bhar')}</div>
<div class="a sans" id="{P}-rest" style="left:1050px;top:900px;font-size:30px;color:#9A948A;z-index:6">for the restless</div>
<div class="pill" id="{P}-pill" style="left:560px;top:850px;background:#2B2A1E;color:#fff;font-size:34px;padding:18px 34px;z-index:7">Kaafi hai tu <span class="w" id="{P}-arr">→</span></div>
<div class="a" id="{P}-lime" style="left:0;top:0;width:1440px;height:1080px;background:var(--lime);z-index:80"></div>
""", """
const B = @B@;
UNFLOOD("#@P@-lime", 0, "inset(0px 0px 1080px 0px)", { dur: 0.42, ease: "power2.inOut" });
FLY("#@P@-h0", 0.16, { a: Math.PI, d: 1200, r0: 0, s0: 1 }); FLY("#@P@-h1", 0.24, { a: Math.PI, d: 1200, r0: 0, s0: 1 }); FLY("#@P@-h2", 0.34, { a: Math.PI, d: 1200, r0: 0, s0: 1 });
DROP("#@P@-clock", B[1], { r: -4 });
B.forEach((b, i) => { if (i >= 1) tl.set("#@P@-hand", { rotation: 30 * i }, b); });
const items = ["#@P@-candle", "#@P@-quill", "#@P@-wine", "#@P@-vinyl"], rots = [-8, -14, 8, 10];
items.forEach((s, i) => { const t = B[2 + i]; POP("#@P@-b" + (i + 1), t); DROP(s, t, { r: rots[i], y0: -700, dur: 0.45 }); DRAW("#@P@-mp" + i, t + 0.08, 0.3); });
RISE("#@P@-r0", B[5]);
FLY("#@P@-r1", B[5] + 0.24, { a: 0, d: 900, r0: 20 });
BLUR("#@P@-rest", B[5] + 0.45);
POP("#@P@-pill", B[6], { r0: 0, ease: "back.out(2)" });
tl.to("#@P@-arr", { keyframes: [{ x: 14, duration: 0.12, ease: "power2.out" }, { x: 0, duration: 0.2, ease: "power2.inOut" }] }, B[8] - 0.12);
// exit: whip up
OUT(["#@P@-h0","#@P@-h1","#@P@-h2","#@P@-r0","#@P@-r1","#@P@-rest","#@P@-pill","#@P@-candle","#@P@-quill","#@P@-clock","#@P@-wine","#@P@-vinyl","#@P@-b1","#@P@-b2","#@P@-b3","#@P@-b4"], 4.98, { y: -520, st: 0.006 });
""".replace("@B@", json.dumps(B)), 23)

# =====================================================================================
# S03 LINE 1 10.4-12.82 — "Kaafi hai tu mujhko thaamne ko" (dusty blue, the hand)
P = "s03"
scene(2, f"""
<div class="full" style="background:#6F8FB0"></div>
<div class="a sans" id="{P}-menu" data-layout-ignore style="left:0;right:0;top:40px;text-align:center;font-size:20px;color:#1E2733;word-spacing:22px;z-index:40"><b style="color:#fff"> Toxic</b> Kaafi Thaam Dil Raat Saans Help</div>
<div class="ftr mono" data-layout-ignore style="color:rgba(255,255,255,.75);z-index:40"><span>@arya</span><span>toxic · 1/14</span><span>@arya</span></div>
<div class="a serif" style="left:120px;top:140px;font-size:270px;color:var(--cream);z-index:5">{ls(P,'k','Kaafi')}</div>
<div class="a sans" style="left:760px;top:150px;font-size:44px;font-weight:700;color:#fff;letter-spacing:.06em;z-index:6">{ls(P,'m','MUJHKO')}</div>
<div class="a serif it" style="left:720px;top:250px;font-size:180px;color:#2A1A14;z-index:6">{w(P,'w1','hai ')}{w(P,'w2','tu')}</div>
<div class="a" id="{P}-num" style="left:124px;top:560px;font:800 120px/0.9 'Inter',sans-serif;color:#2A1A14;z-index:6">1<div style="font-size:44px;font-weight:600;color:var(--cream)">/14</div></div>
{cut(P,'hand','hand.png',640,440,700,700,4)}
<div class="note torn" id="{P}-note" style="left:880px;top:560px;z-index:6">{w(P,'n0','thaamne ')}<i style="color:var(--cobalt)">{w(P,'n1','ko.')}</i></div>
<div class="pin steel" id="{P}-pin" style="left:1040px;top:556px;z-index:7"></div>
<div class="a" id="{P}-flood" style="left:0;top:0;width:1440px;height:1080px;background:var(--cream);z-index:80;opacity:0"></div>
""", """
tl.fromTo("#@P@-st", { y: 360 }, { y: 0, duration: 0.32, ease: "expo.out" }, 0);
// Kaafi: letters fall from above, a frame apart, and land hard
Q(".@P@-k").forEach((e, i) => tl.fromTo(e, { y: -900, rotation: (i % 2 ? 18 : -18), opacity: 0 }, { y: 0, rotation: 0, opacity: 1, duration: 0.34, ease: "expo.out" }, T[0] - 0.12 + i * 0.033));
FLY("#@P@-w1", T[1], { a: 0, d: 1100 }); FLY("#@P@-w2", T[2], { a: -0.4, d: 1100 });
TYPE(".@P@-m", T[3] - 0.04, 0.035);
tl.fromTo("#@P@-num", { opacity: 0, x: -60 }, { opacity: 1, x: 0, duration: 0.3, ease: "expo.out" }, T[3]);
tl.fromTo("#@P@-hand", { y: 700, rotation: 8 }, { y: 0, rotation: -3, duration: 0.6, ease: "expo.out" }, T[4] - 0.3);
tl.fromTo("#@P@-note", { x: 700, y: -500, rotation: 50 }, { x: 0, y: 0, rotation: 5, duration: 0.36, ease: "expo.out" }, T[4] - 0.1);
SLAM("#@P@-n1", T[5], { s0: 2 });
POP("#@P@-pin", T[5] + 0.1);
// exit: the note becomes the next page
tl.set("#@P@-flood", { opacity: 1 }, 1.98);
FLOOD("#@P@-flood", 1.98, "inset(556px 140px 400px 880px)", { dur: 0.44 });
""", 37, cap=1)

# =====================================================================================
# S04 LINE 2 12.82-15.66 — "Bin piye mujhe sharaab ka libaas naa do" (cream, wine glass)
P = "s04"
scene(3, f"""
<div class="full" style="background:var(--cream)"></div>
<div class="ftr mono" data-layout-ignore style="z-index:40"><span>arya.music</span><span>toxic · 2/14</span><span>@arya</span></div>
<div class="a serif" style="left:120px;top:96px;font-size:150px;line-height:.86;z-index:6">
  {w(P,'w0','Bin ')}{w(P,'w1','piye')}<br>{w(P,'w2','mujhe')}<br><span class="w it" id="{P}-w3" style="color:#7A1420">sharaab</span>{w(P,'w4',' ka')}<br>{w(P,'w5','libaas')}<br>{w(P,'w6','naa ')}{w(P,'w7','do.')}
</div>
<div class="a halftone" id="{P}-shadow" style="left:930px;top:900px;width:330px;height:56px;border-radius:50%;opacity:.5;z-index:3"></div>
<div class="cut" id="{P}-wine" style="left:960px;top:150px;width:330px;height:766px;z-index:5"><img src="assets/img/wine.png" alt=""></div>
<div class="a sans" id="{P}-tr" style="left:124px;top:916px;font-size:30px;z-index:6">{w(P,'t0',"Don't ")}{w(P,'t1','dress ')}{w(P,'t2','me ')}{w(P,'t3','in ')}{w(P,'t4',"wine.")}</div>
""", """
const words = ["w0","w1","w2","w3","w4","w5","w6","w7"];
words.forEach((k, i) => { if (k === "w3" || k === "w7") return; FLY("#@P@-" + k, T[i], { d: 1600, dur: 0.32 }); });
SLAM("#@P@-w7", T[7], { s0: 2.4, dur: 0.12 });
SLAM("#@P@-w3", T[3], { s0: 3.4, r0: -12 });
SHAKE("#@P@-st", T[3] + 0.08, 12);
// the glass swings in on its stem like a pendulum and settles at a tilt
tl.fromTo("#@P@-wine", { rotation: 70, x: 500, y: -200 }, { rotation: 16, x: 0, y: 0, duration: 0.9, ease: "elastic.out(1, 0.55)", transformOrigin: "50% 100%" }, T[3] - 0.16);
tl.fromTo("#@P@-shadow", { scaleX: 0.2, opacity: 0 }, { scaleX: 1, opacity: 0.5, duration: 0.5, ease: "power3.out" }, T[3]);
["t0","t1","t2","t3","t4"].forEach((k, i) => INK("#@P@-" + k, T[1] + 0.1 + i * 0.07));
// exit: whip right
OUT(Q("#@P@-st .w, #@P@-wine, #@P@-shadow"), 2.7, { x: 900, st: 0.004, dur: 0.16 });
""", 41, cap=2)

# =====================================================================================
# S05 LINE 3 15.66-17.95 — "Tumhare din savere raat ke musaafiro ko" (split day/night)
P = "s05"
scene(4, f"""
<div class="a" id="{P}-day" style="left:0;top:0;width:720px;height:1080px;background:var(--signal);z-index:1"></div>
<div class="a" id="{P}-night" style="left:720px;top:0;width:720px;height:1080px;background:var(--cobalt);z-index:1"></div>
{chrome(P, "", "06:00", "day ⇄ night · 3/14", "23:59", "#fff")}
<div class="a mono" data-layout-ignore style="left:0;right:0;top:46px;text-align:center;color:#fff;z-index:40;font-size:18px">{ls(P,'tu','TUMHARE')}</div>
<div class="a hv" id="{P}-din" style="left:120px;top:120px;font-size:250px;color:var(--cream);z-index:6">DIN</div>
<div class="a hv" style="left:124px;top:380px;font-size:130px;color:var(--ink);z-index:6">{ls(P,'sv','SAVERE')}</div>
<div class="a hv" id="{P}-raat" style="left:880px;top:120px;font-size:250px;color:var(--cream);z-index:6">RAAT</div>
<div class="a serif it" style="left:860px;top:390px;font-size:96px;color:var(--lime);z-index:6;line-height:1">{w(P,'m0','ke ')}{w(P,'m1','musaafiro')}<br>{w(P,'m2','ko')}</div>
{cut(P,'sun','sun.png',140,600,400,417,5)}
{cut(P,'moon','moon.png',1000,560,300,455,5)}
<div class="a" id="{P}-iris" style="left:0;top:0;width:1440px;height:1080px;background:var(--char);z-index:85;clip-path:circle(0px at 1150px 790px)"></div>
""", """
tl.fromTo("#@P@-day", { x: -720 }, { x: 0, duration: 0.34, ease: "expo.out" }, 0);
tl.fromTo("#@P@-night", { x: 720 }, { x: 0, duration: 0.34, ease: "expo.out" }, 0);
TYPE(".@P@-tu", T[0], 0.035);
SLAM("#@P@-din", T[1], { s0: 3.6 });
tl.fromTo("#@P@-sun", { y: 700, rotation: -40 }, { y: 0, rotation: 0, duration: 0.6, ease: "expo.out" }, T[1] - 0.1);
tl.to("#@P@-sun", { rotation: 40, duration: 1.6, ease: "none" }, T[1] + 0.5);
SCATTER(".@P@-sv", T[2], { st: 0.03, dur: 0.36 });
SLAM("#@P@-raat", T[3], { s0: 3.6 });
SHAKE("#@P@-night", T[3] + 0.05, 8);
tl.fromTo("#@P@-moon", { y: -900, rotation: -60 }, { y: 0, rotation: -10, duration: 0.7, ease: "back.out(1.4)", transformOrigin: "50% 0%" }, T[3] - 0.1);
FLY("#@P@-m0", T[4], { a: 0.2, d: 900 }); FLY("#@P@-m1", T[5], { a: -0.3, d: 1000 }); FLY("#@P@-m2", T[6], { a: 1.5, d: 900, dur: 0.24 });
// exit: iris closes onto the moon -> charcoal
tl.fromTo("#@P@-iris", { clipPath: "circle(0px at 1150px 790px)" }, { clipPath: "circle(1500px at 1150px 790px)", duration: 0.2, ease: "power3.in", immediateRender: false }, 2.09);
""", 53, cap=3)

# =====================================================================================
# S06 LINE 4 17.95-20.6 — "Kya farak pade yeh saasen unki hi aazma lo" (torn sheet, candle)
P = "s06"
scene(5, f"""
<div class="full" style="background:var(--char)"></div>
<div class="ftr mono" data-layout-ignore style="color:rgba(255,255,255,.5);z-index:40"><span>4/14 — arya</span><span>4/14 — arya</span><span>4/14 — arya</span></div>
<div class="a torn" id="{P}-sheet" style="left:110px;top:90px;width:1220px;height:900px;background:#F7F4EC;box-shadow:0 30px 40px rgba(0,0,0,.4);z-index:2"></div>
<div class="a" id="{P}-txt" style="left:0;top:0;width:1440px;height:1080px;z-index:6">
  <div class="a sans" style="left:200px;top:170px;font-size:44px;font-weight:300;letter-spacing:-.01em">{w(P,'w0','KYA ')}<span class="mk" style="height:52px;vertical-align:-10px;padding:0"><span class="w" id="{P}-slot" style="display:block;font-weight:800;line-height:52px">FARQ<br>FARK<br>FURAK<br>FARAK</span></span>{w(P,'w2',' PADE')}</div>
  <div class="a serif" style="left:190px;top:250px;font-size:160px">{w(P,'w3','yeh')}</div>
  <div class="a serif it" style="left:440px;top:290px;font-size:210px">{ls(P,'sa','saasen')}</div>
  <div class="pill" id="{P}-pill" style="left:200px;top:640px;background:var(--cobalt);color:#fff;border-radius:999px 999px 999px 10px">{w(P,'p0','unki')}{w(P,'p1',' hi')}</div>
  <div class="a serif" style="left:620px;top:610px;font-size:140px;line-height:.92">{w(P,'w7','aazma')}<br><i>{w(P,'w8','lo.')}</i></div>
</div>
<div class="a" id="{P}-candle" style="left:1100px;top:270px;width:115px;height:720px;z-index:5">
  <div class="cut" style="left:0;top:127px;width:115px;height:593px"><img src="assets/img/candle-body.png" alt=""></div>
  <div class="a" id="{P}-flame" style="left:23px;top:0;width:69px;height:127px"><img src="assets/img/flame.png" alt="" style="display:block;width:100%;height:100%"></div>
</div>
<div class="a" id="{P}-glow" style="left:1007px;top:160px;width:300px;height:300px;border-radius:50%;background:radial-gradient(circle,rgba(255,190,90,.42),rgba(255,190,90,0) 65%);z-index:4"></div>
<div class="a" id="{P}-dip" style="left:0;top:0;width:1440px;height:1080px;background:#000;opacity:0;z-index:90"></div>
""", """
tl.fromTo("#@P@-sheet", { y: 1000, rotation: 4 }, { y: 0, rotation: 0, duration: 0.42, ease: "expo.out" }, 0);
tl.fromTo("#@P@-candle", { y: 900 }, { y: 0, duration: 0.5, ease: "expo.out" }, 0.08);
FLY("#@P@-w0", T[0], { a: Math.PI, d: 900, r0: 0, s0: 1 });
// FARAK rolls like a slot machine and stops on the right spelling
tl.fromTo("#@P@-slot", { y: 0 }, { y: -156, duration: 0.3, ease: "power2.out" }, T[1] - 0.05);
FLY("#@P@-w2", T[2], { a: 0, d: 900, r0: 0, s0: 1 });
RISE("#@P@-w3", T[3]);
// saasen: each letter inhales (pops big) then exhales to size — a breath across the word
Q(".@P@-sa").forEach((e, i) => tl.fromTo(e, { scale: 0, opacity: 0, y: 40 }, { keyframes: [{ scale: 1.35, opacity: 1, y: -12, duration: 0.14, ease: "power3.out" }, { scale: 1, y: 0, duration: 0.3, ease: "power2.inOut" }] }, T[4] - 0.08 + i * 0.05));
tl.fromTo("#@P@-flame", { scaleY: 1, scaleX: 1 }, { scaleY: 1.3, scaleX: 0.85, duration: 0.3, ease: "power2.inOut", yoyo: true, repeat: 3, transformOrigin: "50% 100%" }, T[4]);
POP("#@P@-pill", T[5], { r0: -10, ease: "back.out(2)" });
tl.fromTo("#@P@-p1", { opacity: 0, x: 30 }, { opacity: 1, x: 0, duration: 0.18, ease: "expo.out" }, T[6] - 0.04);
FLY("#@P@-w7", T[7], { a: 1.6, d: 900 });
SLAM("#@P@-w8", T[8], { s0: 3 });
// the flame goes out on "lo", then a dip cut into the Kyu hits
tl.to("#@P@-flame", { scale: 0, opacity: 0, duration: 0.12, ease: "power3.in", transformOrigin: "50% 100%" }, 2.5);
tl.to("#@P@-glow", { opacity: 0, duration: 0.12 }, 2.5);
tl.set("#@P@-dip", { opacity: 0.42 }, 2.55);
""", 67, cap=4)

# =====================================================================================
# S07 KYU KYU KYU 20.6-21.82 — ONE slide: the three Kyu's stack up on each hit
P = "s07"
KY = f"""
<div class="full" style="background:var(--paper)"></div>
{chrome(P, "why × 3", "5/14", "kyu kyu kyu", "arya")}
<div class="a" id="{P}-b0" style="left:0;top:0;width:1440px;height:360px;background:var(--lime);z-index:2"></div>
<div class="a" id="{P}-b1" style="left:0;top:360px;width:1440px;height:360px;background:var(--signal);z-index:2"></div>
<div class="a" id="{P}-b2" style="left:0;top:720px;width:1440px;height:360px;background:var(--cobalt);z-index:2"></div>
<div class="a hv" id="{P}-k0" style="left:150px;top:30px;font-size:300px;z-index:6">KYU,</div>
<div class="a hv" id="{P}-k1" style="left:520px;top:390px;font-size:300px;color:var(--cream);z-index:6">KYU,</div>
<div class="a hv" id="{P}-k2" style="left:890px;top:750px;font-size:300px;color:var(--lime);z-index:6">KYU</div>
<div class="badge" id="{P}-n0" style="left:1240px;top:150px;background:var(--ink);z-index:7">1</div>
<div class="badge" id="{P}-n1" style="left:150px;top:510px;background:var(--ink);z-index:7">2</div>
<div class="badge" id="{P}-n2" style="left:150px;top:870px;background:var(--signal);z-index:7">3</div>
"""
scene(6, KY, """
const H = @H@;
// each hit: its band slams in from the side it reads from, the word punches in on top (stacked, never cut away)
H.forEach((h, i) => {
  tl.fromTo("#@P@-b" + i, { scaleX: 0 }, { scaleX: 1, duration: 0.09, ease: "power4.out", transformOrigin: i === 1 ? "100% 50%" : "0% 50%" }, h - 0.06);
  tl.fromTo("#@P@-k" + i, { scale: 2.6, opacity: 0, rotation: [-6, 5, -3][i] * 3 }, { scale: 1, opacity: 1, rotation: [-3, 2, -1][i], duration: 0.16, ease: "power4.out" }, h - 0.04);
  POP("#@P@-n" + i, h + 0.05);
  SHAKE("#@P@-st", h + 0.02, 10 + i * 4);
});
// exit: the bands whip off left one after another, leaving bare paper for the next poster
OUT(["#@P@-k0","#@P@-b0","#@P@-n0","#@P@-k1","#@P@-b1","#@P@-n1","#@P@-k2","#@P@-b2","#@P@-n2"], 1.04, { x: -1500, st: 0.015, dur: 0.15, o: 1 });
""", 71)

# =====================================================================================
# S08 LINE 6 21.82-23.25 — "Tu phirbhi banti toxic" (poison bottle)
P = "s08"
scene(7, f"""
<div class="full" style="background:var(--paper)"></div>
{chrome(P, "6/14 · the chorus", "dose: one", "do not swallow", "keep away")}
<div class="a hv" style="left:120px;top:130px;font-size:120px;z-index:6">{w(P,'w0','TU ')}{w(P,'w1','PHIRBHI ')}{w(P,'w2','BANTI')}</div>
<div class="a" id="{P}-hl" style="left:104px;top:300px;width:850px;height:290px;background:var(--lime);z-index:4"></div>
<div class="a hv" style="left:118px;top:270px;font-size:330px;z-index:6;letter-spacing:.01em">{ls(P,'t','TOXIC')}</div>
<div class="a" id="{P}-bottle" style="left:1060px;top:250px;width:262px;height:622px;z-index:5">
  <div class="cut" style="left:0;top:0;width:262px;height:622px"><img src="assets/img/poison.png" alt=""></div>
  <div class="a serif it" style="left:0;right:0;top:330px;text-align:center;font-size:48px">toxic</div>
</div>
{cut(P,'heart','heart.png',860,640,192,300,5)}
<div class="pin" id="{P}-pin" style="left:930px;top:640px;z-index:7"></div>
<div class="check" id="{P}-chk" style="left:-40px;top:780px;width:260px;height:340px;z-index:2"></div>
""", """
FLY("#@P@-w0", T[0], { a: 3.5, d: 1300 }); FLY("#@P@-w1", T[1], { a: 2.6, d: 1300 }); FLY("#@P@-w2", T[2], { a: -0.6, d: 1300 });
// TOXIC: the letters converge from all over and lock in on the word
SCATTER(".@P@-t", T[3], { st: 0.025, dur: 0.32 });
WIPE("#@P@-hl", T[3] + 0.14, { dur: 0.2 });
DROP("#@P@-bottle", T[3], { r: 4, dur: 0.38, y0: -1000 });
SHAKE("#@P@-st", T[3] + 0.26, 12);
tl.fromTo("#@P@-chk", { x: -300 }, { x: 0, rotation: 6, duration: 0.4, ease: "expo.out" }, T[3]);
DROP("#@P@-heart", T[3] + 0.2, { r: -12, dur: 0.4, y0: 700, dr: -20 });
POP("#@P@-pin", T[3] + 0.42);
// exit: whip left
OUT(Q("#@P@-st .w, #@P@-st .l, #@P@-hl, #@P@-bottle, #@P@-heart, #@P@-pin, #@P@-chk"), 1.25, { x: -1100, st: 0.003, dur: 0.16 });
""", 83, cap=6)

# =====================================================================================
# S09 LINE 7 23.25-25.75 — "Phirse tere peeche ek kavi hua mutaasir" (typewriter)
P = "s09"
lines = [("Phirse tere peeche", [0, 1, 2]), ("ek kavi hua", [3, 4, 5]), ("mutaasir_", [6])]
TYPED = []   # (char, word index)
for li, (text, idxs) in enumerate(lines):
    words = text.split(" ")
    for wi, word in enumerate(words):
        for c in word:
            TYPED.append((c, idxs[wi]))
        if wi < len(words) - 1:
            TYPED.append((" ", idxs[wi]))
    TYPED.append(("\n", -1))
typed_html = "".join("<br>" if c == "\n" else f'<span class="l {P}-ty" data-w="{k}">{"&nbsp;" if c == " " else c}</span>' for c, k in TYPED)
scene(8, f"""
<div class="full" style="background:var(--khaki)"></div>
{chrome(P, "7/14 · a poet, again", "arya", "toxic", "@arya")}
<div class="a serif" style="left:120px;top:110px;font-size:100px;z-index:6">{w(P,'w0','Phirse ')}{w(P,'w1','tere ')}{w(P,'w2','peeche')}</div>
<div class="a serif" style="left:120px;top:270px;font-size:140px;z-index:6">{w(P,'w3','ek')}</div>
<div class="a serif it" id="{P}-kavi" style="left:290px;top:220px;font-size:300px;color:var(--signal);z-index:6;clip-path:inset(0px 100% 0px 0px)">kavi</div>
<div class="a serif it" style="left:120px;top:760px;font-size:120px;z-index:6">{mk(P,'w5','hua')} {ls(P,'mu','mutaasir.')}</div>
<div class="a" id="{P}-sheetwrap" style="left:880px;top:300px;width:380px;height:340px;overflow:hidden;z-index:3">
  <div class="a" id="{P}-sheet" data-layout-ignore style="left:0;top:0;width:380px;height:340px;background:#fff;box-shadow:0 10px 20px rgba(0,0,0,.12);padding:40px 34px;font:400 26px/1.65 'JetBrains Mono',monospace;color:#151311">{typed_html}</div>
</div>
{cut(P,'tw','typewriter.png',760,560,600,419,5)}
{cut(P,'quill','quill.png',1150,150,214,300,6)}
<div class="a" id="{P}-flood" style="left:0;top:0;width:1440px;height:1080px;background:#FAFAF8;z-index:80;opacity:0"></div>
""", """
DROP("#@P@-tw", 0.1, { y0: 700, dr: -6, dur: 0.5, ease: "expo.out" });
tl.fromTo("#@P@-sheet", { y: 340 }, { y: 0, duration: 0.55, ease: "power3.out" }, 0.2);
// the sheet types the line as it is sung
const WT = { 0: T[0], 1: T[1], 2: T[2], 3: T[3], 4: T[4], 5: T[5], 6: T[6] };
const seen = {};
Q(".@P@-ty").forEach((e) => { const k = +e.dataset.w; seen[k] = (seen[k] ?? -1) + 1; tl.fromTo(e, { opacity: 0 }, { opacity: 1, duration: 0.001 }, WT[k] - 0.02 + seen[k] * 0.028); });
["w0","w1","w2"].forEach((k, i) => BLUR("#@P@-" + k, T[i], { dur: 0.13 }));
FLY("#@P@-w3", T[3], { a: 3.3, d: 900 });
// kavi is written left to right like ink, while the quill flies in and dips
tl.fromTo("#@P@-kavi", { clipPath: "inset(0px 100% 0px 0px)" }, { clipPath: "inset(0px 0% 0px 0px)", duration: 0.34, ease: "power2.inOut" }, T[4] - 0.06);
tl.fromTo("#@P@-quill", { x: 600, y: -500, rotation: 60 }, { x: 0, y: 0, rotation: 10, duration: 0.45, ease: "expo.out" }, T[4] - 0.12);
tl.to("#@P@-quill", { keyframes: [{ y: 24, rotation: 14, duration: 0.12, ease: "power2.in" }, { y: 0, rotation: 10, duration: 0.24, ease: "power2.out" }] }, T[4] + 0.4);
RISE("#@P@-w5", T[5]);
SCATTER(".@P@-mu", T[6], { st: 0.028, dur: 0.36, w: 1200, h: 800 });
// exit: the typed sheet becomes the next page
tl.set("#@P@-flood", { opacity: 1 }, 2.08);
FLOOD("#@P@-flood", 2.08, "inset(300px 180px 440px 880px)", { dur: 0.42 });
""", 97, cap=7)

# =====================================================================================
# S10 LINE 8 25.75-28.12 — "Ek dafe ki baat hai mili nahi uske baad se" (binder sheet, torn polaroid)
P = "s10"
scene(9, f"""
<div class="full" style="background:#22232A"></div>
<div class="ftr mono" data-layout-ignore style="color:rgba(255,255,255,.55);z-index:40"><span>8/14 · arya</span><span>8/14 · arya</span><span>8/14 · arya</span></div>
<div class="a" id="{P}-page" style="left:0;top:0;width:1440px;height:1080px;z-index:2">
  <div class="a" style="left:120px;top:40px;width:1200px;height:74px;background-color:#F4F4F2;background-image:linear-gradient(#ddd 1px,transparent 1px),linear-gradient(90deg,#ddd 1px,transparent 1px);background-size:34px 34px"></div>
  <div class="a" style="left:120px;top:110px;width:1200px;height:640px;background:#FAFAF8;box-shadow:0 20px 40px rgba(0,0,0,.4)"></div>
  <div class="a" style="left:120px;top:100px;width:1200px;height:16px;background:linear-gradient(#ccc,#888);border-radius:8px"></div>
  {"".join(f'<div class="a" style="left:{x}px;top:66px;width:24px;height:70px;border:5px solid #999;border-radius:12px"></div>' for x in (220, 420, 1000, 1200))}
</div>
<div class="a" id="{P}-reveal" style="left:0;top:0;width:1440px;height:1080px;background:#FAFAF8;z-index:80"></div>
<div class="a sans" style="left:200px;top:160px;font-size:46px;font-weight:300;z-index:6">{w(P,'w0','EK ')}<b>{w(P,'w1','DAFE')}</b>{w(P,'w2',' KI')}</div>
<div class="a serif" style="left:190px;top:230px;font-size:230px;z-index:6">{w(P,'w3','baat ')}{w(P,'w4','hai')}</div>
<div class="a serif it" style="left:680px;top:470px;font-size:150px;z-index:6">{w(P,'w5','mili ')}{w(P,'w6','nahi')}</div>
<div class="pill" id="{P}-pill" style="left:200px;top:520px;background:#3B82F0;color:#fff;border-radius:999px 999px 999px 10px;z-index:7">{w(P,'p0','uske')}{w(P,'p1',' baad')}{w(P,'p2',' se')}</div>
<div class="a" id="{P}-pol" style="left:470px;top:600px;width:500px;height:505px;z-index:5">
  <div class="cut" id="{P}-pl" style="left:0;top:9px;width:261px;height:482px"><img src="assets/img/polaroid-l.png" alt=""></div>
  <div class="cut" id="{P}-pr" style="left:179px;top:0;width:321px;height:505px"><img src="assets/img/polaroid-r.png" alt=""></div>
</div>
<div class="pin steel" id="{P}-pin0" style="left:580px;top:610px;z-index:7"></div>
<div class="pin steel" id="{P}-pin1" style="left:820px;top:604px;z-index:7"></div>
""", """
// arriving: the typed sheet from the last scene shrinks onto the binder
UNFLOOD("#@P@-reveal", 0, "inset(110px 120px 330px 120px)", { dur: 0.36, ease: "expo.out" });
tl.set("#@P@-reveal", { opacity: 0 }, 0.37);
FLY("#@P@-w0", T[0], { a: Math.PI, d: 800, r0: 0, s0: 1, dur: 0.26 }); FLY("#@P@-w1", T[1], { a: -1.57, d: 700, r0: 0, s0: 1, dur: 0.26 }); FLY("#@P@-w2", T[2], { a: 0, d: 700, r0: 0, s0: 1, dur: 0.26 });
SLAM("#@P@-w3", T[3], { s0: 2.8 }); SLAM("#@P@-w4", T[4], { s0: 2.8 });
DROP("#@P@-pol", T[3], { r: -3, y0: 700, dr: -10, ease: "expo.out", dur: 0.5 });
POP("#@P@-pin0", T[3] + 0.3); POP("#@P@-pin1", T[3] + 0.36);
FLY("#@P@-w5", T[5], { a: 0.3, d: 1100 }); FLY("#@P@-w6", T[6], { a: -0.3, d: 1100 });
// on "nahi" the photo tears and the halves drift apart
tl.fromTo("#@P@-pl", { x: 0, rotation: 0 }, { x: -70, rotation: -7, duration: 0.5, ease: "expo.out" }, T[6]);
tl.fromTo("#@P@-pr", { x: 0, rotation: 0 }, { x: 80, rotation: 7, duration: 0.5, ease: "expo.out" }, T[6]);
tl.to("#@P@-pin1", { x: 80, duration: 0.5, ease: "expo.out" }, T[6]);
tl.to("#@P@-pin0", { x: -70, duration: 0.5, ease: "expo.out" }, T[6]);
SHAKE("#@P@-page", T[6] + 0.02, 6);
POP("#@P@-pill", T[7], { r0: -8, ease: "back.out(2)" });
tl.fromTo("#@P@-p1", { opacity: 0, y: 20 }, { opacity: 1, y: 0, duration: 0.14, ease: "expo.out" }, T[8] - 0.03);
tl.fromTo("#@P@-p2", { opacity: 0, y: 20 }, { opacity: 1, y: 0, duration: 0.14, ease: "expo.out" }, T[9] - 0.03);
// exit: the halves are flung off opposite sides, the rest blur-swaps out
tl.to("#@P@-pl", { x: -1000, rotation: -30, duration: 0.2, ease: "power3.in" }, 2.14);
tl.to("#@P@-pr", { x: 1000, rotation: 30, duration: 0.2, ease: "power3.in" }, 2.14);
OUT(Q("#@P@-st .w, #@P@-pill, #@P@-pin0, #@P@-pin1, #@P@-page"), 2.17, { o: 0, s: 0.96, st: 0.002, dur: 0.16 });
""", 101, cap=8)

# =====================================================================================
# S11 LINE 9 28.12-31.04 — "But I keep runnin around you" (vinyl + orbit)
P = "s11"
orbit_items = [("heart.png", 96, 150, -14), ("wine.png", 64, 150, 14), ("candle.png", 24, 150, 8), ("matchbox.png", 130, 126, -8)]
orb_html = "".join(
    f'<div class="a" id="{P}-o{i}" style="left:575px;top:235px;width:650px;height:650px;z-index:6">'
    f'<div class="cut" id="{P}-oi{i}" style="left:{325 - wd/2}px;top:{-ht/2}px;width:{wd}px;height:{ht}px"><img src="assets/img/{img}" alt=""></div></div>'
    for i, (img, wd, ht, r) in enumerate(orbit_items))
scene(10, f"""
<div class="full" style="background:var(--cream)"></div>
{chrome(P, "9/14 · in english now", "rpm 33⅓", "side a", "loop ∞")}
<div class="a hv" style="left:120px;top:130px;font-size:100px;z-index:6">{w(P,'w0','BUT ')}{w(P,'w1','I ')}{w(P,'w2','KEEP')}</div>
<div class="a serif it" style="left:116px;top:250px;font-size:170px;z-index:6">{ls(P,'ru','runnin')}</div>
<div class="a serif" style="left:116px;top:430px;font-size:132px;z-index:6">{ls(P,'ar','around')}</div>
<div class="a serif it" id="{P}-you" style="left:116px;top:590px;font-size:230px;color:var(--signal);z-index:6">you</div>
<svg class="a" style="left:0;top:0;z-index:3" width="1440" height="1080">
  <defs><path id="{P}-orb" d="M900 230 a 330 330 0 1 1 -0.1 0"/></defs>
  <circle id="{P}-ring" cx="900" cy="560" r="330" fill="none" stroke="#151311" stroke-width="2.5" stroke-dasharray="10 12"/>
  <text id="{P}-ringtxt" data-layout-ignore font-family="JetBrains Mono" font-weight="600" font-size="24" letter-spacing="8" fill="#151311"><textPath id="{P}-tp" href="#{P}-orb" startOffset="0">BUT I KEEP RUNNIN AROUND YOU • BUT I KEEP RUNNIN AROUND YOU • BUT I KEEP RUNNIN AROUND YOU •</textPath></text>
</svg>
<div class="a" id="{P}-sleeve" style="left:640px;top:360px;width:400px;height:400px;background:#EDE6D2;box-shadow:0 16px 26px rgba(0,0,0,.22);z-index:4"></div>
<div class="a" id="{P}-disc" style="left:730px;top:390px;width:340px;height:340px;border-radius:50%;z-index:5;box-shadow:0 18px 26px rgba(0,0,0,.3);
  background:radial-gradient(circle,#EF5122 0 18%,#151311 18.5% 20%,transparent 20%),conic-gradient(from 0deg,rgba(255,255,255,.0) 0deg,rgba(255,255,255,.16) 30deg,rgba(255,255,255,0) 60deg,rgba(255,255,255,0) 180deg,rgba(255,255,255,.12) 210deg,rgba(255,255,255,0) 240deg),repeating-radial-gradient(circle,#1b1a19 0 3px,#0c0c0c 3px 5px)">
  <div class="a" style="left:164px;top:164px;width:12px;height:12px;border-radius:50%;background:#F2EDE2"></div>
  <div class="a mono" data-layout-ignore style="left:0;right:0;top:186px;text-align:center;font-size:10px;color:#fff">arya · toxic</div>
</div>
{orb_html}
<div class="a" id="{P}-flood" style="left:0;top:0;width:1440px;height:1080px;z-index:85;opacity:0"><div class="full mat"></div></div>
""", """
tl.fromTo("#@P@-ring", { strokeDashoffset: 0, opacity: 0, scale: 0.6, svgOrigin: "900 560" }, { opacity: 1, scale: 1, duration: 0.5, ease: "expo.out" }, 0);
tl.fromTo("#@P@-tp", { attr: { startOffset: 0 } }, { attr: { startOffset: 420 }, duration: 2.92, ease: "none" }, 0);
tl.fromTo("#@P@-ringtxt", { opacity: 0 }, { opacity: 1, duration: 0.3 }, 0.2);
tl.fromTo("#@P@-sleeve", { x: -500, rotation: -20 }, { x: 0, rotation: -6, duration: 0.5, ease: "expo.out" }, 0.05);
tl.fromTo("#@P@-disc", { x: 700, rotation: 0 }, { x: 0, rotation: 200, duration: 0.6, ease: "expo.out" }, 0.18);
tl.to("#@P@-disc", { rotation: 200 + 200 * 2.3, duration: 2.3, ease: "none" }, 0.78);
FLY("#@P@-w0", T[0], { a: 3.6, d: 1000 }); FLY("#@P@-w1", T[1], { a: -1.6, d: 900 }); FLY("#@P@-w2", T[2], { a: 2.4, d: 1000 });
// runnin: letters sprint in from the left, a frame apart
RUN(".@P@-ru", T[3], { x0: -1500, st: 0.035, dur: 0.34 });
// around: each letter swings in around a far pivot, tracing a circle
Q(".@P@-ar").forEach((e, i) => tl.fromTo(e, { rotation: -200, opacity: 0, transformOrigin: "50% 380%" }, { rotation: 0, opacity: 1, duration: 0.42, ease: "expo.out" }, T[4] - 0.12 + i * 0.035));
SLAM("#@P@-you", T[5], { s0: 3 });
SHAKE("#@P@-st", T[5] + 0.06, 9);
// four objects orbit the record, joining one beat apart; each stays upright (counter-rotated)
[0, 1, 2, 3].forEach((i) => {
  const t0 = 0.5 + i * 0.64, start = i * 90;
  tl.fromTo("#@P@-o" + i, { rotation: start }, { rotation: start + 260, duration: 2.92 - t0 + 0.4, ease: "none" }, t0 - 0.4);
  tl.fromTo("#@P@-oi" + i, { rotation: -start, scale: 0 }, { rotation: -(start + 260), scale: 1, duration: 2.92 - t0 + 0.4, ease: "none" }, t0 - 0.4);
});
// exit: the red label grows into the next scene's orange mat
tl.set("#@P@-flood", { opacity: 1 }, 2.5);
tl.fromTo("#@P@-flood", { clipPath: "circle(0px at 900px 560px)" }, { clipPath: "circle(1500px at 900px 560px)", duration: 0.42, ease: "power3.in" }, 2.5);
""", 113, cap=9)

# =====================================================================================
# S12 KYU KYU KYU (v2) 31.04-32.18 — ONE slide: three stickers stack into one pile on the mat
P = "s12"
scene(11, f"""
<div class="full mat" id="{P}-mat"></div>
{chrome(P, "10/14 · again", "kyu", "kyu", "kyu?", "#fff")}
<div class="a" id="{P}-c0" data-layout-allow-overlap style="left:130px;top:270px;width:470px;height:470px;border-radius:50%;background:var(--lime);box-shadow:0 20px 24px rgba(0,0,0,.25);z-index:5"><div class="hv" style="font-size:170px;text-align:center;line-height:470px">KYU</div></div>
<div class="a" id="{P}-c1" data-layout-allow-overlap style="left:500px;top:350px;width:470px;height:470px;border-radius:50%;background:var(--cobalt);box-shadow:0 20px 24px rgba(0,0,0,.25);z-index:6"><div class="hv" style="font-size:170px;text-align:center;line-height:470px;color:var(--cream)">KYU</div></div>
<div class="a" id="{P}-c2" data-layout-allow-overlap style="left:860px;top:250px;width:490px;height:490px;border-radius:50%;background:var(--cream);box-shadow:0 20px 24px rgba(0,0,0,.25);z-index:7"><div class="hv" style="font-size:170px;text-align:center;line-height:490px">KYU?</div></div>
<div class="pin" id="{P}-pin" style="left:1085px;top:250px;z-index:8;background:radial-gradient(circle at 35% 30%,#fff,#bbb 50%,#555)"></div>
""", """
const H = @H@;
// stickers slap down one on top of the other — one pile, one slide
H.forEach((h, i) => {
  tl.fromTo("#@P@-c" + i, { scale: 1.7, rotation: [-30, 26, -18][i], opacity: 0 }, { scale: 1, rotation: [-8, 6, -3][i], opacity: 1, duration: 0.14, ease: "power4.out" }, h - 0.05);
  SHAKE("#@P@-mat", h + 0.04, 8 + i * 3);
});
POP("#@P@-pin", H[2] + 0.1);
""", 127)

# =====================================================================================
# S13 LINE 11 32.18-33.52 — "Tu phirbhi banti toxic" (bottle tips, lime spills)
P = "s13"
scene(12, f"""
<div class="full" style="background:var(--paper)"></div>
{chrome(P, "11/14 · spilled", "dose: two", "told you", "keep away")}
<div class="a hv" style="left:120px;top:120px;font-size:120px;z-index:6">{w(P,'w0','TU ')}{w(P,'w1','PHIRBHI')}<br>{w(P,'w2','BANTI')}</div>
<div class="a serif it" style="left:110px;top:350px;font-size:320px;z-index:6">{ls(P,'t','toxic')}</div>
<svg class="a" id="{P}-spill" style="left:-150px;top:790px;z-index:3" width="680" height="250" viewBox="0 0 1020 380"><path d="M980 200 C 1000 120, 840 90, 720 120 C 600 150, 520 80, 380 120 C 240 160, 60 170, 40 250 C 20 330, 260 350, 420 330 C 580 310, 700 360, 840 330 C 960 300, 960 260, 980 200Z" fill="#C9F23F"/></svg>
<div class="a" id="{P}-bottle" style="left:1100px;top:230px;width:262px;height:622px;z-index:5">
  <div class="cut" style="left:0;top:0;width:262px;height:622px"><img src="assets/img/poison.png" alt=""></div>
  <div class="a serif it" style="left:0;right:0;top:330px;text-align:center;font-size:48px">toxic</div>
</div>
<div class="a" id="{P}-flood" style="left:0;top:0;width:1440px;height:1080px;background:var(--lime);z-index:85;opacity:0"></div>
""", """
FLY("#@P@-w0", T[0], { a: 1.5, d: 900, dur: 0.26 }); FLY("#@P@-w1", T[1], { a: 1.8, d: 900, dur: 0.26 }); FLY("#@P@-w2", T[2], { a: 1.2, d: 900, dur: 0.26 });
// the bottle tips over on its base
tl.fromTo("#@P@-bottle", { rotation: 0, x: 0, y: 0 }, { rotation: -78, x: -40, y: 120, duration: 0.42, ease: "power3.in", transformOrigin: "20% 100%" }, T[2] - 0.05);
tl.to("#@P@-bottle", { keyframes: [{ rotation: -72, duration: 0.08, ease: "power2.out" }, { rotation: -78, duration: 0.14, ease: "power2.in" }], transformOrigin: "20% 100%" }, T[2] + 0.37);
tl.fromTo("#@P@-spill", { scaleX: 0, scaleY: 0.2 }, { scaleX: 1, scaleY: 1, duration: 0.5, ease: "expo.out", transformOrigin: "98% 45%" }, T[2] + 0.36);
// toxic: letters drip down into place and bounce
Q(".@P@-t").forEach((e, i) => tl.fromTo(e, { y: -700, opacity: 0 }, { y: 0, opacity: 1, duration: 0.42, ease: "back.out(2.2)" }, T[3] - 0.12 + i * 0.04));
// exit: the spill floods the frame
tl.set("#@P@-flood", { opacity: 1 }, 1.0);
FLOOD("#@P@-flood", 1.0, "inset(800px 910px 50px 0px)", { dur: 0.34 });
""", 131, cap=11)

# =====================================================================================
# S14 LINE 12 33.52-36.1 — "Phirse tere peeche hogayi balaa ki aatish" (matchbox under a magnifier)
P = "s14"
mono_hdr = ls(P, 'ph', 'PHIRSE TERE PEECHE')
scene(13, f"""
<div class="full mat"></div>
<div class="a mono" data-layout-ignore style="left:0;right:0;top:46px;text-align:center;color:#fff;z-index:40;font-size:18px">{mono_hdr}<span style="opacity:.6"> · 12/14</span></div>
<div class="a mono" data-layout-ignore style="left:72px;bottom:40px;color:#fff;z-index:40">strike anywhere</div>
<div class="a hv" style="left:120px;top:130px;font-size:120px;z-index:6">{w(P,'w3','HOGAYI ')}{w(P,'w4','BALAA ')}{w(P,'w5','KI')}</div>
<div class="a" id="{P}-hl" style="left:104px;top:300px;width:900px;height:290px;background:var(--cream);z-index:4"></div>
<div class="a hv" style="left:118px;top:270px;font-size:330px;z-index:6;letter-spacing:.01em">{ls(P,'aa','AATISH')}</div>
<div class="a" id="{P}-glow" style="left:1050px;top:560px;width:300px;height:300px;border-radius:50%;background:radial-gradient(circle,rgba(255,220,120,.6),rgba(255,180,60,0) 65%);z-index:6;opacity:0"></div>
{cut(P,'mb','matchbox.png',985,690,340,331,5)}
<div class="a" id="{P}-mag" style="left:930px;top:610px;width:560px;height:700px;z-index:7">
  <div class="a" id="{P}-lens" style="left:0;top:0;width:450px;height:450px;border-radius:50%;border:26px solid #CFD3D6;box-shadow:inset 0 0 0 6px #fff,0 30px 40px rgba(0,0,0,.35);background:radial-gradient(circle,rgba(255,255,255,.18),rgba(255,255,255,.02))"></div>
  <div class="a" style="left:380px;top:410px;width:70px;height:260px;background:linear-gradient(90deg,#9aa,#eee,#889);border-radius:20px;transform:rotate(-42deg);box-shadow:0 20px 30px rgba(0,0,0,.3)"></div>
</div>
<div class="a" id="{P}-lime" style="left:0;top:0;width:1440px;height:1080px;background:var(--lime);z-index:80"></div>
<div class="a" id="{P}-through" style="left:0;top:0;width:1440px;height:1080px;background:#3A2E25;z-index:85;opacity:0"></div>
""", """
UNFLOOD("#@P@-lime", 0, "inset(1080px 0px 0px 0px)", { dur: 0.36, ease: "power2.inOut" });
// header types word by word with the vocal
Q(".@P@-ph").forEach((e, i) => { const k = i < 7 ? 0 : i < 12 ? 1 : 2; const base = [T[0], T[1], T[2]][k]; const off = i - [0, 7, 12][k]; tl.fromTo(e, { opacity: 0 }, { opacity: 1, duration: 0.001 }, base + off * 0.03); });
FLY("#@P@-w3", T[3], { a: 3.4, d: 1200 }); FLY("#@P@-w4", T[4], { a: -1.9, d: 1100 }); FLY("#@P@-w5", T[5], { a: 0.4, d: 1000, dur: 0.22 });
DROP("#@P@-mb", T[3], { r: -6, dur: 0.5 });
tl.fromTo("#@P@-mag", { x: 700, y: 500, rotation: 20 }, { x: 0, y: 0, rotation: 0, duration: 0.7, ease: "expo.out" }, T[3] + 0.4);
// AATISH ignites: each letter flickers on like a struck match, then the cream block burns in behind
Q(".@P@-aa").forEach((e, i) => { const t = T[6] - 0.06 + i * 0.04;
  tl.fromTo(e, { opacity: 0, scale: 1.25 }, { keyframes: [{ opacity: 1, duration: 0.02 }, { opacity: 0.2, duration: 0.03 }, { opacity: 1, scale: 1, duration: 0.1, ease: "power3.out" }] }, t); });
WIPE("#@P@-hl", T[6] + 0.12, { dur: 0.22 });
tl.fromTo("#@P@-glow", { opacity: 0, scale: 0.6 }, { opacity: 1, scale: 1.3, duration: 0.25, ease: "expo.out" }, T[6]);
tl.to("#@P@-glow", { scale: 1, opacity: 0.7, duration: 0.3, ease: "power2.out" }, T[6] + 0.25);
SHAKE("#@P@-st", T[6] + 0.1, 10);
// exit: zoom through the magnifier lens into the next scene
tl.to("#@P@-mag", { scale: 7, x: -435, y: -295, duration: 0.42, ease: "power3.in", transformOrigin: "225px 225px" }, 2.16);
tl.fromTo("#@P@-through", { opacity: 0 }, { opacity: 1, duration: 0.14, ease: "none" }, 2.44);
""", 149, cap=12)

# =====================================================================================
# S15 LINE 13 36.1-38.6 — "Ek dafe ki baat hai thi dil mein uske saazish" (evidence board)
P = "s15"
notes = [("thi", 200, 180, -6, 5), ("dil <i>mein</i>", 1030, 170, 5, 6), ("uske", 220, 600, 4, 8)]
scene(14, f"""
<div class="full" style="background:#3A2E25"></div>
<div class="full halftone" style="opacity:.35"></div>
<div class="ftr mono" data-layout-ignore style="color:rgba(255,255,255,.6);z-index:40"><span>13/14</span><span>case: her heart</span><span>@arya</span></div>
<div class="a sans" style="left:120px;top:64px;font-size:40px;font-weight:300;color:var(--cream);z-index:6">{w(P,'w0','EK ')}{w(P,'w1','DAFE ')}{w(P,'w2','KI ')}<b>{w(P,'w3','BAAT ')}{w(P,'w4','HAI')}</b></div>
<svg class="a" style="left:0;top:0;z-index:4" width="1440" height="1080" fill="none" stroke="#E0301E" stroke-width="4">
  <path id="{P}-s0" d="M720 430 L 300 210" pathLength="100" stroke-dasharray="100 120" stroke-dashoffset="110"/>
  <path id="{P}-s1" d="M720 430 L 1130 200" pathLength="100" stroke-dasharray="100 120" stroke-dashoffset="110"/>
  <path id="{P}-s2" d="M720 430 L 320 630" pathLength="100" stroke-dasharray="100 120" stroke-dashoffset="110"/>
  <path id="{P}-s3" d="M720 430 L 1150 640" pathLength="100" stroke-dasharray="100 120" stroke-dashoffset="110"/>
</svg>
{"".join(f'<div class="note" id="{P}-n{i}" style="left:{x}px;top:{y}px;z-index:6">{t}</div><div class="pin" id="{P}-np{i}" style="left:{x+90}px;top:{y-12}px;z-index:7"></div>' for i,(t,x,y,r,_) in enumerate(notes))}
<div class="note" id="{P}-n3" style="left:1060px;top:610px;background:var(--lime);font:600 28px/1.2 'JetBrains Mono',monospace;z-index:6">evidence<br>no. 13</div>
<div class="pin" id="{P}-np3" style="left:1150px;top:598px;z-index:7"></div>
{cut(P,'heart','heart.png',566,180,307,480,5)}
<div class="pin" id="{P}-hp" style="left:700px;top:400px;z-index:7"></div>
<div class="a serif it" id="{P}-saz" style="left:0;right:0;top:720px;text-align:center;font-size:230px;color:var(--cream);z-index:6;clip-path:inset(0px 100% 0px 0px)">saazish</div>
""", """
tl.fromTo("#@P@-st", { scale: 1.4, opacity: 0.6 }, { scale: 1, opacity: 1, duration: 0.45, ease: "expo.out" }, 0);
["w0","w1","w2"].forEach((k, i) => BLUR("#@P@-" + k, T[i], { dur: 0.13 }));
SLAM("#@P@-w3", T[3], { s0: 2.2 }); SLAM("#@P@-w4", T[4], { s0: 2.2 });
DROP("#@P@-heart", T[3], { r: -4, dur: 0.5 });
POP("#@P@-hp", T[3] + 0.34);
// the heart keeps beating on the beat once it is pinned
@BEATS@.forEach((b) => tl.fromTo("#@P@-heart", { scale: 1 }, { keyframes: [{ scale: 1.06, duration: 0.07, ease: "power2.out" }, { scale: 1, duration: 0.16, ease: "power2.in" }], immediateRender: false }, b));
// notes are thrown at the board, pinned, and wired to the heart
[[0, T[5]], [1, T[6]], [2, T[8]], [3, T[7]]].forEach(([i, t]) => {
  tl.fromTo("#@P@-n" + i, { x: (i % 2 ? 900 : -900), y: -300, rotation: (i % 2 ? 70 : -70), opacity: 0 }, { x: 0, y: 0, rotation: [-6, 5, 4, -5][i], opacity: 1, duration: 0.3, ease: "expo.out" }, t - 0.1);
  POP("#@P@-np" + i, t + 0.12);
  DRAW("#@P@-s" + i, t + 0.14, 0.26);
});
// saazish is written across the board
tl.fromTo("#@P@-saz", { clipPath: "inset(0px 100% 0px 0px)" }, { clipPath: "inset(0px 0% 0px 0px)", duration: 0.26, ease: "power2.inOut" }, T[9] - 0.06);
// exit: whip down
OUT(Q("#@P@-st .w, #@P@-st .note, #@P@-st .pin, #@P@-heart, #@P@-saz"), 2.32, { y: 900, st: 0.004, dur: 0.18 });
""".replace("@BEATS@", json.dumps([round(b - 36.1, 2) for b in plan["beats"] if 36.1 + 1.2 < b < 38.4])), 157, cap=13)

# =====================================================================================
# S16 LINE 14 + END 38.6-42.4 — "Pata nahi chahti thi fir mera dil kyu" (split, the last question)
P = "s16"
scene(15, f"""
<div class="full" style="background:var(--cream)"></div>
<div class="a" id="{P}-right" style="left:720px;top:0;width:720px;height:1080px;background:var(--blue);z-index:1"></div>
<div class="a serif" style="left:120px;top:110px;font-size:150px;z-index:6">{w(P,'w0','Pata ')}{w(P,'w1','nahi')}</div>
<div class="a serif it" style="left:124px;top:270px;font-size:100px;z-index:6">{w(P,'w2','chahti ')}{w(P,'w3','thi')}</div>
{cut(P,'heart','heart.png',150,380,192,300)}
<div class="a hv" style="left:800px;top:110px;font-size:130px;z-index:6;line-height:.9">{w(P,'w4','FIR')}<br>{w(P,'w5','MERA')}<br>{w(P,'w6','DIL')}</div>
<div class="a" id="{P}-pol" style="left:1060px;top:380px;width:300px;height:303px;z-index:5">
  <div class="cut" style="left:0;top:5px;width:157px;height:289px"><img src="assets/img/polaroid-l.png" alt=""></div>
  <div class="cut" style="left:107px;top:0;width:193px;height:303px"><img src="assets/img/polaroid-r.png" alt=""></div>
</div>
<div class="pin steel" id="{P}-pin" style="left:1190px;top:372px;z-index:7"></div>
<div class="a serif it" style="left:0;right:0;top:640px;text-align:center;font-size:300px;color:var(--signal);z-index:8">{ls(P,'k','kyu')}<span class="l" id="{P}-q">?</span></div>
<div class="a mono" data-layout-ignore style="left:72px;bottom:40px;z-index:40">14/14</div>
<div class="a mono" data-layout-ignore style="right:72px;bottom:40px;z-index:40">arya — toxic</div>
<div class="a" id="{P}-black" style="left:0;top:0;width:1440px;height:1080px;background:#000;opacity:0;z-index:95"></div>
""", """
tl.fromTo("#@P@-st", { y: -600 }, { y: 0, duration: 0.36, ease: "expo.out" }, 0);
tl.fromTo("#@P@-right", { x: 720 }, { x: 0, duration: 0.4, ease: "expo.out" }, 0.06);
FLY("#@P@-w0", T[0], { a: 3.3, d: 1000 }); FLY("#@P@-w1", T[1], { a: 2.8, d: 1000 });
BLUR("#@P@-w2", T[2]); BLUR("#@P@-w3", T[3]);
DROP("#@P@-heart", T[3], { r: -8, dur: 0.5 });
SLAM("#@P@-w4", T[4], { s0: 2.6 }); SLAM("#@P@-w5", T[5], { s0: 2.6 }); SLAM("#@P@-w6", T[6], { s0: 2.6 });
DROP("#@P@-pol", T[5], { r: 7, dur: 0.5, y0: -700 });
POP("#@P@-pin", T[5] + 0.32);
// kyu: k and y fly in from the left half, u from the right — the only word that crosses the split
const K = Q(".@P@-k");
tl.fromTo(K[0], { x: -900, rotation: -40, opacity: 0 }, { x: 0, rotation: 0, opacity: 1, duration: 0.36, ease: "expo.out" }, T[7] - 0.12);
tl.fromTo(K[1], { x: -900, y: 300, rotation: -30, opacity: 0 }, { x: 0, y: 0, rotation: 0, opacity: 1, duration: 0.36, ease: "expo.out" }, T[7] - 0.09);
tl.fromTo(K[2], { x: 900, rotation: 40, opacity: 0 }, { x: 0, rotation: 0, opacity: 1, duration: 0.36, ease: "expo.out" }, T[7] - 0.06);
SHAKE("#@P@-st", T[7] + 0.2, 8);
POP("#@P@-q", T[7] + 0.62, { r0: -60, ease: "back.out(2.6)", dur: 0.3 });
// the last line holds still, then the record ends
tl.to("#@P@-black", { opacity: 1, duration: 0.5, ease: "power2.in" }, 3.28);
""", 163, cap=14)

# ---------- write files ----------
os.makedirs(os.path.join(ROOT, "compositions"), exist_ok=True)
for s in SCENES:
    P = s["P"]
    js = (JS + s["js"] + f'\nwindow.__timelines["{P}"] = tl;\n').replace("@SEED@", str(s["seed"])).replace("@T@", json.dumps(s["T"])).replace("@H@", json.dumps(s["hits"])).replace("@P@", P)
    html = f"""<template>
  <style>{CSS.replace("@P@", P)}</style>
  <div id="root" data-composition-id="{P}" data-width="{W}" data-height="{H}">
    <div id="{P}-st">
{s["html"]}
      <div class="grain"></div>
    </div>
  </div>
  <script>{js}</script>
</template>
"""
    open(os.path.join(ROOT, f"compositions/{P}.html"), "w").write(html)

hosts = "\n".join(
    f'      <div id="{s["P"]}" data-composition-id="{s["P"]}" data-composition-src="compositions/{s["P"]}.html" '
    f'data-start="{s["start"]:.3f}" data-duration="{s["dur"]:.3f}" data-track-index="1" data-track-kind="graphics" '
    f'data-width="{W}" data-height="{H}"></div>' for s in SCENES)
index = f"""<!doctype html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width={W}, height={H}" />
    <script src="https://cdn.jsdelivr.net/npm/gsap@3.15.0/dist/gsap.min.js"></script>
    <style>
      * {{ margin: 0; padding: 0; box-sizing: border-box; }}
      html, body {{ margin: 0; width: {W}px; height: {H}px; overflow: hidden; background: #F2EDE2; }}
    </style>
  </head>
  <body>
    <div id="root" data-composition-id="main" data-start="0" data-duration="{TOTAL}" data-width="{W}" data-height="{H}" data-motion-blur="on">
{hosts}
      <audio id="song" class="clip" src="assets/toxic-full.mp3" data-start="0" data-duration="{TOTAL}" data-track-index="2" data-volume="1" data-fade-in="0.2" data-fade-out="1.2"></audio>
    </div>
    <script>
      window.__timelines = window.__timelines || {{}};
      window.__timelines["main"] = gsap.timeline({{ paused: true }});
    </script>
  </body>
</html>
"""
open(os.path.join(ROOT, "index.html"), "w").write(index)
print("wrote", len(SCENES), "scenes;", sum(s["dur"] for s in SCENES), "s")
