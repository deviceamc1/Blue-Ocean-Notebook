# White-background cutouts -> transparent PNGs.  Usage: python3 cutout.py <raw_dir> <out_dir>
# Flood-fills near-white pixels connected to the border, erodes 1px, feathers 1.2px, crops,
# and caps the long side at 720px. Needs Pillow + numpy.
import sys, glob, os
from collections import deque
import numpy as np
from PIL import Image, ImageFilter

src, dst = sys.argv[1], sys.argv[2]
os.makedirs(dst, exist_ok=True)
for f in sorted(glob.glob(os.path.join(src, "*.png"))):
    im = Image.open(f).convert("RGB")
    a = np.asarray(im).astype(int)
    h, w, _ = a.shape
    # "background" = near-white, low-saturation pixels connected to the border
    mn, mx = a.min(2), a.max(2)
    bgish = (mn > 228) & (mx - mn < 18)
    seen = np.zeros((h, w), bool)
    q = deque()
    for x in range(w):
        for y in (0, h - 1):
            if bgish[y, x] and not seen[y, x]:
                seen[y, x] = True; q.append((y, x))
    for y in range(h):
        for x in (0, w - 1):
            if bgish[y, x] and not seen[y, x]:
                seen[y, x] = True; q.append((y, x))
    while q:
        y, x = q.popleft()
        for dy, dx in ((1, 0), (-1, 0), (0, 1), (0, -1)):
            ny, nx = y + dy, x + dx
            if 0 <= ny < h and 0 <= nx < w and bgish[ny, nx] and not seen[ny, nx]:
                seen[ny, nx] = True; q.append((ny, nx))
    alpha = Image.fromarray(np.where(seen, 0, 255).astype(np.uint8))
    alpha = alpha.filter(ImageFilter.MinFilter(3)).filter(ImageFilter.GaussianBlur(1.2))
    out = im.convert("RGBA"); out.putalpha(alpha)
    bb = alpha.point(lambda v: 255 if v > 20 else 0).getbbox()
    out = out.crop(bb); out.thumbnail((720, 720))
    name = os.path.splitext(os.path.basename(f))[0]
    out.save(os.path.join(dst, name + ".png"), optimize=True)
    print(name, out.size, f"{(~seen).mean():.0%} kept")
