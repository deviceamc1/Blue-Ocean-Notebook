# Split one cutout PNG into two layers so their parts can move separately.
#   color  in.png a.png b.png        a = blue-ish object, b = red/orange-ish object (e.g. moon / sun)
#   column in.png left.png right.png a jagged vertical tear (e.g. a torn polaroid)
#   top    in.png top.png rest.png   a thin top part above a wide body (e.g. flame / candle)
# Needs Pillow + numpy. Each output is cropped to its own content.
import sys
import numpy as np
from PIL import Image, ImageFilter


def save(arr, path):
    im = Image.fromarray(arr.astype(np.uint8))
    bb = im.getchannel("A").point(lambda v: 255 if v > 100 else 0).getbbox()
    im = im.crop(bb)
    im.save(path)
    print(path, im.size)


def soft(mask, k=10):
    return np.asarray(Image.fromarray(mask.astype(np.uint8) * 255).filter(ImageFilter.BoxBlur(k))).astype(float)


def by_color(a):
    r, b, al = a[..., 0], a[..., 2], a[..., 3]
    blue = (al > 60) & (b > r + 30)
    red = (al > 60) & (r > b + 30)
    sb, sr = soft(blue), soft(red)
    # neutral pixels (paper edges) go to the nearer colour; far-away strays are dropped
    m1 = (blue | (~red & (sb > sr))) & (sb > 8)
    m2 = (red | (~blue & (sr >= sb))) & (sr > 8)
    return m1, m2


def by_column(a):
    al = a[..., 3]
    h, w = al.shape
    lo, hi = int(w * 0.35), int(w * 0.65)
    fallback = lo + int(np.argmin(al.sum(0)[lo:hi]))
    left = np.zeros_like(al, bool)
    for y in range(h):
        seg = al[y, lo:hi]
        c = lo + int(np.argmin(seg)) if seg.min() < 40 else fallback
        left[y, :c] = True
    return left, ~left


def by_top(a):
    al = a[..., 3]
    h, w = al.shape
    split = next(y for y in range(int(h * 0.05), h) if (al[y] > 100).sum() > w * 0.5)
    top = np.zeros_like(al, bool)
    top[:split] = True
    return top, ~top


if __name__ == "__main__":
    mode, src, out_a, out_b = sys.argv[1:5]
    a = np.asarray(Image.open(src).convert("RGBA")).astype(int)
    m1, m2 = {"color": by_color, "column": by_column, "top": by_top}[mode](a)
    for mask, path in ((m1, out_a), (m2, out_b)):
        out = a.copy()
        out[..., 3] = np.where(mask, a[..., 3], 0)
        save(out, path)
