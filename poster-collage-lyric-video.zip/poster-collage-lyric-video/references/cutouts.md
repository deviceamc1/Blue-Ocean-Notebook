# Cutouts

## Pick the props from the lyrics

Give each lyric line one object that shows its meaning, not the line itself. Toxic used:

| Line idea | Prop |
| --- | --- |
| title / poison | apothecary bottle with a blank label (the label text is set in HTML on top of it) |
| waiting / the hour | twin-bell alarm clock (the second hand is a CSS line that ticks on beats) |
| holding | white plaster hand, palm up |
| wine | red wine glass |
| day and night | paper-cut sun + crescent moon in one image, split into two layers |
| breath | lit candle (flame split onto its own layer) |
| poet | quill in an ink pot; vintage typewriter |
| met once, never again | a polaroid torn in half (split into two halves) |
| running around you | a record in a sleeve (the disc is redrawn in CSS so it can spin) |
| fire | matchbox with a lit match |
| heart / conspiracy | anatomical heart in halftone risograph style |

## Generation

- Model: Higgsfield `gpt_image_2_5`, 1:1, 0.25 credits each. Run `get_cost: true` once, then send all of them in one `generate_image_batch` (up to 12 items), then `jobs_wait`, then download the `result_url`s with curl.
- Prompt template (photoreal): `Photoreal product cutout of <object, material, colour, angle>, isolated centered on pure flat white background, soft studio light, crisp edges, editorial collage sticker style, no text`
- Illustrated variant: `Vintage <object> illustration, two-tone halftone print style in deep red and black ink on cream, like a retro risograph poster, isolated on pure flat white background, centered, no text`
- Paper craft variant: `Paper cut craft: <shapes> cut from matte textured paper, slight paper thickness visible, isolated on pure flat white background, flat lay, editorial collage, no text`
- Ask for blank labels and "no text": put any text on the props yourself in HTML.

## Background removal

`python3 scripts/cutout.py <raw_dir> <out_dir>` flood-fills near-white pixels from the image borders, erodes 1 px, feathers 1.2 px, crops to the content and caps the long side at 720 px. Wine-glass interiors survive because the fill only reaches from the edges. It needs Pillow + numpy; run it without `-I` so user site-packages load, from a directory you control.

Always check the result on a cream contact sheet before using it.

## Layers for moving parts

`python3 scripts/split_layers.py <mode> <in.png> <out_a.png> <out_b.png> [args]`

- `color`: splits two differently coloured objects (sun = red, moon = blue). Each neutral pixel goes to whichever colour is nearer, and pixels far from both are dropped, so stray shadow pixels don't inflate the crop.
- `column`: a vertical tear (polaroid halves). For each row it cuts at the emptiest column in the middle 35–65% band.
- `top`: splits off a flame. It cuts at the first row where the object is wider than half the image (the candle body starts there).

After splitting, update the CSS width/height to the new aspect ratios. A spinning disc is easier redrawn in CSS (repeating-radial grooves, a conic highlight so the spin shows, a red label).
