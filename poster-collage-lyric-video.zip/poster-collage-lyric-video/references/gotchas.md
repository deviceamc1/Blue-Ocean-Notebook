# Gotchas (all hit on the first build)

| Problem | Fix |
| --- | --- |
| The highlight block behind an Anton/Oswald word was taller than the word and covered the line above | `.hl{display:inline-block;line-height:.86;padding:.04em .06em 0}`, or a separate absolutely positioned block sized to the cap height |
| The Browser pane's local server returned 404 for files in `~/Downloads` (macOS privacy restriction on the launched python) | copy the storyboard to the scratchpad and serve it from there; the real file stays in the project |
| `data:` URL preview breaks relative image paths | always serve the folder over http |
| `ffprobe not found`: check errors `audio_source_unreadable`, and the render fails | `npm i -D ffmpeg-static ffprobe-static`, symlink both into `.bin/`, `export PATH="$PWD/.bin:$PATH"` before check/snapshot/render; `chmod +x` the ffprobe binary |
| `python3 -I` can't import numpy/PIL | run without `-I`, from the scratchpad, with absolute paths |
| Micro mono chrome (16–20 px) fails the 28 px type floor | it is texture: add `data-layout-ignore` to header, footer and mono labels |
| Cream type on dusty blue fails contrast | deepen the blue to #6F8FB0 under cream type |
| `gsap_tween_tail` / overlapping tweens | one `fromTo` per element per property; no extra opacity tween before a SLAM; no yoyo on top of an elastic that is still running |
| Iris written as fromTo + set + fromTo flickered | give the overlay its start clip in CSS (`circle(0px at …)`) and use ONE `fromTo(..., {immediateRender:false})` at the exit time |
| A two-colour image split by column took the other object's parts with it (sun rays inside the moon crop) | split by colour region, not by column (`split_layers.py color`) |
| Stacked stickers hid each other's words | fan them so ≤100 px overlap and the type stays inside the visible part; `data-layout-allow-overlap` on each |
| A tipped bottle fell out of frame or over the lyric | pivot at `20% 100%`, keep `y` small, move the lyric up; start the spill at the bottle's mouth |
| A magnifier covered the hero word | keep props out of the type's bounding box; props go bottom-right, type top-left |
| The last word was still flying when the exit began | exits start ≥0.06 s after the last word lands; the last word uses SLAM at 0.12 s |
| `line_unread` warnings on sung lines | the song sets the pace; move non-lyric extras (pills, tags, translations) earlier so they hold ≥1.05 s, and accept the sung lines |
| A "Replay" pill as the last thing on screen was under the 2 s closing hold | end on the final lyric word; fade to black over the last 0.5 s |
| Text clipped at the frame edge | `white-space:nowrap` on every type block; estimate widths (serif ≈ 0.45 em per character, Oswald ≈ 0.5 em) before placing |
| Snapshots looked "wrong" during transitions | snapshot each scene 0.1–0.3 s before its exit starts for the landed state, then separately mid-motion |
