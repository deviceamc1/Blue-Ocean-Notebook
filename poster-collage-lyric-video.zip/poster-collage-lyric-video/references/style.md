# Style: analysis and scale

## The five references and what each adds

| Reference | Takes from it |
| --- | --- |
| Inspo Keywords (Pinterest) | Heavy condensed caps with ONE word on a lime block; a tracked mono label between hairline rules; photoreal paper cutouts and red pins; orange cutting mat; checkerboard; blurred props in the corners for depth; an outlined CTA box |
| Gift Guide | Tight high-contrast serif with words overlapping; one accent (orange); floating product cutouts with soft shadows; numbered orange badges with dashed curved connectors; pinstripe ground; a pill tag and a dark pill button |
| AntiCaos | Dusty-blue ground; a huge serif mixing a cream roman with a dark italic; a retro beige object as hero; a torn note held by a pin; menu-bar micro text across the top; bold number pairs left/right; handles in the footer |
| Picco | Cream paper; a left-aligned stack of very tight serif; a halftone illustrated object tumbling at an angle; one small centred paragraph; a 3-column footer |
| Alinhamento | Dark textured ground with a ring-binder sheet; a light + bold sans kicker, then serif, then italic serif; a blue speech-bubble pill; pinned cards; the footer micro text repeated 3× |

## What they share (the rules)

- **Type**: two voices only.
  - High-contrast serif (roman + italic, tracking −3%, leading 0.84–0.9) carries the emotion.
  - Ultra-heavy condensed grotesk in caps carries the impact.
  - Mono micro text only frames the poster: a header rule and a 3-column footer.
  - In each frame one word gets the highlight block or the accent colour.
- **Objects**:
  - Real objects cut out cleanly, with a two-layer contact shadow.
  - One hero prop at 50–65% of the frame, 1–3 secondary props, and pins, badges or notes as tertiary details.
  - Rotation in steps: 0, ±3, ±8, ±14°.
  - Blurred corner props give depth of field.
- **Colour**: paper neutrals, plus ink, plus ONE loud accent per frame.
- **Finish**:
  - Fine paper grain over everything (SVG fractal noise at 16% opacity, multiply).
  - Halftone on illustrated props.
  - Nothing glossy or glowing: it should look printed and physical.

## Tokens

```
--paper  #F2EDE2   --cream #F6F1D8   --ink    #151311   --mute  #9A948A
--blue   #93B0CB   (deepen to #6F8FB0 under cream type, for contrast)
--cobalt #2348C8   --signal #EF5122  --lime   #C9F23F (the "toxic" colour)
--khaki  #E6DBB8   --char  #1C1D21   corkboard #3A2E25   binder-dark #22232A
```

| Type token (1440×1080) | px | Family |
| --- | --- | --- |
| mega | 300–330 | Oswald 700 caps (stand-in for Anton) or the serif italic |
| h1 | 200–270 | Playfair Display 400 (stand-in for DM Serif Display) |
| h2 | 130–170 | serif / serif italic |
| h3 | 100–120 | Oswald 700 caps |
| label | 40–48 | Inter 300 + 800 mix |
| body | 30–34 | Inter 700 |
| micro | 16–20 | JetBrains Mono 600, +22% tracking, caps: mark `data-layout-ignore` (texture, not reading) |

At most 3 sizes per frame. The most emotional word of the line gets h1 or mega. Fonts: Playfair Display, Oswald, Inter and JetBrains Mono ship with HyperFrames. DM Serif Display and Anton (used in the storyboard) need `@font-face` files in `assets/fonts/`.

**Layout**:
- 12 columns, 72 px margin, 24 px gutter, 8 px baseline.
- The header rule sits at y≈46, the footer at bottom 40.
- Landscape: type stacks on the left half or the top band; props sit right or bottom.

**Shadow** (every cutout): `drop-shadow(0 4px 3px rgba(20,15,10,.2)) drop-shadow(0 22px 26px rgba(20,15,10,.24))`

**Textured surfaces** (CSS only):
- orange grid mat: `linear-gradient` lines every 36 px at 28% white;
- pinstripes: a 2 px line every 96 px;
- checkerboard: `repeating-conic-gradient` 64 px;
- halftone dots: an 8 px radial pattern;
- ring-binder sheet: a grid strip, a metal bar and rings.

## Frame patterns that worked (Toxic)

| Moment | Ground | Layout |
| --- | --- | --- |
| Title | paper | serif-italic kicker → mega word on a lime block → bold tagline → outlined CTA; hero bottle on an orange mat; blurred corner props |
| Instrumental | pinstripes | hero object centred; 4 numbered badges with dashed connectors to secondary props (one per beat); a dark pill hinting the first line |
| Tender line | dusty blue | menu-bar text; huge cream roman + dark italic; a hand rising, holding a torn note |
| List-like line | cream | left serif stack, one word in a deep accent italic; a tilted hero prop on the right; a small centred translation |
| Contrast line (day/night) | split orange / cobalt | two grotesk words facing off; paper sun and paper moon |
| Breath / intimate | charcoal + torn sheet | light/bold sans kicker; serif words; blue speech pill; a candle with its flame on its own layer |
| Repeated word ×3 | three full-width colour bands, or stickers on a mat | the stack builds on each hit |
| Chorus hook | paper | grotesk line + mega word on a lime block; the poison bottle; checkerboard corner |
| Poet / writing | khaki | serif + giant accent italic; a typewriter whose sheet types the line |
| Memory / loss | dark + binder sheet | a polaroid that tears on the negative word |
| English line | cream | a record spinning, the lyric running on a circular path, objects orbiting |
| Fire | orange grid mat | grotesk + mega word on a cream block; a matchbox under a magnifier |
| Conspiracy | corkboard + halftone | the heart pinned in the centre, notes thrown and wired with red string |
| Ending | split cream / blue | the last question word crosses the split; hold, then fade to black |
