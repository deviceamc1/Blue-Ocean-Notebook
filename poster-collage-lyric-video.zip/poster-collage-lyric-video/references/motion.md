# Motion

All helpers live in `templates/build.py` (the `JS` block) and run on one paused GSAP timeline per scene. `T[i]` is the sung time of word i, local to the scene.

## Presets

| Preset | Move | Duration / ease | Use |
| --- | --- | --- | --- |
| FLY | from 900–1600 px off-frame on a seeded heading, rotation ±45°, scale 1.7 → 1 | 0.32 s `expo.out`, starts 0.1 s early | most words |
| SLAM | scale 3–3.6 → 1, opacity 0 → 1 | 0.12–0.2 s `power4.out` | the hit word of a line; follow with SHAKE |
| RISE | yPercent 118 → 0 inside a `.mk` overflow mask | 0.26 s `power4.out` | calm serif words |
| BLUR | blur 10 → 0, opacity 0 → 1 in place | 0.13–0.15 s | quiet kickers, translations |
| INK | colour from 16% ink to ink, no movement, 0.07 s apart | 0.12 s | taglines, translations |
| SCATTER | letters from all over the frame, rotation ±130°, one frame apart | 0.32–0.5 s `expo.out` | hero words (TOXIC, mutaasir) |
| RUN | letters streak in from one side, one frame apart | 0.3 s `expo.out` | "runnin" |
| TYPE | characters switch on one by one at 0.03 s | — | typewriter sheets, mono headers |
| DROP | prop y −900 → 0, rotation +16° → final, scale 1.08 → 1 | 0.55 s `back.out(1.25)` | every hero prop |
| POP | scale 0 → 1, rotation −24° → final | 0.22 s `back.out(3)` | pins, badges, pills, stickers |
| WIPE | highlight block scaleX 0 → 1 from the left | 0.2–0.26 s `power3.inOut` | lime/cream blocks behind words |
| DRAW | stroke-dashoffset 110 → 0 on `pathLength=100` | 0.26–0.32 s | red strings; dashed connectors (via a mask path) |
| SHAKE | 4 keyframes ±8–16 px | 0.13 s | the page reacts to a hit |
| OUT | everything leaves together, staggered 0.003–0.015 s | 0.15–0.2 s `power3.in` | exits |
| FLOOD | clip-path inset from an object's rectangle to the full frame | 0.34–0.44 s `power3.in` | object becomes the world |
| UNFLOOD | the arriving ground recedes from the full frame | 0.36–0.42 s | the other half of a flood |

## Type-technique bank (act out the word)

| Word idea | Technique (Toxic example) |
| --- | --- |
| A title / a label | SCATTER letters, then a lime WIPE (TOXIC) |
| Something falling or held | letters fall from above, a frame apart, ±18° (Kaafi) |
| Unsure / a mispronounced word | slot-machine roll through spellings inside a 1-line mask, stopping on the right one (FARQ → FARK → FURAK → FARAK) |
| Breath | each letter inhales (scale 0 → 1.35) then exhales to 1, 0.05 s apart, with the candle flame stretching in time (saasen) |
| Writing / a poet | clip-path ink reveal left → right while a quill flies in and dips (kavi); a typewriter sheet types the whole line in sync |
| Running | RUN letters from the left with heavy motion blur (runnin) |
| Around / circling | each letter swings in around a pivot far below it (`transformOrigin: 50% 380%`, −200° → 0) (around); the lyric also runs around a circular textPath |
| Fire | letters ignite: opacity 0 → 1 → 0.2 → 1 flicker with scale 1.25 → 1, then a cream WIPE and a flame glow (AATISH) |
| Dripping / spilling | letters drop with `back.out(2.2)` and bounce (toxic, 2nd chorus) |
| A question across a divide | letters fly in from both halves of a split and meet; the "?" pops last (kyu?) |
| Conspiracy | notes are thrown at the board, PINned, and wired to the heart with DRAW strings (saazish is ink-revealed) |
| Repeated word ×3 | ONE slide: each hit slams a band or sticker into the stack, with a punch and a shake; numbered badges count 1-2-3 |

## Transitions used (each caused on screen)

1. **Label floods the frame**: the lime block behind TOXIC → a full lime frame → the next scene UNFLOODs to its own ground.
2. **Whip**: everything OUTs up, right or left with motion blur, and the next scene enters moving the same way.
3. **Note becomes the page**: a torn note's rectangle floods to cream, which becomes the next poster's paper.
4. **Iris**: the frame closes onto the moon in the next ground colour (`clip-path: circle()`).
5. **Dip cut**: a 42% black overlay for the last 3 frames, then a hard cut onto the Kyu hits.
6. **Typed sheet → binder sheet**: the sheet floods white, then shrinks onto the binder (UNFLOOD to the sheet rectangle).
7. **Record label → mat**: a circle clip grows from the record's red label into the orange mat.
8. **Spill floods**: the lime spill rectangle floods, then the next scene wipes lime away to reveal its orange.
9. **Zoom through the lens**: the magnifier scales 7× around the lens centre and the lens interior becomes the next ground.

## GSAP rules that matter here

- Use `fromTo` for every entrance; it renders the from-state at time 0, so elements wait off-frame. Only one `fromTo` per element per property; later moves are `.to`.
- No CSS `transform` on anything GSAP moves. Static tilt goes in the tween's end `rotation`.
- Static positions use CSS `left`/`top`; motion uses x/y/scale/rotation only.
- Counter-rotate orbiting objects: a full-size wrapper rotates and the child rotates by the negative of that angle, so the object stays upright.
- Seeded random only (`_s = (_s * 16807) % 2147483647`); never `Math.random()`.
- Timing reads from `plan.json` inside `build.py`, so re-running the build after a timing change keeps every word in sync.
