// AI layoffs in India — storyboard / example for Editing Style 1 v3 (v2 edit + interactive UI).
// 16:9 split-panel edit: full-screen hook with subtitles, then the black left panel fills with screens
// that alternate dark / light. Captions, wipes, clippings, stamps: Editing Style 1 v2.
// Every object in the visual area is UI from interactive-ui-reels (slabs, rolling figures, segmented
// controls, bars, toasts, checklists, a demo cursor, an island).
// Run: node build.mjs → index.html   (work/transcript.json optional: without it words are spaced 0.26 s)
import fs from "node:fs";

const END = 63;
const FPS = 30;
const f = (t) => Math.round(t * FPS) / FPS;
const SPLIT_IN = f(4.0); // first split frame in the cut
const WIDEN = null; // set to the frame where the cut's black panel widens, if it does
const TITLE = "AI layoffs in India";
const TAG = null; // e.g. { name: "Nikhil Kamath", role: "CO-FOUNDER, ZERODHA", in: 2.6, out: 5.5 }
const words = fs.existsSync("work/transcript.json") ? JSON.parse(fs.readFileSync("work/transcript.json", "utf8")).words : [];
const norm = (s) => s.toLowerCase().replace(/[^a-z0-9$]/g, "");

// ---------- media ----------
const svgInner = (src) => src.replace(/<!--[\s\S]*?-->/g, "").replace(/^[\s\S]*?<svg[^>]*>/, "").replace(/<\/svg>\s*$/, "").replace(/<title>[\s\S]*?<\/title>/, "");
const ICONS = {};
for (const n of fs.readdirSync("assets/icons")) ICONS[n.replace(".svg", "")] = svgInner(fs.readFileSync(`assets/icons/${n}`, "utf8"));
const LOGOS = {};
for (const n of fs.readdirSync("assets/logos")) LOGOS[n.replace(".svg", "")] = svgInner(fs.readFileSync(`assets/logos/${n}`, "utf8"));
const icon = (n, s, sw = 1.6) => {
  if (!ICONS[n]) throw new Error("icon " + n);
  return `<svg class="ic" width="${s}" height="${s}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="${sw}" stroke-linecap="round" stroke-linejoin="round">${ICONS[n]}</svg>`;
};
const logo = (n, s) => {
  if (!LOGOS[n]) throw new Error("logo " + n);
  return `<svg class="lg" width="${s}" height="${s}" viewBox="0 0 24 24" fill="currentColor" fill-rule="evenodd">${LOGOS[n]}</svg>`;
};

// ---------- v2 editorial blocks (absolute, screen px) ----------
const box = (x, y, w, h) => `left:${x}px;top:${y}px;width:${w}px;height:${h}px`;
const card = (id, x, y, w, h, art, lab, extra = "") => `<div class="card" id="${id}" style="${box(x, y, w, h)}"><div class="art">${art}</div>${lab ? `<div class="lab">${lab}</div>` : ""}${extra}</div>`;
const big = (id, x, y, w, text, size, weight = 900) => `<div class="big" id="${id}" style="left:${x}px;top:${y}px;width:${w}px;font-size:${size}px;font-weight:${weight}">${text}</div>`;
const stamp = (id, x, y, text, size = 64) => `<div class="stamp" id="${id}" style="left:${x}px;top:${y}px;font-size:${size}px">${text}</div>`;
const clip = (id, x, y, w, c) => `<div class="clip" id="${id}" style="left:${x}px;top:${y}px;width:${w}px">
  <div class="ck"><span>${c.kicker}</span><span>${c.date}</span></div>
  <div class="ch">${c.head}</div>${c.sub ? `<div class="cs">${c.sub}</div>` : ""}
  <div class="cl"><i></i><i></i><i style="width:62%"></i></div>
  <div class="cf">${c.source}</div></div>`;

// ---------- UI blocks (authored at web size, presented with zoom) ----------
// ui(): centre a w1-wide component (1× px) in the panel at `top`, scaled by z. Returns the wrapper.
const ui = (id, W, w1, z, top, inner, dx = 0) => `<div class="ui" id="${id}" style="left:${Math.round((W - w1 * z) / 2 / z + dx)}px;top:${Math.round(top / z)}px;width:${w1}px;zoom:${z}">${inner}</div>`;
// at(): place a w1-wide component at an absolute panel x (screen px)
const uiAt = (id, x, w1, z, top, inner) => `<div class="ui" id="${id}" style="left:${Math.round(x / z)}px;top:${Math.round(top / z)}px;width:${w1}px;zoom:${z}">${inner}</div>`;
// roll(): a figure whose changed digits roll (keyed by place from the right)
const roll = (id, from, to, cls = "ui-fig") => {
  const n = Math.max(from.length, to.length), A = from.padStart(n, " "), B = to.padStart(n, " ");
  let h = "";
  for (let i = 0; i < n; i++) {
    const a = A[i].trim(), b = B[i].trim(), d = /\d/.test(a) || /\d/.test(b);
    h += `<span class="ui-slot${d ? " d" : ""}"${a !== b ? " data-c" : ""}><span class="sz">${a || b}</span><span class="o">${a}</span><span class="n">${b}</span></span>`;
  }
  return `<span class="${cls} tab ui-roll" id="${id}">${h}</span>`;
};
const seg = (id, labels, on = 0) => `<div class="ui-seg" id="${id}"><span class="ui-seg-th" style="width:calc(${100 / labels.length}% - ${4 / labels.length}px)"></span>${labels.map((l, i) => `<b class="${i === on ? "on" : ""}">${l}</b>`).join("")}</div>`;
const bars = (id, rows) => `<div class="ui-brows" id="${id}">${rows.map(([lab, val, color]) => `<div class="ui-brow"><span class="ui-blab">${lab}</span><span class="ui-track"><span class="ui-fill"${color ? ` style="background:${color}"` : ""}></span></span><span class="ui-bval">${val}</span></div>`).join("")}</div>`;
const chip = (id, text, dot) => `<span class="ui-chip" id="${id}">${dot ? `<i style="background:${dot}"></i>` : ""}${text}</span>`;
const glyph = (d, s = 13) => `<svg width="${s}" height="${s}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round">${d}</svg>`;
const G = { check: '<path d="M5 12.5l4.5 4.5L19 7.5"/>', alert: '<path d="M12 8v5"/><path d="M12 17h.01"/>', mail: '<rect x="3" y="5" width="18" height="14" rx="2"/><path d="m3 7 9 6 9-6"/>', users: '<path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87"/>' };
const toast = (id, g, color, title, sub, act) => `<div class="ui-toast" id="${id}" style="opacity:0"><span class="ui-ic" style="background:color-mix(in srgb, ${color} 22%, transparent);color:${color}">${glyph(g)}</span><span class="ui-tx"><b>${title}</b><span>${sub}</span></span>${act ? `<span class="ui-act">${act}</span>` : ""}</div>`;
const crow = (id, text, tag) => `<div class="ui-crow" id="${id}"><span class="ui-cbox"><span class="ui-cfill"></span><svg class="ui-ctick" viewBox="0 0 24 24"><path d="M5 12.5l4.5 4.5L19 7.5" pathLength="1"/></svg></span><span class="ui-csay">${text}<span class="ui-crule"></span></span>${tag ? `<span class="ui-tag">${tag}</span>` : ""}</div>`;
const cursor = (id) => `<svg class="ui-cursor" id="${id}" viewBox="0 0 24 24"><path d="M5.5 3.21V20.8c0 .45.54.67.85.35l4.86-4.86a.5.5 0 0 1 .35-.15h6.87a.5.5 0 0 0 .35-.85L6.35 2.85a.5.5 0 0 0-.85.35Z"/></svg>`;

// ---------- screens ----------
// chunks: [text, t]. {braces} = key phrase, bold only (never a highlight box).
// beats: [type, selector, t, ...args] — see references/beats.md.
const S = [];
const add = (s) => S.push(s);

// F2 · DARK — TCS cut 12,000 jobs (first split frame: hard cut)
add({ id: "s1", theme: "dark", start: SPLIT_IN, cut: true, shot: 8.9,
  vo: "In July 2025, TCS, India's biggest IT company, said it would cut about 12,000 jobs — around 2% of its workforce.",
  chunks: [["In July 2025, {TCS}", 4.3], ["cut {12,000 jobs}", 5.7], ["about {2%} of its people", 7.1]],
  html: (W) => ui("s1-ui", W, 340, 2.4, 400, `<div class="ui-slab">
      <div class="ui-head"><span class="ui-title">Tata Consultancy Services</span><span class="ui-label">FY26</span></div>
      <div class="ui-figrow"><span class="ui-fig tab" id="s1-n">0</span><span class="ui-unit">roles cut</span></div>
      <div class="ui-meter" id="s1-m"><span class="ui-mseg" style="flex-grow:2;background:var(--k-pink)"></span><span class="ui-mseg" style="flex-grow:98;background:var(--ui-empty)"></span></div>
      <div class="ui-chips">${chip("s1-c1", "~2% of workforce", "var(--k-pink)")}${chip("s1-c2", "Mostly mid &amp; senior grades")}</div></div>`),
  beats: [["uin", "#s1-ui", 4.35], ["meter", "#s1-m", 4.7], ["count", "#s1-n", 5.75, 1.1, 0, 12000, "inr"], ["ink", "#s1-c1", 7.3]] });

// F3 · LIGHT — "skill mismatch, not AI" (clipping + segmented control pressed by the cursor)
add({ id: "s2", theme: "light", start: 10.4, shot: 14.6,
  vo: "Its CEO said the cuts were about skill mismatch, not AI.",
  chunks: [["The CEO said", 10.8], ["{skill mismatch,}", 11.9], ["{not AI}", 13.1]],
  html: (W) => clip("s2-c", 60, 400, 470, { kicker: "Business", date: "Jul 27, 2025", head: "TCS to cut about 12,000 jobs, 2% of its workforce", sub: "CEO K. Krithivasan: “skill and capability based.”", source: "As reported by Reuters, Business Today" }) +
    uiAt("s2-ui", 580, 220, 2.0, 470, `<div class="ui-slab"><div class="ui-label">Official reason</div><div style="height:10px"></div>${seg("s2-seg", ["AI", "Skills"], 0)}<div style="height:12px"></div><div class="ui-sub">Per TCS, July 2025</div>${cursor("s2-cur")}</div>`) +
    stamp("s2-st", 640, 800, "Not AI?", 70),
  beats: [["clip", "#s2-c", 11.0, -2.5], ["uin", "#s2-ui", 11.3], ["press", "#s2-cur", 12.3, 60, 120, 168, 66, "#s2-seg"], ["seg", "#s2-seg", 12.3, 0, 1], ["stamp", "#s2-st", 13.4, -6]] });

// F4 · DARK — the top five shrank (segmented FY25 / FY26, figure counts through zero, bars)
add({ id: "s3", theme: "dark", start: 16.4, shot: 21.0,
  vo: "But across India's top five IT firms, net headcount fell by 7,389 in FY26 — after adding 12,718 the year before.",
  chunks: [["But the {top five}", 16.8], ["IT firms {shrank}", 18.1], ["by {7,389 people}", 19.4]],
  html: (W) => ui("s3-ui", W, 360, 2.3, 390, `<div class="ui-slab">
      <div class="ui-head"><span class="ui-title">Top 5 IT firms · net hiring</span>${seg("s3-seg", ["FY25", "FY26"], 0)}</div>
      <div class="ui-figrow"><span class="ui-fig tab" id="s3-n">+12,718</span><span class="ui-unit">people</span></div>
      ${bars("s3-b0", [["FY25", "+12,718", "var(--ui-ok)"]])}<div style="height:10px"></div>${bars("s3-b1", [["FY26", "−7,389", "var(--ui-err)"]])}
      <div class="ui-hair"></div><div class="ui-sub">TCS · Infosys · HCLTech · Wipro · Tech Mahindra — IANS, Apr 2026</div>${cursor("s3-cur")}</div>`),
  beats: [["uin", "#s3-ui", 16.75], ["grow", "#s3-b0", 17.2, [100]], ["press", "#s3-cur", 18.3, 120, 150, 328, 40, "#s3-seg"], ["seg", "#s3-seg", 18.3, 0, 1], ["count", "#s3-n", 18.35, 1.1, 12718, -7389, "signed"], ["grow", "#s3-b1", 18.5, [58]]] });

// F5 · LIGHT — freshers feel it first (bars + rolling figure 40,000 → 25,000)
add({ id: "s4", theme: "light", start: 22.4, shot: 26.6,
  vo: "Freshers feel it first: TCS plans to hire around 25,000 graduates in FY27, down from 40,000 or more a year.",
  chunks: [["{Freshers} feel it", 22.8], ["{first}", 23.8], ["{25,000} hires, not 40,000", 24.6]],
  html: (W) => ui("s4-ui", W, 340, 2.4, 400, `<div class="ui-slab">
      <div class="ui-head"><span class="ui-title">TCS fresher hiring</span><span class="ui-label">per year</span></div>
      <div class="ui-figrow">${roll("s4-n", "40,000", "25,000")}<span class="ui-unit">graduates</span></div>
      ${bars("s4-b", [["Recent years", "40,000+"], ["FY27 plan", "~25,000"]])}
      <div class="ui-hair"></div><div class="ui-sub">IANS, CNBC — Apr 2026</div></div>`),
  beats: [["uin", "#s4-ui", 22.75], ["grow", "#s4-b", 23.2, [100, 62.5]], ["roll", "#s4-n", 24.7, false]] });

// F6 · DARK — AI does the junior work (illustrative checklist)
add({ id: "s5", theme: "dark", start: 28.4, shot: 33.6,
  vo: "Why? A lot of entry-level work — tests, routine fixes, documentation, ticket triage — is now done with AI tools.",
  chunks: [["AI now does", 28.8], ["the {junior work}", 29.8]],
  html: (W) => ui("s5-ui", W, 330, 2.4, 380, `<div class="ui-slab">
      <div class="ui-head"><span class="ui-title">Junior dev · this week</span><span class="ui-tag" style="margin-left:0">Illustrative</span></div>
      <div style="height:6px"></div>
      ${crow("s5-r0", "Write unit tests", "AI")}${crow("s5-r1", "Fix routine bugs", "AI")}${crow("s5-r2", "Draft documentation", "AI")}${crow("s5-r3", "Triage support tickets", "AI")}</div>`),
  beats: [["uin", "#s5-ui", 28.75], ["check", "#s5-r0", 30.3], ["check", "#s5-r1", 31.0], ["check", "#s5-r2", 31.7], ["check", "#s5-r3", 32.4]] });

// F7 · LIGHT — yet the sector still grew (rolling 58.2 → 59.5 lakh + stamp)
add({ id: "s6", theme: "light", start: 34.4, shot: 39.0,
  vo: "Yet the sector as a whole still grew: Nasscom counts 59.5 lakh tech workers, up 2.3%.",
  chunks: [["Yet the sector", 34.8], ["{still grew}", 35.8], ["to {59.5 lakh} people", 36.9]],
  html: (W) => ui("s6-ui", W, 340, 2.4, 400, `<div class="ui-slab">
      <div class="ui-head"><span class="ui-title">India tech workforce</span><span class="ui-label">Nasscom · FY26</span></div>
      <div class="ui-figrow">${roll("s6-n", "58.2", "59.5")}<span class="ui-unit">lakh people</span></div>
      <div class="ui-chips" style="margin-top:0">${chip("s6-c1", "+1.35 lakh added", "var(--ui-ok)")}${chip("s6-c2", "+2.3%")}</div>
      <div class="ui-hair"></div><div class="ui-sub">As reported by IANS, Apr 2026</div></div>`) +
    stamp("s6-st", 300, 880, "Big five ≠ sector", 46),
  beats: [["uin", "#s6-ui", 34.75], ["roll", "#s6-n", 36.0, true], ["ink", "#s6-c1", 37.0], ["stamp", "#s6-st", 37.8, -5]] });

// F8 · DARK — 10–15 million people; Bernstein's warning (toast stack)
add({ id: "s7", theme: "dark", start: 40.4, shot: 47.6,
  vo: "This matters: 10 to 15 million people in IT services and BPO built India's middle class. Bernstein has warned the Prime Minister that generative AI challenges that template.",
  chunks: [["{10–15 million} people", 40.8], ["built India's {middle class}", 42.0], ["{Bernstein} warned the PM", 43.9]],
  html: (W) => ui("s7-ui", W, 340, 2.6, 440, `<div style="position:relative;height:150px">
      ${toast("s7-t0", G.users, "var(--ui-ok)", "10–15 million people", "IT services &amp; BPO · two decades", "")}
      ${toast("s7-t1", G.mail, "#9a9a9a", "Open letter to PM Modi", "Bernstein · employment warning", "Read")}
      ${toast("s7-t2", G.alert, "var(--ui-warn)", "“Gen AI now challenges that template”", "Bernstein, via CNBC", "")}</div>
      <div class="ui-sub" style="margin-top:6px">As reported by CNBC, Apr 2026</div>`),
  beats: [["toast", "#s7-t0", 41.0, []], ["toast", "#s7-t1", 44.1, ["#s7-t0"]], ["toast", "#s7-t2", 45.5, ["#s7-t1", "#s7-t0"]]] });

// F9 · LIGHT — THE TAKEAWAY (checklist for the viewer)
add({ id: "s8", theme: "light", start: 49.4, shot: 55.6,
  vo: "So what's the takeaway? Build with AI, not against it: ship with AI tools, go deep in one domain, and learn to review what AI writes.",
  chunks: [["So, what's the", 49.8], ["{takeaway?}", 50.6], ["Build {with AI,}", 51.9], ["not {against it}", 53.0]],
  html: (W) => ui("s8-ui", W, 330, 2.4, 400, `<div class="ui-slab">
      <div class="ui-head"><span class="ui-title">Your next 90 days</span><span class="ui-label tab" id="s8-k">3 steps</span></div>
      <div style="height:6px"></div>
      ${crow("s8-r0", "Ship one project with AI tools")}${crow("s8-r1", "Go deep in one domain")}${crow("s8-r2", "Learn to review AI’s output")}</div>`),
  beats: [["uin", "#s8-ui", 51.3], ["check", "#s8-r0", 52.2], ["check", "#s8-r1", 53.2], ["check", "#s8-r2", 54.2]] });

// F10 · DARK — CTA (island + v2 cards restyled as UI)
add({ id: "s9", theme: "dark", start: 57.4, shot: 61.6,
  vo: "Is your role next? Tell me in the comments, and share this with someone in IT.",
  chunks: [["Is your role {next?}", 57.8], ["Tell me in the {comments}", 59.0]],
  html: (W) => `<div class="ui" style="left:0;top:0;zoom:2;width:540px"><div class="ui-island" id="s9-i" style="left:95px;top:200px;width:350px;height:64px"><span style="width:36px;height:36px;border-radius:50%;background:#ff9f0a3d;color:#e09a12;display:grid;place-items:center">${glyph(G.alert, 16)}</span><span style="display:flex;flex-direction:column;gap:2px"><span style="font-size:11px;color:#ffffff8c">Up next</span><span style="font-size:17px;font-weight:500;letter-spacing:-0.02em">Which IT roles are safest?</span></span></div></div>` +
    card("s9-c", 90, 600, 270, 300, icon("message-square", 110), "Comment") + card("s9-s", 405, 600, 270, 300, icon("share-2", 110), "Share") + card("s9-f", 720, 600, 270, 300, icon("users", 110), "Follow"),
  beats: [["island", "#s9-i", 57.9, 126, 37], ["pop", "#s9-c", 58.2], ["pop", "#s9-s", 58.35], ["pop", "#s9-f", 58.5], ["lit", "#s9-c", 59.6]] });

// ---------- subtitles over the full-screen footage (F1 · hook) ----------
const CAPS = [["Is AI quietly taking", 0.3], ["India’s IT jobs?", 1.7, SPLIT_IN]];

// ---------- assemble ----------
function timeWords(text, t0) {
  let cur = words.findIndex((w) => w.start >= t0 - 0.06);
  if (cur < 0) cur = words.length;
  let prev = t0 - 0.26;
  const out = [];
  for (const raw of text.replace(/[{}]/g, "").split(" ")) {
    const n = norm(raw);
    let hit = -1;
    for (let j = cur; j < Math.min(cur + 8, words.length); j++) if (norm(words[j].text) === n || (n.length > 3 && norm(words[j].text).startsWith(n))) { hit = j; break; }
    let t = hit >= 0 ? words[hit].start : prev + 0.26;
    if (hit >= 0) cur = hit + 1;
    t = Math.max(t, prev + 0.06);
    out.push(t); prev = t;
  }
  return out;
}

const chunkSpec = [];
function chunksHtml(s, W) {
  if (!s.chunks.length) return "";
  let html = `<div class="chunks" style="width:${W}px">`;
  s.chunks.forEach(([text, t0], ci) => {
    const times = timeWords(text, t0);
    let wi = 0, inMark = false, markIdx = 0;
    const plain = text.replace(/[{}]/g, "");
    const size = plain.length > 24 ? 70 : plain.length > 16 ? 80 : 92;
    const cid = `${s.id}-k${ci}`;
    let inner = "";
    for (const tok of text.split(" ")) {
      const open = tok.startsWith("{"), close = /}[,.?!]?$/.test(tok);
      let w = tok;
      if (open) { inMark = true; inner += `<span class="mk" id="${cid}-m${markIdx++}">`; w = w.slice(1); }
      const trail = w.match(/}(.*)$/);
      const core = w.replace(/}.*$/, "");
      inner += `<span class="w${inMark ? " on" : ""}" data-t="${times[wi].toFixed(2)}">${core}</span>`;
      if (close && inMark) { inner += `</span>`; inMark = false; if (trail && trail[1]) inner += `<span class="w" data-t="${times[wi].toFixed(2)}">${trail[1]}</span>`; }
      wi++;
    }
    html += `<div class="chunk" id="${cid}" style="font-size:${size}px">${inner}</div>`;
    const next = s.chunks[ci + 1];
    chunkSpec.push({ sel: "#" + cid, leave: next ? timeWords(next[0], next[1])[0] : null });
  });
  return html + "</div>";
}

const screenSpec = [];
let screens = "";
S.forEach((s, i) => {
  const W = WIDEN && s.start >= WIDEN - 0.001 ? 1110 : 1080;
  const next = S[i + 1];
  s.end = next ? (next.cut ? next.start : next.start + 0.5) : END;
  screens += `<div class="scr ${s.theme}" id="${s.id}" style="width:${W}px"><div class="push" id="${s.id}-push" style="transform-origin:${W / 2}px 620px">
    <div class="frame"><i class="c tl"></i><i class="c tr"></i><i class="c bl"></i><i class="c br"></i></div>
    ${chunksHtml(s, W)}${s.html(W)}</div></div>\n`;
  screenSpec.push({ id: s.id, start: s.start, end: s.end, cut: !!s.cut, theme: s.theme, beats: s.beats });
});

const caps = CAPS.map(([t], i) => `<div class="cap" id="cap${i}"><span class="ph">${t}</span></div>`).join("");
const tagHtml = TAG ? `<div id="tag"><b>${TAG.name}</b><span>${TAG.role}</span></div>` : "";

const tpl = fs.readFileSync("template.tmpl", "utf8");
const out = tpl
  .replace("__TITLE__", TITLE)
  .replace("__RES__", "landscape").replaceAll("__W__", "1920").replaceAll("__H__", "1080").replaceAll("__PH__", "1080")
  .replace("__CT__", "96").replace("__CHH__", "250").replace("__ACCENT__", "#3d7ef5").replace("__AUDIO__", "")
  .replace("__MEDIA__", '      <video id="src" src="media/source.mp4" muted playsinline data-start="0" data-duration="' + END + '" data-track-index="0"></video>')
  .replaceAll("__END__", String(END))
  .replace("__SCREENS__", screens)
  .replace("__CAPS__", caps)
  .replace("__TAG__", tagHtml)
  .replace("__DATA__", JSON.stringify({ END, SPLIT_IN, WIDEN, TAG, screens: screenSpec, chunks: chunkSpec, caps: CAPS.map(([, t, e], i) => [t, e ?? (CAPS[i + 1] ? CAPS[i + 1][1] : SPLIT_IN)]) }));
fs.writeFileSync("index.html", out);
// storyboard sheet data: one frame per screen (+ the hook) at its settled moment
const board = [{ id: "hook", theme: "full", t: 2.6, vo: "Is AI quietly taking India's IT jobs?", caption: CAPS.map((c) => c[0]).join(" ") },
  ...S.map((s) => ({ id: s.id, theme: s.theme, t: s.shot, start: s.start, end: s.end, vo: s.vo, caption: s.chunks.map((c) => c[0].replace(/[{}]/g, "")).join(" / ") }))];
fs.mkdirSync("work", { recursive: true });
fs.writeFileSync("work/board.json", JSON.stringify(board, null, 1));
console.log("index.html written:", S.length, "screens,", chunkSpec.length, "chunks; shots at", board.map((b) => b.t).join(","));
