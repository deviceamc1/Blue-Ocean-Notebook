# SaaS explainer motion (studied 2026-11-05)

Learned frame by frame from four reference explainers the creator supplied (a 60 fps "Feature Animation Breakdown" of an icon-library promo, an AI-video-tool launch, a flow-diagram ad tool, and an "Auto Pilot" inbox product). This is the motion layer of Editing Style 1 v3: it decides **how things move and how scenes are composed**; `ui.md` decides how the objects look; the v2 rules (captions bold-only, clippings, facts) still hold.

## 1. Structure: the five acts

Every reference follows the same arc, labelled on the breakdown's own timeline:

| Act | Share | What happens | Typical beats |
| --- | --- | --- | --- |
| **Hook** (HK) | 8–12 % | One typed question over a cloud of real-looking UI cards flying in around it | `type`, `fly` |
| **Reveal** (RV) | 5–8 % | "Meet …" then the name/mark resolves letter by letter while a brand swell rises | `spell`, `swell`, `cam` |
| **Features** | 55–65 % | The product itself on a tilted 3D screen; the camera drifts, a cursor clicks, each feature gets a pill or a morph | `cam` (3D), `press`, `morph`, `seed`, `share`, `stair`, `listgo` |
| **Result** (RS) | 10–15 % | Three short benefit lines, each with its own geometric motif (rings, a wedge, an orbit) | `spell`, `orbit`, `morph` |
| **CTA** | 6–10 % | Mark + URL / "comment" + a cursor click | `spell`, `press` |

Map a topic explainer the same way: hook question → the "reveal" is the subject → features = the evidence → result = the takeaway → CTA.

## 2. The camera is always moving

- Nothing is ever locked off. Every scene has a slow continuous camera on a wrapper: push-in 1.00 → 1.06–1.12, or pull-out 1.25 → 1.0 while text types, over the whole shot, `sine.inOut` / `power1.inOut`.
- **UI is shown on a tilted screen**: perspective ≈ 1600–2000 px, rotateX 14–24°, rotateY −8…−14°, rotateZ −4…−8°, a thick soft white rim and one big soft ambient shadow. The camera eases the tilt **towards flat** when it wants you to read (≈ 0.9 s, `power3.inOut`), and away again when it moves on.
- The camera **follows the new thing**: when content is added to the right (a new card), the whole composition pans left so the action stays near centre (v3 reference: hub card exits left as the output card grows).
- Scroll is a camera move too: the page translates up inside a fixed tilted frame.

## 3. Type is performed

- **Typewriter hook**: 18–22 characters / s; a thin caret; the line stays **centred while it grows** (both edges move); **the newest characters are in the brand colour and settle to ink over ≈ 0.35 s**, so a coloured "wake" trails the caret. Replacing a line is a hard clear, then type again.
- **Letter resolve** (logos, short pills, result lines): letters arrive left → right 25–35 ms apart from opacity 0, blur 6–10 px and a wider tracking (each letter offset outward), easing to tight; ≈ 0.6 s `expo.out`.
- **Zoom while typing**: the line starts big (scale 1.3–1.5) and the camera pulls out as it extends, so a short word fills the frame and the full sentence still fits.
- Grey → ink: words that are not the point resolve to a lighter grey; the key words land in ink or brand colour. (Still bold-only in captions — no boxes behind words.)

## 4. Morphs (the satisfying part)

Every morph keeps **one container alive** while its shape and contents change. Build it as an element at its largest size, animate its **clip-path `inset(… round r)`** between shapes (never width/height — no reflow, seek-safe), and cross-fade or re-type what is inside.

| Morph | Shape path | Timing | Seen in |
| --- | --- | --- | --- |
| **Dot → circle → pill** | 12 px dot → circle → pill whose width eases to fit the text being typed | pop 0.45 s (overshoot), width follows text 0.3 s steps | icon promo, "Browse from" → "5000+ open-source icons" |
| **Concentric rings** | 3–5 rings that are the same shape scaled outward by a gap, drawn in white with soft shadow, following the core morph with a 30–60 ms lag each | as the core | icon promo |
| **Toggle → card** | pill switch (knob on) → its track grows into a rounded card; the knob becomes the first inner glass card; a fill swaps flat blue → gradient | 0.5 s `expo.out` | Auto Pilot |
| **Dot → tile / thumbnail → card** | connector endpoint dot seeds into an app tile; a tiny portrait thumb grows into a landscape output card (aspect change) | 0.55–0.7 s | flow-diagram ad tool |
| **Text box hugs text** | a black box grows as words type into it, then the same box cross-fades into a video | 0.3 s per word step | AI video tool |
| **Shared element (FLIP)** | the clicked item lifts out of its grid, flies along a short arc and lands in the detail card that builds around it | 0.7 s `power3.inOut`, the card grows 0.1 s after landing | icon promo |
| **Highlight seed** | a small brand square appears, stretches into a highlight bar, the text wipes in over it, the check stamps | 0.25 + 0.35 + 0.2 s | AI video tool checklist |

## 5. Entrances, depth and layout

- **Fly-ins** for UI cards around a headline: from beyond the frame edge, 0.7–0.9 s `expo.out`, with a slight rotation that settles, and **depth blur**: far cards stay blurred 3–6 px and smaller; near cards are sharp. Parallax: far cards drift slower.
- **Stair cascade**: each new list item offsets right + down from the last (≈ 0.3 of its height), the camera re-centres the group as it grows.
- **Arrow chain**: pill → arrow → pill → arrow; each arrow draws, then the next pill seeds.
- **List-driven carousel**: a vertical list (inactive grey, active ink with a brand dot) drives a column of cards that scroll so the matching card is centred, 0.6 s `expo.inOut` per step.
- **Composition**: one subject centred with generous negative space; supporting cards at the edges, partly off-frame; thin layout guide lines (a design-canvas grid) may extend from card edges; soft brand **blobs** drift behind (two radial gradients, 10–18 % of the brand colour, blurred, moving slowly).
- Backgrounds stay light and airy in SaaS mode (mint, lime-white, cool grey); a dark scene is used for "inside the product" moments.

## 6. Transitions

- Mostly **hard cuts on the beat**, with the motion carried inside the shot (the next scene is already moving on its first frame).
- **Zoom-through** between ideas: the outgoing scene scales up 1.06–1.1 with blur 8–12 px and fades in 0.3 s (`power2.in`); the incoming starts at 0.92 with blur and lands sharp in 0.55 s (`expo.out`).
- Logo / benefit lines: **swell** — a brand gradient rises from the bottom as the mark resolves.
- Wipes are reserved for "next takeaway" moments (v2's wipe stays available).

## 7. Timing numbers (from the 60 fps reference)

- Entrances 0.4–0.6 s, `expo.out` or the overshoot ease; morphs 0.45–0.7 s; camera moves 0.8–3 s; holds after a beat ≥ 0.6 s.
- Stagger: letters 25–35 ms, cards 60–90 ms, list rows 90–120 ms.
- A new beat every 0.8–1.5 s inside a feature scene; nothing waits more than ~2 s without a change.

## 8. Beats that implement this (template runtime)

`type`, `spell`, `cam`, `morph`, `rings`, `seed`, `fly`, `share`, `stair`, `listgo`, `orbit` (= `draw` on an ellipse), `swell`, plus per-screen `tr: "zoom" | "wipe" | "cut"`. Arguments in `beats.md`.
