# UI on the panel

The objects in the visual area come from `interactive-ui-reels` (studied from bencho.dev). Its full design system — principles, motion, component recipes — lives in `~/.claude/skills/interactive-ui-reels/references/`; this file is how it sits on the v2 panel.

## Tokens (set per screen theme in `template.tmpl`)

| Token | Dark screen (#202020 grid) | Light screen (#f2f2ef paper) |
| --- | --- | --- |
| `--ui-slab` | #2b2b2b (one step above the ground) | #ffffff |
| `--ui-edge` (1 px hairline) | rgba(255,255,255,.10) | rgba(23,24,26,.10) |
| `--ui-wash` (tracks, chips, quiet controls) | rgba(255,255,255,.07) | rgba(23,24,26,.06) |
| `--ui-ink` / `--ui-ink2` / `--ui-muted` | #fff / #b4b4b4 / #8f8f8f | #17181a / #3c3b37 / #73726d |
| `--ui-empty` (meter remainder) | #3a3a3a | #ecebe7 |
| selected (`--ui-lit-bg` / `--ui-lit-fg`) | #fff / #000 | #17181a / #fff |
| meaning colours | ok #34d17a · err #e5484d · warn #e09a12 | ok #15803d · err #e5484d · warn #e09a12 |
| categories | pink #ec4f8c · violet #9a5cf6 · blue #3d7ef5 · cyan #1db4cc · green #2ccb7e | same |

Rules: colour only where it is the meaning; no glow, no drop shadow (depth is the hairline); corners concentric (slab 20 → control 10 → thumb 8, pills 999).

## Type inside the UI

Inter 500 for titles/labels/figures, 400 for running text, sentence case, tracking −0.01 em (titles) to −0.03 em (figures), `.tab` for tabular figures. Captions and subtitles stay Helvetica Now (v2). Nothing in the UI renders under ~28 px on the 1080 panel: at zoom 2.4 the smallest 12 px label becomes 29 px.

## Placing a component

Author at web size (a 300–360 px slab), present with `zoom`:

```js
ui(id, W, w1, zoom, top, innerHtml)      // centred in the panel
uiAt(id, x, w1, zoom, top, innerHtml)    // at an absolute panel x
```

Zoom 2.3–2.6 for one hero slab; 2.0 when it shares the screen with a clipping. Top 380–440 (under the caption band). Keep the bottom above ~1010 and the sides inside 36–1044.

## Components (helpers in `example-build.mjs`)

| Helper | What it is | Typical beats |
| --- | --- | --- |
| `.ui-slab` + `.ui-head` / `.ui-title` / `.ui-label` | the body of every component | `uin` |
| `.ui-figrow` + `.ui-fig` + `.ui-unit` | big tabular figure with a small grey unit | `count` (0 → N, signed, inr, lakh) or `roll` |
| `roll(id, from, to)` | figure whose changed digits roll | `roll` (up for growth, down for a fall) |
| `.ui-meter` of `.ui-mseg` | proportions as one bar of segments | `meter`, `focus` |
| `bars(id, rows)` | label · track · fill · value rows | `grow`, `regrow` |
| `seg(id, labels, on)` | segmented control | `press` + `seg` |
| `chip(id, text, dot)` | wash pill, optional colour dot | `ink` / `unink` |
| `toast(id, glyph, colour, title, sub, action)` | notification (stack oldest-first in markup) | `toast` |
| `crow(id, text, tag)` | checklist row | `check` |
| `cursor(id)` | demo cursor inside a slab | `press` |
| `.ui-island` | black pill that opens | `island` |
| v2 `card`, `badge`, `chip` (88 px), `layer`, `tile`, `step` | v2 objects in UI tokens | `pop`, `lit` / `unlit`, `step`, `wave`, `fall`, `win` |

## Sound (off by default)

The cut's own mix is final in this style. If the person asks for UI sounds, use `assets/sfx/*.wav` (24 MIT sounds from bencho.dev's free plan, rendered by `tools/render_sfx.py`) on a separate audio track mixed into the cut, one per visible action, transient one frame after the picture, 12–18 dB under the voice; map in `~/.claude/skills/interactive-ui-reels/references/sound.md`. Then the mux step changes: mix, don't `-c:a copy`, and say so.
