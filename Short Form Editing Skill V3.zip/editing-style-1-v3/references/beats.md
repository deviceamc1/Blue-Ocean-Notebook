# Beats

`[type, selector, t, ...args]` in a screen's `beats`. Times are absolute seconds on the cut.

## Edit / editorial (Editing Style 1 v2)

| Beat | Args | Does |
| --- | --- | --- |
| `drop` | — | falls in from 80 px above (`back.out(1.6)`) |
| `fade` | — | rises 24 px and fades in |
| `clip` | rotation | a clipping drops in, rotated |
| `stamp` | rotation | a stamp slams in from 1.9× |
| `draw` | duration, `"w"` for a width rule | strokes a `pathLength=1` line (and its arrowhead) |
| `count` | duration, from, to, fmt (`money`, `year`, `int`, `inr`, `lakh`, `signed`) | counts a figure's text |
| `spin` | duration, degrees | rotates an icon |
| `dim` | — | to 32 % |
| `shake` | — | five quick shakes |
| `settle` | — | 1.12 → 1 |
| `bars` | heights from[], to[] | v2 column chart (height tween) |
| `fill` | count | stars fill one by one |
| `step` | — | numbered step: number inverts, icon pops, text slides |
| `wave` | count | tiles invert in turn |
| `fall` | count, keep[] | all but the kept tiles fall away |
| `win` | keep[] | kept tiles grow |

## UI (interactive-ui-reels)

| Beat | Args | Does |
| --- | --- | --- |
| `pop` | — | arrives: y 24, scale .94, blur 3 → rest on the overshoot ease |
| `uin` | — | quieter arrival for a whole slab (settle ease) |
| `lit` / `unlit` | — | slab-coloured object inverts to the ink and back (0.16 s + a 4 % pulse) |
| `ink` / `unink` | — | wash-coloured chip inverts to the ink and back |
| `roll` | up (bool) | changed digits of a `roll()` figure roll, 70 ms apart |
| `seg` | from index, to index | segmented control thumb slides |
| `grow` | values[] (0–100) | bars fill, 60 ms apart |
| `regrow` | from[], to[] | bars re-divide (glide ease) |
| `meter` | — | meter segments rise from the baseline |
| `focus` | keep selector | everything matching the selector dims to 22 % except `keep` |
| `toast` | older selectors (newest first) | toast lands; older ones step back 12 px / 6 % and the next one's content hides |
| `check` | — | checklist row ticks: fill, tick draw, grey text, rule sweep |
| `press` | x1, y1, x2, y2, target | cursor appears, travels, presses; release (state change) at `t` |
| `island` | compact w, h | black pill opens from compact size by clip-path |

Order on a press: `["press", "#cur", t, …, "#target"]` then the state change at the same `t` (`seg`, `lit`, `check`…).

## SaaS explainer motion (references/saas-motion.md)

| Beat | Args | Does |
| --- | --- | --- |
| `type` | cps (≈20), blink seconds (−1 = hide caret at once) | typewriter on a `typeLine()`: caret, the line stays centred as it grows, newest letters in `--accent` settle to ink |
| `spell` | stagger (0.03), spread px | letters of a `spellWord()` resolve left → right out of blur and wide tracking |
| `unspell` | — | the word blurs out (before a morph swaps it) |
| `cam` | duration, from{}, to{}, ease | a camera move on a `.cam` / `.tilt` wrapper: scale, x, y, rotationX/Y/Z, opacity. Use on every scene; flatten a tilted screen before the viewer must read it |
| `morph` | duration, from [w,h,r], to [w,h,r], ease | one `morphBox()` changes shape by clip-path (dot → circle → pill → card); its rings follow 50 ms apart |
| `seed` | duration, radius | any element grows out of a 12 px dot into its own shape |
| `fly` | dx, dy, rotation, depth blur, duration | a card arrives from off-frame with a settling tilt; far cards keep a blur |
| `drift` | duration, dx, dy | slow parallax float after a fly |
| `share` | destination selector, duration | shared-element flight (FLIP) into another element's place; flat contexts only |
| `stair` / `unhl` | — | cascade item: brand square → bar → text wipe → check; `unhl` fades the previous bar |
| `listgo` | from index, to index, track selector, pitch px | the active dot steps down a list and the paired card track scrolls |
| `swell` | duration | the brand gradient rises from the bottom |
| `orbit` | duration | an ellipse path (pathLength=1) draws around something |

Per screen: `tr: "zoom" | "wipe" | "cut"` and `zoomOut: <time>` (the zoom-through exit). Every screen also gets two drifting accent blobs when its html includes `blobs()`.
