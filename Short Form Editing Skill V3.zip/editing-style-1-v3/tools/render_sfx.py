#!/usr/bin/env python3
"""Render UI sounds from layered synth recipes to WAV, matching the Web Audio
engine studied on bencho.dev (oscillator / filtered-noise layers, exponential
glides, attack-then-exponential-decay envelopes, BiquadFilter maths per the
Web Audio spec).

Usage:
  python3 render_sfx.py recipes.json OUT_DIR [--peak -3] [--raw] [--only key1,key2]

--raw   keep the published level (very quiet, ~-20..-30 dBFS); default
        normalises every file to --peak dBFS so mix levels are predictable.
"""
import json, math, sys, wave, argparse
import numpy as np

SR = 48000

def biquad(x, kind, f, q):
    """Web Audio BiquadFilter. f may be scalar or per-sample array.
    lowpass: Q in dB. bandpass: linear Q. Coefficients recomputed per block."""
    n = len(x)
    f = np.broadcast_to(np.asarray(f, dtype=float), (n,))
    y = np.zeros(n)
    x1 = x2 = y1 = y2 = 0.0
    blk = 32
    for s in range(0, n, blk):
        fc = min(max(f[s], 10.0), SR / 2 - 10)
        w0 = 2 * math.pi * fc / SR
        cw, sw = math.cos(w0), math.sin(w0)
        if kind == 'lowpass':
            alpha = sw / (2 * 10 ** (q / 20))
            b0 = (1 - cw) / 2; b1 = 1 - cw; b2 = b0
        else:  # bandpass, constant 0 dB peak
            alpha = sw / (2 * max(q, 1e-4))
            b0 = alpha; b1 = 0.0; b2 = -alpha
        a0 = 1 + alpha; a1 = -2 * cw; a2 = 1 - alpha
        b0 /= a0; b1 /= a0; b2 /= a0; a1 /= a0; a2 /= a0
        for i in range(s, min(s + blk, n)):
            xi = x[i]
            yi = b0 * xi + b1 * x1 + b2 * x2 - a1 * y1 - a2 * y2
            x2, x1, y2, y1 = x1, xi, y1, yi
            y[i] = yi
    return y

def freq_curve(L, n, t0):
    """Frequency per sample: setValueAtTime(hz) then exp ramp to `to` by glide end."""
    t = np.arange(n) / SR
    hz = L['hz']
    if not L.get('to'):
        return np.full(n, float(hz))
    dur = (L['glide'] if L.get('glide') else L['ms']) / 1000
    p = np.clip(t / dur, 0, 1)
    return hz * (L['to'] / hz) ** p

def osc(wave_type, f):
    """Band-limited oscillator via additive harmonics (Web Audio oscillators are band-limited)."""
    ph = 2 * math.pi * np.cumsum(f) / SR
    if wave_type == 'sine':
        return np.sin(ph)
    out = np.zeros_like(ph)
    fmax = f.max()
    kmax = int((SR / 2) // max(fmax, 1))
    for k in range(1, kmax + 1):
        alive = (k * f) < SR / 2
        if wave_type == 'square':
            if k % 2 == 0: continue
            a = 4 / (math.pi * k)
            out += a * np.sin(k * ph) * alive
        elif wave_type == 'triangle':
            if k % 2 == 0: continue
            a = 8 / (math.pi ** 2 * k ** 2) * (-1) ** ((k - 1) // 2)
            out += a * np.sin(k * ph) * alive
        elif wave_type == 'sawtooth':
            a = 2 / (math.pi * k) * (-1) ** (k + 1)
            out += a * np.sin(k * ph) * alive
    # Web Audio normalises built-in periodic waves so one cycle peaks at 1.
    g = np.linspace(0, 2 * math.pi, 4096, endpoint=False)
    cyc = np.zeros_like(g)
    for k in range(1, int((SR / 2) // max(f[0], 1)) + 1):
        if wave_type in ('square', 'triangle') and k % 2 == 0: continue
        if wave_type == 'square': a = 4 / (math.pi * k)
        elif wave_type == 'triangle': a = 8 / (math.pi ** 2 * k ** 2) * (-1) ** ((k - 1) // 2)
        else: a = 2 / (math.pi * k) * (-1) ** (k + 1)
        cyc += a * np.sin(k * g)
    return out / max(np.abs(cyc).max(), 1e-9)

def envelope(L, n):
    ms = L['ms'] / 1000
    atk = min((L.get('atk', 4)) / 1000, ms * 0.6)
    peak = L.get('gain', 0.05)
    t = np.arange(n) / SR
    env = np.empty(n)
    a = t < atk
    if L.get('lin'):
        env[a] = 1e-4 + (peak - 1e-4) * (t[a] / atk)
    else:
        env[a] = 1e-4 * (peak / 1e-4) ** (t[a] / atk)
    d = ~a
    p = np.clip((t[d] - atk) / max(ms - atk, 1e-6), 0, 1)
    env[d] = peak * (1e-4 / peak) ** p
    env[t > ms] = 0.0
    return env

def render(layers, rng):
    total = max(L.get('at', 0) + L['ms'] for L in layers) / 1000 + 0.05
    out = np.zeros(int(total * SR) + 1)
    for L in layers:
        start = int(L.get('at', 0) / 1000 * SR)
        n = int((L['ms'] / 1000 + 0.02) * SR)
        f = freq_curve(L, n, 0)
        if L.get('noise'):
            src = rng.uniform(-1, 1, n)
            sig = biquad(src, L['noise'], f, L.get('q', 1.0))
        else:
            sig = osc(L.get('wave', 'sine'), f)
        if L.get('cut'):
            sig = biquad(sig, 'lowpass', L['cut'], 1.0)
        sig = sig * envelope(L, n)
        end = min(start + n, len(out))
        out[start:end] += sig[:end - start]
    return out

def write_wav(path, x):
    x = np.clip(x, -1, 1)
    pcm = (x * 32767).astype('<i2')
    with wave.open(path, 'wb') as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(SR)
        w.writeframes(pcm.tobytes())

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('recipes'); ap.add_argument('out')
    ap.add_argument('--peak', type=float, default=-3.0)
    ap.add_argument('--raw', action='store_true')
    ap.add_argument('--only', default='')
    a = ap.parse_args()
    import os
    os.makedirs(a.out, exist_ok=True)
    lib = json.load(open(a.recipes))
    only = set(filter(None, a.only.split(',')))
    rng = np.random.default_rng(7)
    for s in lib:
        if only and s['key'] not in only and s['name'].lower() not in only: continue
        x = render(s['layers'], rng)
        if not a.raw:
            pk = np.abs(x).max()
            if pk > 0: x = x * (10 ** (a.peak / 20) / pk)
        fn = os.path.join(a.out, s['name'].lower().replace(' ', '-') + '.wav')
        write_wav(fn, x)
        print(f"{fn}  {len(x)/SR*1000:.0f} ms  peak {20*math.log10(np.abs(x).max()+1e-12):.1f} dBFS")

if __name__ == '__main__':
    main()
