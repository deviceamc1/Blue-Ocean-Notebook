"""Find where a split-screen cut's black panel is, and the frames where its edge moves.

Usage: python3 panel_edge.py VIDEO [start_seconds]
Prints the first non-black x on the middle row at 2 fps, then the exact frame of every change.
The graphics panel must match: left 0, width = that x (rounded), switched with tl.set on the change frame.
"""
import subprocess, sys

video = sys.argv[1]
start = float(sys.argv[2]) if len(sys.argv) > 2 else 0.0
W, H, FPS = 1920, 1080, 30


def frames(ss, rate=None, dur=None):
    cmd = ["ffmpeg", "-v", "error", "-ss", str(ss)]
    if dur:
        cmd += ["-t", str(dur)]
    cmd += ["-i", video]
    if rate:
        cmd += ["-vf", f"fps={rate}"]
    cmd += ["-f", "rawvideo", "-pix_fmt", "gray", "-"]
    p = subprocess.Popen(cmd, stdout=subprocess.PIPE)
    while True:
        d = p.stdout.read(W * H)
        if len(d) < W * H:
            break
        row = d[540 * W:541 * W]
        yield next((i for i in range(W) if row[i] > 25), -1)


changes, prev, t = [], None, start
for x in frames(start, rate=2):
    if x != prev:
        print(f"{t:8.2f}s  edge x = {x}")
        if prev is not None:
            changes.append(t)
        prev = x
    t += 0.5

for c in changes:  # refine to the exact frame
    prev, n = None, 0
    for x in frames(max(c - 1, 0), dur=1.5):
        if prev is not None and x != prev:
            print(f"  change on frame {round((max(c - 1, 0)) * FPS) + n}  ({max(c - 1, 0) + n / FPS:.4f}s): {prev} -> {x}")
            break
        prev, n = x, n + 1
