"""Word-level transcript for the reel. Usage: .whisper-env/bin/python transcribe.py AUDIO OUT.json"""
import json, sys
from faster_whisper import WhisperModel

audio, out = sys.argv[1], sys.argv[2]
model = WhisperModel("small.en", device="cpu", compute_type="int8")
segments, info = model.transcribe(audio, language="en", word_timestamps=True, vad_filter=True)
words, text = [], []
for seg in segments:
    text.append(seg.text.strip())
    for w in seg.words:
        words.append({"text": w.word.strip(), "start": round(w.start, 2), "end": round(w.end, 2)})
json.dump({"text": " ".join(text), "words": words}, open(out, "w"), indent=1)
print(" ".join(text))
print(len(words), "words")
