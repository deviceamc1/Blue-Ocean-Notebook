// Nikhil D1 — "Why do inference companies get such high multiples?"
// 16:9 Instagram edit over the finished cut (picture + audio untouched underneath).
// Editing Style 1 (dark kinetic line) and Style 2 (light paper) alternate per takeaway.
//   0 – 15.167   full-screen footage: bottom subtitles only
//  15.167 – END  the cut's split (left half black, face right): graphics fill the black panel
// Run: node build.mjs  → index.html
// (Editing Style 1 v2 original, adapted to the v3 template: title + name tag are now placeholders; its cards render in the UI tokens.)
import fs from "node:fs";

const END = 168.5;
const FPS = 30;
const f = (t) => Math.round(t * FPS) / FPS;
const SPLIT_IN = f(15.1667); // first split frame in the cut
const WIDEN = f(104.0667); // the cut's black panel grows from 1078 to 1109 px here
const words = JSON.parse(fs.readFileSync("work/transcript.json", "utf8")).words;
const norm = (s) => s.toLowerCase().replace(/[^a-z0-9$]/g, "");

// ---------- media ----------
const svgInner = (src) => src.replace(/<!--[\s\S]*?-->/g, "").replace(/^[\s\S]*?<svg[^>]*>/, "").replace(/<\/svg>\s*$/, "").replace(/<title>[\s\S]*?<\/title>/, "");
const ICONS = {};
for (const n of fs.readdirSync("assets/icons")) ICONS[n.replace(".svg", "")] = svgInner(fs.readFileSync(`assets/icons/${n}`, "utf8"));
const LOGOS = {};
for (const n of fs.readdirSync("assets/logos")) LOGOS[n.replace(".svg", "")] = svgInner(fs.readFileSync(`assets/logos/${n}`, "utf8"));
const icon = (n, s, sw = 1.6) => {
  if (!ICONS[n]) throw new Error("icon " + n);
  return `<svg class="ic" width="${s}" height="${s}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="${sw}" stroke-linecap="round" stroke-linejoin="round">${ICONS[n]}</svg>`;
};
const logo = (n, s) => {
  if (!LOGOS[n]) throw new Error("logo " + n);
  return `<svg class="lg" width="${s}" height="${s}" viewBox="0 0 24 24" fill="currentColor" fill-rule="evenodd">${LOGOS[n]}</svg>`;
};
const star = (s) => `<svg class="ic" width="${s}" height="${s}" viewBox="0 0 24 24"><path d="M12 2.5l2.9 6.1 6.6.8-4.9 4.6 1.3 6.6L12 17.3l-5.9 3.3 1.3-6.6L2.5 9.4l6.6-.8z" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linejoin="round"/><path class="sf" d="M12 2.5l2.9 6.1 6.6.8-4.9 4.6 1.3 6.6L12 17.3l-5.9 3.3 1.3-6.6L2.5 9.4l6.6-.8z" fill="currentColor"/></svg>`;

// ---------- building blocks (absolute, screen px) ----------
const box = (x, y, w, h) => `left:${x}px;top:${y}px;width:${w}px;height:${h}px`;
// card: icon/logo on top, label at the bottom; "lit" inverts it (one lit thing at a time)
const card = (id, x, y, w, h, art, lab, extra = "") => `<div class="card" id="${id}" style="${box(x, y, w, h)}"><div class="art">${art}</div>${lab ? `<div class="lab">${lab}</div>` : ""}${extra}</div>`;
const slot = (x, y, w, h) => `<div class="slot" style="${box(x, y, w, h)}"></div>`;
const chip = (id, x, y, w, art, text) => `<div class="chip" id="${id}" style="left:${x}px;top:${y}px;width:${w}px">${art}<span>${text}</span></div>`;
const big = (id, x, y, w, text, size, weight = 900) => `<div class="big" id="${id}" style="left:${x}px;top:${y}px;width:${w}px;font-size:${size}px;font-weight:${weight}">${text}</div>`;
const stamp = (id, x, y, text, size = 64) => `<div class="stamp" id="${id}" style="left:${x}px;top:${y}px;font-size:${size}px">${text}</div>`;
const badge = (id, x, y, s, art) => `<div class="badge" id="${id}" style="${box(x, y, s, s)}">${art}</div>`;
// newspaper-style clipping (facts only; generic paper, source credited — no real masthead)
const clip = (id, x, y, w, c) => `<div class="clip" id="${id}" style="left:${x}px;top:${y}px;width:${w}px">
  <div class="ck"><span>${c.kicker}</span><span>${c.date}</span></div>
  <div class="ch">${c.head}</div>${c.sub ? `<div class="cs">${c.sub}</div>` : ""}
  <div class="cl"><i></i><i></i><i></i><i style="width:62%"></i></div>
  <div class="cf">${c.source}</div></div>`;
// connector lines drawn with pathLength=1
const lines = (W, paths) => `<svg class="lines" width="${W}" height="1080" viewBox="0 0 ${W} 1080">${paths.map(([id, d, head]) => `<path id="${id}" d="${d}" pathLength="1" class="ln"/>${head ? `<path id="${id}-h" d="${head}" class="lh"/>` : ""}`).join("")}</svg>`;
const arrowR = (id, x1, x2, y) => [id, `M${x1} ${y} L${x2 - 4} ${y}`, `M${x2 - 22} ${y - 16} L${x2} ${y} L${x2 - 22} ${y + 16}`];
const strike = (id, x, y, w, h) => [id, `M${x + 20} ${y + 20} L${x + w - 20} ${y + h - 20}`];

// ---------- screens ----------
// chunks: [text, t]. {braces} mark a key phrase (bold only — no highlight box). Word times come from the transcript.
// beats: [type, selector, t, ...args] — interpreted by the page runtime.
const S = [];
const add = (s) => S.push(s);

// 1 · DARK — billion dollar business around free tech (on screen from the first split frame)
add({ id: "s1", theme: "dark", start: SPLIT_IN, cut: true,
  chunks: [["you can build a", 15.44], ["{billion dollar} business", 16.6], ["around {free technology?}", 18.06]],
  html: (W) => card("s1-free", 90, 430, 400, 420, icon("code", 150) + `<div class="sub">${icon("lock-open", 46)}</div>`, "Open source") +
    card("s1-biz", 590, 430, 400, 420, icon("building-2", 130) + `<div class="num" id="s1-n">$0</div>`, "Business") +
    lines(W, [arrowR("s1-a", 500, 580, 640)]) + stamp("s1-st", 130, 760, "$0 to use"),
  beats: [["lit", "#s1-biz", 16.6], ["count", "#s1-n", 16.6, 1.3, 0, 1e9, "money"], ["unlit", "#s1-biz", 18.74], ["lit", "#s1-free", 18.74], ["draw", "#s1-a", 18.9, 0.5], ["stamp", "#s1-st", 19.36, -6]] });

// 2 · LIGHT — inference is the hottest topic (clippings)
add({ id: "s2", theme: "light", start: 20.0,
  chunks: [["this word", 20.76], ["{inference}", 21.26], ["one of the {hottest topics}", 22.76], ["in {Silicon Valley}", 24.2], ["and the {open source AI} world.", 25.56]],
  html: (W) => clip("s2-c1", 60, 390, 470, { kicker: "Tech", date: "Dec 24, 2025", head: "Nvidia strikes ~$20 billion deal for Groq’s inference tech", sub: "Licensing deal. Groq’s founder joins Nvidia.", source: "As reported by TechRepublic" }) +
    clip("s2-c2", 550, 430, 470, { kicker: "Startups", date: "2026", head: "Inference startup Fireworks AI valued at $17.5 billion", source: "As reported by Forbes" }) +
    badge("s2-fire", 250, 905, 120, icon("flame", 78)) + chip("s2-os", 400, 921, 420, icon("code", 44), "Open source AI"),
  beats: [["pop", "#s2-fire", 21.3], ["ink", "#s2-fire", 21.4], ["clip", "#s2-c1", 22.9, -3], ["clip", "#s2-c2", 24.86, 2.5], ["pop", "#s2-os", 26.54], ["ink", "#s2-os", 26.6]] });

// 3 · DARK — what inference is
add({ id: "s3", theme: "dark", start: 27.45,
  chunks: [["For anybody away from AI,", 27.88], ["{inference} is when AI", 30.4], ["uses what it {learned}", 32.1], ["to {answer your question.}", 34.2]],
  html: (W) => card("s3-l", 70, 460, 280, 340, icon("book-open", 120), "Learned") + card("s3-ai", 400, 460, 280, 340, icon("brain", 130), "AI model") +
    card("s3-q", 730, 460, 280, 340, icon("message-circle-question", 120), "Answer") +
    lines(W, [arrowR("s3-a1", 356, 394, 630), arrowR("s3-a2", 686, 724, 630)]),
  beats: [["lit", "#s3-ai", 30.4], ["pop", "#s3-l", 33.1], ["unlit", "#s3-ai", 33.28], ["lit", "#s3-l", 33.28], ["draw", "#s3-a1", 33.5, 0.4], ["pop", "#s3-q", 34.25], ["unlit", "#s3-l", 34.38], ["lit", "#s3-q", 34.38], ["draw", "#s3-a2", 34.5, 0.4]] });

// 4 · LIGHT — why would investors like this? rewind to a historical example
add({ id: "s4", theme: "light", start: 35.4,
  chunks: [["But why would", 35.82], ["{investors} like this?", 36.72], ["Let’s start with", 38.74], ["a {historical example.}", 39.5]],
  html: (W) => card("s4-inv", 290, 400, 500, 300, `<div class="row">${icon("chart-line", 110)}${icon("coins", 110)}</div>`, "Investors") +
    stamp("s4-q", 760, 380, "?", 120) +
    `<div class="row abs" id="s4-yr" style="left:0;top:760px;width:${W}px">${icon("rotate-ccw", 110)}<span class="yr" id="s4-n">2026</span></div>`,
  beats: [["lit", "#s4-inv", 36.72], ["stamp", "#s4-q", 37.6, 8], ["unlit", "#s4-inv", 39.6], ["fade", "#s4-yr", 39.7], ["spin", "#s4-yr .ic", 40.2, 1.1, -720], ["count", "#s4-n", 40.2, 1.1, 2026, 1991, "year"]] });

// 5 · DARK — Linux was free, enterprises still needed support + someone responsible
add({ id: "s5", theme: "dark", start: 41.7,
  chunks: [["{Linux} was always available", 42.14], ["as {open source}", 43.76], ["But {enterprises}", 46.84], ["still needed {support}", 48.98], ["and somebody to take", 51.58], ["{responsibility.}", 53.22]],
  html: (W) => card("s5-lx", 70, 400, 400, 400, logo("linux", 190), "Linux") + chip("s5-free", 70, 830, 400, icon("lock-open", 40), "Free · Open") +
    card("s5-ent", 610, 400, 400, 400, icon("building-2", 170), "Enterprise") +
    badge("s5-w", 580, 370, 110, icon("wrench", 60)) + badge("s5-b", 930, 370, 110, icon("life-buoy", 60)) +
    lines(W, [arrowR("s5-a", 480, 600, 600)]) + chip("s5-r", 540, 830, 500, icon("handshake", 44), "Who’s responsible?"),
  beats: [["lit", "#s5-lx", 42.14], ["pop", "#s5-free", 44.46], ["ink", "#s5-free", 44.5], ["pop", "#s5-ent", 47.1], ["unlit", "#s5-lx", 47.14], ["lit", "#s5-ent", 47.14], ["draw", "#s5-a", 47.9, 0.5],
    ["pop", "#s5-w", 49.9], ["pop", "#s5-b", 50.2], ["pop", "#s5-r", 52.3], ["unlit", "#s5-ent", 53.22], ["ink", "#s5-r", 53.22]] });

// 6 · LIGHT — Red Hat stack, IBM clipping, $34B
add({ id: "s6", theme: "light", start: 54.2,
  chunks: [["So {Red Hat}", 54.62], ["built a business", 55.46], ["{enterprise grade} solutions", 56.42], ["around open source tech.", 58.4], ["{IBM} acquired it", 60.52], ["in {2019}", 61.76], ["for {~$34 billion.}", 62.7]],
  html: (W) => card("s6-rh", 60, 400, 420, 150, `<div class="row">${logo("redhat", 96)}<span class="wm">Red Hat</span></div>`, "") +
    ["Certified", "Security", "Support"].map((t, i) => `<div class="layer" id="s6-l${i}" style="${box(60, 570 + i * 96, 420, 80)}">${t}</div>`).join("") +
    `<div class="layer base" id="s6-lx" style="${box(60, 858, 420, 96)}">${logo("linux", 54)}<span>Linux · free</span></div>` +
    clip("s6-c", 520, 400, 500, { kicker: "Business", date: "Oct 28, 2018", head: "IBM to acquire Red Hat for about $34 billion", sub: "Deal closed July 2019. IBM’s biggest ever.", source: "Source: IBM announcement" }) +
    stamp("s6-st", 640, 840, "$34B", 96),
  beats: [["drop", "#s6-rh", 54.9], ["ink", "#s6-rh", 55.0], ["drop", "#s6-l2", 56.7], ["drop", "#s6-l1", 57.2], ["drop", "#s6-l0", 57.7], ["unink", "#s6-rh", 60.4], ["clip", "#s6-c", 60.5, 2], ["stamp", "#s6-st", 63.66, -7]] });

// 7 · DARK — closed-model companies run their own inference
add({ id: "s7", theme: "dark", start: 66.3,
  chunks: [["How does this connect", 66.92], ["to {AI?}", 68.18], ["{Closed-model} AI companies", 71.06], ["{Google}, {OpenAI}, {Anthropic}", 73.0], ["run their {own inference.}", 75.38]],
  html: (W) => `<div class="fence" id="s7-f" style="${box(50, 400, 980, 380)}"></div>` + badge("s7-lock", 480, 360, 120, icon("lock", 64)) +
    card("s7-g", 90, 450, 270, 290, logo("google", 130), "Google") + card("s7-o", 405, 450, 270, 290, logo("openai", 130), "OpenAI") + card("s7-a", 720, 450, 270, 290, logo("anthropic", 130), "Anthropic") +
    [0, 1, 2].map((i) => badge(`s7-s${i}`, 165 + i * 315, 820, 120, icon("server", 68))).join("") +
    `<div class="note" id="s7-n" style="left:0;top:960px;width:${W}px">Their own servers</div>`,
  beats: [["pop", "#s7-f", 71.0], ["pop", "#s7-lock", 71.2], ["ink", "#s7-lock", 71.3], ["pop", "#s7-g", 72.9], ["lit", "#s7-g", 73.0], ["pop", "#s7-o", 73.6], ["unlit", "#s7-g", 73.7], ["lit", "#s7-o", 73.7],
    ["pop", "#s7-a", 74.4], ["unlit", "#s7-o", 74.52], ["lit", "#s7-a", 74.52], ["pop", "#s7-s0", 76.0], ["pop", "#s7-s1", 76.15], ["pop", "#s7-s2", 76.3], ["fade", "#s7-n", 76.4]] });

// 8 · LIGHT — open-source models: Llama, DeepSeek, Gemma
add({ id: "s8", theme: "light", start: 77.0,
  chunks: [["Now the tech world", 77.44], ["wants {open source} models", 79.24], ["{Meta’s Llama}", 82.52], ["{China’s DeepSeek}", 83.58], ["{Google Gemma}", 84.84]],
  html: (W) => slot(70, 430, 280, 330) + slot(400, 430, 280, 330) + slot(730, 430, 280, 330) +
    card("s8-m", 70, 430, 280, 330, logo("meta", 140), "Llama") + card("s8-d", 400, 430, 280, 330, logo("deepseek", 140), "DeepSeek") + card("s8-g", 730, 430, 280, 330, logo("gemma", 130), "Gemma") +
    chip("s8-c", 290, 820, 500, icon("lock-open", 44), "Open · free to run"),
  beats: [["pop", "#s8-c", 81.14], ["ink", "#s8-c", 81.2], ["unink", "#s8-c", 82.4], ["pop", "#s8-m", 82.45], ["lit", "#s8-m", 82.52], ["pop", "#s8-d", 83.5], ["unlit", "#s8-m", 83.58], ["lit", "#s8-d", 83.58],
    ["pop", "#s8-g", 84.75], ["unlit", "#s8-d", 84.84], ["lit", "#s8-g", 84.84]] });

// 9 · DARK — ChatGPT: OpenAI runs the inference, you relax
add({ id: "s9", theme: "dark", start: 85.9,
  chunks: [["Use {ChatGPT?}", 86.34], ["{OpenAI} runs the inference", 87.78], ["so you’re {very relaxed.}", 89.08]],
  html: (W) => card("s9-c", 90, 420, 380, 380, logo("openai", 170), "ChatGPT") + lines(W, [arrowR("s9-a", 480, 600, 610)]) +
    card("s9-s", 610, 420, 380, 380, icon("server", 160), "OpenAI runs it") + chip("s9-r", 330, 850, 420, icon("sofa", 48), "You: relaxed"),
  beats: [["lit", "#s9-c", 86.9], ["draw", "#s9-a", 87.7, 0.4], ["pop", "#s9-s", 88.0], ["unlit", "#s9-c", 88.12], ["lit", "#s9-s", 88.12], ["pop", "#s9-r", 89.4], ["unlit", "#s9-s", 89.56], ["lit", "#s9-r", 89.56]] });

// 10 · LIGHT — pick Llama, Groq runs it (not Grok)
add({ id: "s10", theme: "light", start: 90.15,
  chunks: [["But pick {Llama},", 90.56], ["and companies like {Groq}", 92.26], ["run inference for you.", 93.74], ["Not the {Elon Musk} one!", 95.06]],
  html: (W) => card("s10-m", 90, 410, 360, 360, logo("meta", 170), "Llama") + lines(W, [arrowR("s10-a", 460, 620, 590)]) +
    card("s10-g", 630, 410, 360, 360, logo("groq", 170), "Groq") + badge("s10-chip", 900, 380, 120, icon("cpu", 66)) +
    `<div class="row abs" id="s10-x" style="left:0;top:880px;width:${W}px"><span class="mini">${logo("grok", 70)}<b>Grok</b></span><span class="neq">≠</span><span class="mini">${logo("groq", 70)}<b>Groq</b></span></div>` +
    stamp("s10-st", 150, 790, "Not this", 48),
  beats: [["lit", "#s10-m", 91.52], ["draw", "#s10-a", 92.3, 0.5], ["pop", "#s10-g", 92.85], ["unlit", "#s10-m", 92.98], ["lit", "#s10-g", 92.98], ["pop", "#s10-chip", 94.24], ["fade", "#s10-x", 95.06], ["stamp", "#s10-st", 95.6, -8]] });

// 11 · DARK — lower the cost of better answers
add({ id: "s11", theme: "dark", start: 96.5,
  chunks: [["Inference companies promise", 97.22], ["to {lower the cost}", 98.66], ["of {better answers}", 100.42], ["from open source.", 101.54]],
  html: (W) => `<div class="chart" style="${box(80, 420, 420, 480)}">${[0, 1, 2, 3].map((i) => `<div class="bar" id="s11-b${i}" style="left:${20 + i * 100}px"></div>`).join("")}<div class="axis"></div></div>` +
    `<div class="note" id="s11-cl" style="left:80px;top:930px;width:420px">${icon("trending-down", 44)} Cost</div>` +
    `<div class="stars" id="s11-st" style="left:560px;top:560px;width:460px">${[0, 1, 2, 3, 4].map((i) => `<span id="s11-s${i}">${star(84)}</span>`).join("")}</div>` +
    `<div class="note" id="s11-al" style="left:560px;top:700px;width:460px">${icon("message-square", 44)} Answers</div>`,
  beats: [["bars", "#s11-b", 98.66, [340, 340, 340, 340], [300, 210, 130, 60]], ["fill", "#s11-s", 100.76, 5], ["fade", "#s11-al", 100.5]] });

// 12 · LIGHT — THE TAKEAWAY (hard cut on the cut's own panel change)
add({ id: "s12", theme: "light", start: WIDEN, cut: true,
  chunks: [],
  html: (W) => big("s12-a", 0, 330, W, "So, what’s the", 72, 400) + big("s12-b", 0, 420, W, "TAKEAWAY?", 168, 900) + `<div class="rule" id="s12-r" style="left:${W / 2 - 300}px;top:640px;width:600px"></div>` +
    `<div class="row abs" style="left:0;top:740px;width:${W}px">${badge("s12-i1", 0, 0, 150, icon("code", 84)).replace("left:0px;top:0px;", "position:relative;")}${badge("s12-i2", 0, 0, 150, icon("chart-line", 84)).replace("left:0px;top:0px;", "position:relative;")}</div>`,
  beats: [["settle", "#s12-b", WIDEN], ["draw", "#s12-r", WIDEN + 0.15, 0.5, "w"], ["pop", "#s12-i1", 104.64], ["pop", "#s12-i2", 104.8]] });

// 13 · DARK — engineers: four steps
const steps = [["Deploy open models", 107.52, "package"], ["Cut inference costs", 110.0, "coins"], ["Make AI reliable", 113.16, "check"], ["Cybersecurity", 116.0, "shield-check"]];
add({ id: "s13", theme: "dark", start: 105.4,
  chunks: [["If you’re an {engineer},", 105.86]],
  html: (W) => steps.map(([t, , ic], i) => `<div class="step" id="s13-r${i}" style="left:90px;top:${390 + i * 150}px;width:${W - 180}px"><span class="n" id="s13-n${i}">0${i + 1}</span><span class="si">${icon(ic, 58)}</span><span class="st" id="s13-t${i}">${t}</span></div>`).join(""),
  beats: steps.flatMap(([, t], i) => [["step", `#s13-r${i}`, t]]) });

// 14 · LIGHT — investors: don't just look at growth or chips
add({ id: "s14", theme: "light", start: 117.9,
  chunks: [["If you’re an {investor},", 118.32], ["{don’t just} look at", 119.76], ["how {fast} it’s growing", 120.38], ["or how good its {chips} are", 123.84]],
  html: (W) => card("s14-g", 95, 420, 420, 380, icon("gauge", 160), "Growth speed") + card("s14-c", 595, 420, 420, 380, icon("cpu", 160), "Chips") + stamp("s14-st", 320, 830, "Not enough", 70),
  beats: [["pop", "#s14-g", 120.6], ["lit", "#s14-g", 120.7], ["pop", "#s14-c", 124.85], ["unlit", "#s14-g", 124.96], ["lit", "#s14-c", 124.96], ["unlit", "#s14-c", 125.5], ["dim", "#s14-g", 125.5], ["dim", "#s14-c", 125.5], ["stamp", "#s14-st", 125.55, -5]] });

// 15 · DARK — retention + profitable in a price war
add({ id: "s15", theme: "dark", start: 126.25,
  chunks: [["Look at how many", 126.7], ["{customers keep coming back}", 127.66], ["over a {longer horizon}", 128.9], ["can they stay {profitable}", 131.66], ["when rivals {lower prices?}", 133.02]],
  html: (W) => card("s15-r", 95, 420, 420, 380, `<div class="stackic">${icon("users", 130)}<span class="spin" id="s15-sp">${icon("refresh-cw", 70)}</span></div>`, "Retention") +
    card("s15-p", 595, 420, 420, 380, icon("badge-dollar-sign", 160), "Profit") + chip("s15-w", 640, 840, 330, icon("trending-down", 44), "Price war"),
  beats: [["pop", "#s15-r", 127.55], ["lit", "#s15-r", 127.66], ["spin", "#s15-sp", 128.0, 2.2, 720], ["pop", "#s15-p", 132.05], ["unlit", "#s15-r", 132.18], ["lit", "#s15-p", 132.18], ["pop", "#s15-w", 133.88], ["shake", "#s15-p", 134.0]] });

// 16 · LIGHT — Red Hat's $34B wasn't for support
add({ id: "s16", theme: "light", start: 134.85,
  chunks: [["Red Hat’s {$34B} deal", 135.26], ["wasn’t about", 137.36], ["selling {Linux support.}", 138.74]],
  html: (W) => card("s16-rh", 255, 400, 600, 240, `<div class="row">${logo("redhat", 120)}<span class="wm xl">$34B</span></div>`, "") +
    card("s16-s", 305, 700, 500, 240, `<div class="row">${logo("linux", 100)}${icon("wrench", 90)}</div>`, "Linux support") + lines(W, [strike("s16-x", 305, 700, 500, 240), ["s16-x2", "M785 720 L325 920"]]),
  beats: [["ink", "#s16-rh", 135.94], ["pop", "#s16-s", 138.8], ["draw", "#s16-x", 139.5, 0.3], ["draw", "#s16-x2", 139.7, 0.3], ["dim", "#s16-s", 139.9]] });

// 17 · DARK — it sold risk mitigation + certifications
add({ id: "s17", theme: "dark", start: 140.3,
  chunks: [["Red Hat sold", 141.6], ["{risk mitigation}", 142.7], ["and {certifications.}", 143.62]],
  html: (W) => chip("s17-rh", 345, 380, 390, logo("redhat", 54), "Red Hat sold") +
    card("s17-r", 95, 480, 420, 400, icon("shield-check", 170), "Less risk") + card("s17-c", 595, 480, 420, 400, icon("award", 170), "Certified"),
  beats: [["pop", "#s17-r", 142.6], ["lit", "#s17-r", 142.7], ["pop", "#s17-c", 144.4], ["lit", "#s17-c", 144.52]] });

// 18 · LIGHT — Oracle tried to copy it and failed
add({ id: "s18", theme: "light", start: 145.3,
  chunks: [["Even {Oracle} tried", 145.7], ["to copy Red Hat", 146.56], ["and {failed.}", 147.84]],
  html: (W) => clip("s18-c", 90, 390, 930, { kicker: "Tech", date: "Oct 26, 2006", head: "Red Hat shares tumble 24% as Oracle offers Linux support at half the price", source: "As reported by The Register" }) +
    card("s18-o", 95, 730, 420, 250, `<div class="row">${logo("oracle", 110)}</div>`, "Oracle · 2006") + card("s18-r", 595, 730, 420, 250, `<div class="row">${logo("redhat", 90)}<span class="wm">$34B</span></div>`, "Red Hat · 2019") +
    stamp("s18-st", 300, 690, "Failed", 70),
  beats: [["clip", "#s18-c", 145.85, -1.5], ["pop", "#s18-o", 146.3], ["pop", "#s18-r", 147.1], ["stamp", "#s18-st", 148.22, -8], ["ink", "#s18-r", 148.3]] });

// 19 · DARK — a massive industry ≠ every company a massive business
const tiles = Array.from({ length: 12 }, (_, i) => i);
const WIN = [5, 10];
add({ id: "s19", theme: "dark", start: 149.1,
  chunks: [["Inference may become", 149.6], ["a {massive industry}", 151.26], ["but {not every} company", 152.18], ["becomes a {massive business.}", 154.88]],
  html: (W) => `<div class="tiles" style="left:${(W - 4 * 200 - 3 * 30) / 2}px;top:390px">${tiles.map((i) => `<div class="tile" id="s19-t${i}">${icon(["server", "cpu", "bot", "layers"][i % 4], 74)}</div>`).join("")}</div>` +
    WIN.map((i, k) => badge(`s19-w${k}`, (W - 890) / 2 + (i % 4) * 230 + 120, 390 + Math.floor(i / 4) * 200 - 30, 90, icon("sparkles", 50))).join(""),
  beats: [["wave", "#s19-t", 151.42, 12], ["fall", "#s19-t", 153.62, 12, WIN], ["win", "#s19-t", 156.1, WIN], ["pop", "#s19-w0", 156.2], ["pop", "#s19-w1", 156.3]] });

// 20 · LIGHT — CTA
add({ id: "s20", theme: "light", start: 156.75,
  chunks: [["Let me know in the {comments}", 157.18], ["if you have {any doubts}", 158.32], ["{share this} with", 159.7], ["anyone in {AI.}", 160.52], ["more {nuanced} topics", 162.94], ["to {open your mind.}", 166.32]],
  html: (W) => card("s20-c", 70, 430, 290, 340, icon("message-square", 130), "Comment") + card("s20-s", 395, 430, 290, 340, icon("share-2", 130), "Share") + card("s20-m", 720, 430, 290, 340, icon("brain", 130), "Open mind") +
    badge("s20-sp", 900, 380, 120, icon("sparkles", 70)),
  beats: [["pop", "#s20-c", 157.6], ["lit", "#s20-c", 157.76], ["pop", "#s20-s", 160.0], ["unlit", "#s20-c", 160.12], ["lit", "#s20-s", 160.12], ["pop", "#s20-m", 163.3], ["unlit", "#s20-s", 165.28], ["lit", "#s20-m", 165.28], ["pop", "#s20-sp", 166.48], ["ink", "#s20-sp", 166.5]] });

// ---------- subtitles over the full-screen footage ----------
const CAPS = [["Listen to Nikhil Kamath", 0.0], ["asking this question.", 1.34, 2.5], ["Can I ask a question?", 2.58], ["Why do they get", 3.42], ["such high multiples?", 3.84, 5.5], ["Which ones?", 5.88], ["The inference guys?", 6.5, 8.0],
  ["When you value them,", 9.6], ["because it doesn’t seem like", 10.48], ["they’re doing anything innovative.", 11.7, 12.95], ["Now, would you believe me", 13.16], ["if I said that…", 14.2, SPLIT_IN]];

// ---------- assemble ----------
function timeWords(text, t0) {
  let cur = words.findIndex((w) => w.start >= t0 - 0.06);
  if (cur < 0) cur = words.length;
  let prev = t0 - 0.12;
  const out = [];
  for (const raw of text.replace(/[{}]/g, "").split(" ")) {
    const n = norm(raw);
    let hit = -1;
    for (let j = cur; j < Math.min(cur + 8, words.length); j++) if (norm(words[j].text) === n || (n.length > 3 && norm(words[j].text).startsWith(n))) { hit = j; break; }
    let t = hit >= 0 ? words[hit].start : prev + 0.12;
    if (hit >= 0) cur = hit + 1;
    t = Math.max(t, prev + 0.06);
    out.push(t); prev = t;
  }
  return out;
}

const chunkSpec = []; // runtime: [{sel, words:[t], marks:[{sel,t}], leave}]
function chunksHtml(s, W) {
  if (!s.chunks.length) return "";
  let html = `<div class="chunks" style="width:${W}px">`;
  s.chunks.forEach(([text, t0], ci) => {
    const times = timeWords(text, t0);
    let wi = 0, inMark = false, markIdx = 0;
    const plain = text.replace(/[{}]/g, "");
    const size = plain.length > 24 ? 70 : plain.length > 16 ? 80 : 92;
    const cid = `${s.id}-k${ci}`;
    const marks = [];
    let inner = "";
    for (const tok of text.split(" ")) {
      const open = tok.startsWith("{"), close = tok.endsWith("}") || tok.endsWith("},") || tok.endsWith("}?");
      let w = tok;
      if (open) { inMark = true; const mid = `${cid}-m${markIdx++}`; marks.push({ sel: "#" + mid, t: times[wi] }); inner += `<span class="mk" id="${mid}">`; w = w.slice(1); }
      const trail = w.match(/}(.*)$/);
      const core = w.replace(/}.*$/, "");
      inner += `<span class="w${inMark ? " on" : ""}" data-t="${times[wi].toFixed(2)}">${core}</span>`;
      if (close && inMark) { inner += `</span>`; inMark = false; if (trail && trail[1]) inner += `<span class="w" data-t="${times[wi].toFixed(2)}">${trail[1]}</span>`; }
      wi++;
    }
    html += `<div class="chunk" id="${cid}" style="font-size:${size}px">${inner}</div>`;
    const next = s.chunks[ci + 1];
    chunkSpec.push({ sel: "#" + cid, marks, leave: next ? timeWords(next[0], next[1])[0] : null });
  });
  return html + "</div>";
}

const screenSpec = [];
let screens = "";
S.forEach((s, i) => {
  const W = s.start >= WIDEN - 0.001 ? 1110 : 1080;
  const next = S[i + 1];
  s.end = next ? (next.cut ? next.start : next.start + 0.5) : END;
  screens += `<div class="scr ${s.theme}" id="${s.id}" style="width:${W}px"><div class="push" id="${s.id}-push" style="transform-origin:${W / 2}px 620px">
    <div class="frame"><i class="c tl"></i><i class="c tr"></i><i class="c bl"></i><i class="c br"></i></div>
    ${chunksHtml(s, W)}${s.html(W)}</div></div>\n`;
  screenSpec.push({ id: s.id, start: s.start, end: s.end, cut: !!s.cut, theme: s.theme, beats: s.beats });
});

const caps = CAPS.map(([t], i) => `<div class="cap" id="cap${i}"><span class="ph">${t.split(" ").join(" ")}</span></div>`).join("");

const tpl = fs.readFileSync("template.tmpl", "utf8");
const out = tpl
  .replace("__TITLE__", "Nikhil D1: Inference multiples")
  .replace("__RES__", "landscape").replaceAll("__W__", "1920").replaceAll("__H__", "1080").replaceAll("__PH__", "1080")
  .replace("__CT__", "96").replace("__CHH__", "250").replace("__ACCENT__", "#3d7ef5").replace("__AUDIO__", "")
  .replace("__MEDIA__", '      <video id="src" src="media/source.mp4" muted playsinline data-start="0" data-duration="' + END + '" data-track-index="0"></video>')
  .replace("__TAG__", '<div id="tag"><b>Nikhil Kamath</b><span>CO-FOUNDER, ZERODHA</span></div>')
  .replaceAll("__END__", String(END))
  .replace("__SCREENS__", screens)
  .replace("__CAPS__", caps)
  .replace("__DATA__", JSON.stringify({ END, SPLIT_IN, WIDEN, TAG: { in: 2.6, out: 5.5 }, screens: screenSpec, chunks: chunkSpec, caps: CAPS.map(([, t, e], i) => [t, e ?? (CAPS[i + 1] ? CAPS[i + 1][1] : SPLIT_IN)]) }));
fs.writeFileSync("index.html", out);
console.log("index.html written:", S.length, "screens,", chunkSpec.length, "chunks");
