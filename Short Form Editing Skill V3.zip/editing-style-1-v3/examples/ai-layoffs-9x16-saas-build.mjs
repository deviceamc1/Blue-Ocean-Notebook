// AI layoffs in India — 9:16 reel, SaaS-explainer motion (Editing Style 1 v3 + references/saas-motion.md).
// Sound: viral-style SFX (Openverse CC0 / CC BY + HyperFrames bundled) trimmed in assets/fx. Run: node build.mjs
import fs from "node:fs";

const END = 45;
const TITLE = "AI layoffs in India";
const ACCENT = "#3d7ef5";

const svgInner = (src) => src.replace(/<!--[\s\S]*?-->/g, "").replace(/^[\s\S]*?<svg[^>]*>/, "").replace(/<\/svg>\s*$/, "").replace(/<title>[\s\S]*?<\/title>/, "");
const ICONS = {};
for (const n of fs.readdirSync("assets/icons")) ICONS[n.replace(".svg", "")] = svgInner(fs.readFileSync(`assets/icons/${n}`, "utf8"));
const LOGOS = {};
for (const n of fs.readdirSync("assets/logos")) LOGOS[n.replace(".svg", "")] = svgInner(fs.readFileSync(`assets/logos/${n}`, "utf8"));
const icon = (n, s, sw = 1.6) => {
  if (!ICONS[n]) throw new Error("icon " + n);
  return `<svg class="ic" width="${s}" height="${s}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="${sw}" stroke-linecap="round" stroke-linejoin="round">${ICONS[n]}</svg>`;
};
const logo = (n, s) => {
  if (!LOGOS[n]) throw new Error("logo " + n);
  return `<svg class="lg" width="${s}" height="${s}" viewBox="0 0 24 24" fill="currentColor" fill-rule="evenodd">${LOGOS[n]}</svg>`;
};

// ---------- v2 editorial blocks (absolute, screen px) ----------
const box = (x, y, w, h) => `left:${x}px;top:${y}px;width:${w}px;height:${h}px`;
const card = (id, x, y, w, h, art, lab, extra = "") => `<div class="card" id="${id}" style="${box(x, y, w, h)}"><div class="art">${art}</div>${lab ? `<div class="lab">${lab}</div>` : ""}${extra}</div>`;
const big = (id, x, y, w, text, size, weight = 900) => `<div class="big" id="${id}" style="left:${x}px;top:${y}px;width:${w}px;font-size:${size}px;font-weight:${weight}">${text}</div>`;
const stamp = (id, x, y, text, size = 64) => `<div class="stamp" id="${id}" style="left:${x}px;top:${y}px;font-size:${size}px">${text}</div>`;
const clip = (id, x, y, w, c) => `<div class="clip" id="${id}" style="left:${x}px;top:${y}px;width:${w}px">
  <div class="ck"><span>${c.kicker}</span><span>${c.date}</span></div>
  <div class="ch">${c.head}</div>${c.sub ? `<div class="cs">${c.sub}</div>` : ""}
  <div class="cl"><i></i><i></i><i style="width:62%"></i></div>
  <div class="cf">${c.source}</div></div>`;

// ---------- UI blocks (authored at web size, presented with zoom) ----------
// ui(): centre a w1-wide component (1× px) in the panel at `top`, scaled by z. Returns the wrapper.
const ui = (id, W, w1, z, top, inner, dx = 0) => `<div class="ui" id="${id}" style="left:${Math.round((W - w1 * z) / 2 / z + dx)}px;top:${Math.round(top / z)}px;width:${w1}px;zoom:${z}">${inner}</div>`;
// at(): place a w1-wide component at an absolute panel x (screen px)
const uiAt = (id, x, w1, z, top, inner) => `<div class="ui" id="${id}" style="left:${Math.round(x / z)}px;top:${Math.round(top / z)}px;width:${w1}px;zoom:${z}">${inner}</div>`;
// roll(): a figure whose changed digits roll (keyed by place from the right)
const roll = (id, from, to, cls = "ui-fig") => {
  const n = Math.max(from.length, to.length), A = from.padStart(n, " "), B = to.padStart(n, " ");
  let h = "";
  for (let i = 0; i < n; i++) {
    const a = A[i].trim(), b = B[i].trim(), d = /\d/.test(a) || /\d/.test(b);
    h += `<span class="ui-slot${d ? " d" : ""}"${a !== b ? " data-c" : ""}><span class="sz">${a || b}</span><span class="o">${a}</span><span class="n">${b}</span></span>`;
  }
  return `<span class="${cls} tab ui-roll" id="${id}">${h}</span>`;
};
const seg = (id, labels, on = 0) => `<div class="ui-seg" id="${id}"><span class="ui-seg-th" style="width:calc(${100 / labels.length}% - ${4 / labels.length}px)"></span>${labels.map((l, i) => `<b class="${i === on ? "on" : ""}">${l}</b>`).join("")}</div>`;
const bars = (id, rows) => `<div class="ui-brows" id="${id}">${rows.map(([lab, val, color]) => `<div class="ui-brow"><span class="ui-blab">${lab}</span><span class="ui-track"><span class="ui-fill"${color ? ` style="background:${color}"` : ""}></span></span><span class="ui-bval">${val}</span></div>`).join("")}</div>`;
const chip = (id, text, dot) => `<span class="ui-chip" id="${id}">${dot ? `<i style="background:${dot}"></i>` : ""}${text}</span>`;
const glyph = (d, s = 13) => `<svg width="${s}" height="${s}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round">${d}</svg>`;
const G = { check: '<path d="M5 12.5l4.5 4.5L19 7.5"/>', alert: '<path d="M12 8v5"/><path d="M12 17h.01"/>', mail: '<rect x="3" y="5" width="18" height="14" rx="2"/><path d="m3 7 9 6 9-6"/>', users: '<path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87"/>' };
const toast = (id, g, color, title, sub, act) => `<div class="ui-toast" id="${id}" style="opacity:0"><span class="ui-ic" style="background:color-mix(in srgb, ${color} 22%, transparent);color:${color}">${glyph(g)}</span><span class="ui-tx"><b>${title}</b><span>${sub}</span></span>${act ? `<span class="ui-act">${act}</span>` : ""}</div>`;
const crow = (id, text, tag) => `<div class="ui-crow" id="${id}"><span class="ui-cbox"><span class="ui-cfill"></span><svg class="ui-ctick" viewBox="0 0 24 24"><path d="M5 12.5l4.5 4.5L19 7.5" pathLength="1"/></svg></span><span class="ui-csay">${text}<span class="ui-crule"></span></span>${tag ? `<span class="ui-tag">${tag}</span>` : ""}</div>`;
const cursor = (id) => `<svg class="ui-cursor" id="${id}" viewBox="0 0 24 24"><path d="M5.5 3.21V20.8c0 .45.54.67.85.35l4.86-4.86a.5.5 0 0 1 .35-.15h6.87a.5.5 0 0 0 .35-.85L6.35 2.85a.5.5 0 0 0-.85.35Z"/></svg>`;


// ---------- SaaS-motion helpers (references/saas-motion.md) ----------
const esc = (c) => (c === "<" ? "&lt;" : c === ">" ? "&gt;" : c === "&" ? "&amp;" : c);
const chars = (text) => { let out = "", b = false; for (const tok of text.split(/([{}])/)) { if (tok === "{") { b = true; continue; } if (tok === "}") { b = false; continue; } for (const c of tok) out += `<span class="cx${b ? " b" : ""}">${esc(c)}</span>`; } return out; };
// a typed line (caret + accent wake); {braces} = bold key words
const typeLine = (id, text, size, top, weight = 500) => `<div class="type" id="${id}" style="top:${top}px;font-size:${size}px;font-weight:${weight}"><span class="tline">${chars(text)}<span class="caret"></span></span></div>`;
// a word that resolves letter by letter; pos = absolute top, or "rel" inside a morph
const spellWord = (id, text, size, top, weight = 500, extra = "") => `<div class="spell" id="${id}" style="${top === "rel" ? "position:relative;left:auto;right:auto;" : `top:${top}px;`}font-size:${size}px;font-weight:${weight};${extra}">${chars(text)}</div>`;
// a morph container (max size W×H centred at cx,cy) plus n rings that follow its shape
const morphBox = (id, cx, cy, W, H, inner, bg, rings = 0, gap = 36) => {
  let h = "";
  for (let k = rings; k >= 1; k--) h += `<div class="ring" data-ring-of="${id}" data-k="${k}" data-gap="${gap}" style="left:${cx - W / 2 - k * gap}px;top:${cy - H / 2 - k * gap}px;width:${W + 2 * k * gap}px;height:${H + 2 * k * gap}px"></div>`;
  return h + `<div class="morph" id="${id}" style="left:${cx - W / 2}px;top:${cy - H / 2}px;width:${W}px;height:${H}px;background:${bg}">${inner}</div>`;
};
const blobs = () => `<div class="blobs"><div class="blob a" style="left:-180px;top:380px;width:760px;height:760px"></div><div class="blob b" style="right:-220px;top:900px;width:820px;height:820px"></div></div>`;
const stairItem = (id, x, y, size, text) => `<div class="st-item" id="${id}" style="left:${x}px;top:${y}px;font-size:${size}px"><span class="st-hl"></span><span class="st-tx">${text}</span><span class="st-ck">${glyph(G.check, Math.round(size * 0.5))}</span></div>`;
const pillCard = (id, x, y, w, h, html, extra = "") => `<div id="${id}" style="position:absolute;left:${x}px;top:${y}px;width:${w}px;height:${h}px;${extra}">${html}</div>`;
const bigCursor = (id) => `<svg class="ui-cursor" id="${id}" viewBox="0 0 24 24" style="width:72px;height:72px;margin:-9px 0 0 -16px"><path d="M5.5 3.21V20.8c0 .45.54.67.85.35l4.86-4.86a.5.5 0 0 1 .35-.15h6.87a.5.5 0 0 0 .35-.85L6.35 2.85a.5.5 0 0 0-.85.35Z"/></svg>`;
const camWrap = (id, inner) => `<div class="cam" id="${id}">${inner}</div>`;
const tilt = (id, inner) => `<div class="stage3d"><div class="tilt" id="${id}">${inner}</div></div>`;

const S = [];
const add = (s) => S.push(s);
const INK = "#17181a";

// 1 · LIGHT · HOOK — typed question, real-looking UI cards fly in around it with depth blur; camera pulls out
add({ id: "s1", theme: "light", start: 0, cut: true, zoomOut: 4.4,
  chunks: [],
  html: (W) => blobs() + camWrap("s1-cam",
    typeLine("s1-l1", "Is {AI} taking", 116, 470) + typeLine("s1-l2", "India’s {IT jobs?}", 116, 600) +
    `<div style="position:absolute;left:70px;top:240px;filter:blur(4px);opacity:.55">${ui("s1-far1", 360, 220, 1.6, 0, `<div class="ui-slab"><div class="ui-label">Hiring · FY27</div><div class="ui-fig tab">25,000</div></div>`)}</div>` +
    `<div style="position:absolute;left:640px;top:1180px;filter:blur(5px);opacity:.5">${ui("s1-far2", 360, 200, 1.6, 0, `<div class="ui-slab"><div class="ui-label">Net headcount</div><div class="ui-fig tab">−7,389</div></div>`)}</div>` +
    pillCard("s1-c1", 60, 820, 470, 120, ui("s1-c1u", 470, 300, 1.55, 0, toast("s1-t1", G.alert, "var(--ui-err)", "TCS · ~12,000 roles cut", "July 2025 · about 2% of staff", "").replace(' style="opacity:0"', ' style="position:relative"'))) +
    pillCard("s1-c2", 560, 860, 460, 140, ui("s1-c2u", 460, 280, 1.6, 0, `<div class="ui-slab"><div class="ui-head"><span class="ui-title">Top 5 IT firms</span><span class="ui-label">FY26</span></div><div class="ui-figrow" style="margin-bottom:0"><span class="ui-fig tab">−7,389</span><span class="ui-unit">net</span></div></div>`)) +
    pillCard("s1-c3", 140, 1040, 480, 160, ui("s1-c3u", 480, 290, 1.6, 0, `<div class="ui-slab">${bars("s1-b", [["Before", "40,000"], ["FY27", "25,000"]])}</div>`)) +
    pillCard("s1-c4", 680, 300, 330, 130, ui("s1-c4u", 330, 200, 1.6, 0, `<div class="ui-slab"><div class="ui-label">AI tools</div><div class="ui-title">Junior tasks · auto</div></div>`))),
  beats: [["cam", "#s1-cam", 0, 4.4, { scale: 1.14 }, { scale: 1 }, "power1.out"],
    ["type", "#s1-l1", 0.12, 22, -1], ["type", "#s1-l2", 0.85, 22, 1.4],
    ["fly", "#s1-c1", 0.55, -700, 60, -4, 0], ["fly", "#s1-c2", 0.75, 700, 120, 3, 0], ["fly", "#s1-c3", 0.95, -300, 600, 2, 1.5], ["fly", "#s1-c4", 1.15, 500, -400, 4, 2],
    ["grow", "#s1-b", 1.4, [100, 62]],
    ["drift", "#s1-c1", 1.4, 3, 18, -10], ["drift", "#s1-c2", 1.6, 2.8, -14, 12], ["drift", "#s1-c3", 1.8, 2.6, 10, -8], ["drift", "#s1-c4", 2.0, 2.4, -8, 10]] });

// 2 · LIGHT · a dot pops into a circle, the circle morphs into a pill that fits the line; rings follow
add({ id: "s2", theme: "light", start: 4.4, tr: "zoom", zoomOut: 9.0,
  chunks: [],
  html: (W) => blobs() + camWrap("s2-cam",
    morphBox("s2-m", 540, 760, 900, 300, spellWord("s2-a", "12,000", 104, "rel", 600, `color:${INK};position:absolute;inset:0;align-items:center;`) + spellWord("s2-b", "TCS cut {12,000 jobs}", 66, "rel", 500, `color:${INK};position:absolute;inset:0;align-items:center;`), "#ffffff", 4, 40) +
    pillCard("s2-chip", 290, 1060, 500, 84, `<div style="height:100%;border-radius:42px;background:${INK};color:#fff;display:flex;align-items:center;justify-content:center;gap:16px;font:500 34px Inter,sans-serif;letter-spacing:-0.01em"><span style="width:14px;height:14px;border-radius:4px;background:var(--k-pink)"></span>~2% of its workforce</div>`, "border-radius:42px") +
    spellWord("s2-src", "July 2025 · Reuters, Business Today", 30, 1190, 400, "color:#73726d;letter-spacing:0")),
  beats: [["cam", "#s2-cam", 4.4, 4.6, { scale: 1.12 }, { scale: 0.98 }, "power1.inOut"],
    ["morph", "#s2-m", 4.65, 0.5, [12, 12, 6], [300, 300, 150]], ["spell", "#s2-a", 4.85, 0.035, 14],
    ["unspell", "#s2-a", 5.55], ["morph", "#s2-m", 5.7, 0.6, [300, 300, 150], [880, 190, 95], "expo.out"], ["spell", "#s2-b", 5.85, 0.028, 16],
    ["seed", "#s2-chip", 6.9, 0.55], ["spell", "#s2-src", 7.4, 0.012, 8]] });

// 3 · DARK · "skills, not AI" — clipping drops with depth; the reason control is on a tilted screen that flattens for the click
add({ id: "s3", theme: "dark", start: 9.0, tr: "zoom", zoomOut: 13.6,
  chunks: [["The CEO said", 9.2], ["{skills,} not {AI}", 10.3]],
  html: (W) => blobs() + camWrap("s3-cam",
    clip("s3-c", 170, 640, 620, { kicker: "Business", date: "Jul 27, 2025", head: "TCS to cut about 12,000 jobs, 2% of its workforce", sub: "CEO K. Krithivasan: “skill and capability based.”", source: "As reported by Reuters, Business Today" }) +
    tilt("s3-tilt", ui("s3-ui", W, 240, 2.4, 1080, `<div class="ui-slab screen3d"><div class="ui-label">Official reason</div><div style="height:10px"></div>${seg("s3-seg", ["AI", "Skills"], 0)}${cursor("s3-cur")}</div>`)) +
    stamp("s3-st", 640, 590, "Not AI?", 74)),
  beats: [["cam", "#s3-cam", 9.0, 4.6, { scale: 1.06 }, { scale: 1 }],
    ["clip", "#s3-c", 9.4, -2.5], ["cam", "#s3-tilt", 9.55, 0.9, { rotationX: 24, rotationY: -14, rotationZ: -6, y: 120, opacity: 0 }, { rotationX: 0, rotationY: 0, rotationZ: 0, y: 0, opacity: 1 }, "power3.out"],
    ["press", "#s3-cur", 10.6, 60, 110, 182, 62, "#s3-seg"], ["seg", "#s3-seg", 10.6, 0, 1], ["stamp", "#s3-st", 11.4, -7]] });

// 4 · LIGHT · the top five shrank — stat card on a tilted screen; the camera brings it flat to read, the cursor flips the year
add({ id: "s4", theme: "light", start: 13.6, tr: "wipe",
  chunks: [["Yet the {top five}", 13.8], ["IT firms {shrank}", 14.7]],
  html: (W) => blobs() + tilt("s4-tilt", ui("s4-ui", W, 360, 2.5, 690, `<div class="ui-slab screen3d">
      <div class="ui-head"><span class="ui-title">Top 5 IT firms · net hiring</span>${seg("s4-seg", ["FY25", "FY26"], 0)}</div>
      <div class="ui-figrow"><span class="ui-fig tab" id="s4-n">+12,718</span><span class="ui-unit">people</span></div>
      ${bars("s4-b0", [["FY25", "+12,718", "var(--ui-ok)"]])}<div style="height:10px"></div>${bars("s4-b1", [["FY26", "−7,389", "var(--ui-err)"]])}
      <div class="ui-hair"></div><div class="ui-sub">TCS · Infosys · HCLTech · Wipro · Tech Mahindra — IANS, Apr 2026</div>${cursor("s4-cur")}</div>`)),
  beats: [["cam", "#s4-tilt", 13.7, 1.1, { rotationX: 26, rotationY: 16, rotationZ: 5, scale: 0.86, y: 80 }, { rotationX: 0, rotationY: 0, rotationZ: 0, scale: 1, y: 0 }, "power3.inOut"],
    ["grow", "#s4-b0", 14.6, [100]], ["press", "#s4-cur", 15.4, 120, 150, 338, 40, "#s4-seg"], ["seg", "#s4-seg", 15.4, 0, 1],
    ["count", "#s4-n", 15.45, 1.0, 12718, -7389, "signed"], ["grow", "#s4-b1", 15.6, [58]],
    ["cam", "#s4-tilt", 16.6, 2.0, { rotationX: 0, rotationY: 0, rotationZ: 0, scale: 1, y: 0 }, { rotationX: 6, rotationY: -8, rotationZ: -2, scale: 1.04, y: -10 }, "sine.inOut"]] });

// 5 · DARK · freshers: the toggle is switched off, and the toggle itself grows into the hiring card
add({ id: "s5", theme: "dark", start: 18.6, tr: "zoom", zoomOut: 23.4,
  chunks: [["{Freshers} feel it", 18.8], ["{first}", 19.6]],
  html: (W) => blobs() + camWrap("s5-cam",
    morphBox("s5-m", 540, 930, 800, 600,
      `<div id="s5-track" style="position:absolute;inset:0;background:var(--accent)"></div>
       <div id="s5-knob" style="position:absolute;left:${400 + 150 - 75 - 60}px;top:${300 - 60}px;width:120px;height:120px;border-radius:50%;background:#fff;box-shadow:0 6px 18px rgba(0,0,0,.28)"></div>
       <div id="s5-card" style="position:absolute;inset:0;opacity:0">${ui("s5-ui", 800, 330, 2.42, 0, `<div class="ui-slab" style="box-shadow:none;background:transparent">
         <div class="ui-head"><span class="ui-title">TCS fresher hiring</span><span class="ui-label">per year</span></div>
         <div class="ui-figrow">${roll("s5-n", "40,000", "25,000")}<span class="ui-unit">graduates</span></div>
         ${bars("s5-b", [["Recent years", "40,000+"], ["FY27 plan", "~25,000"]])}
         <div class="ui-hair"></div><div class="ui-sub">IANS · CNBC, Apr 2026</div></div>`)}</div>`, "#2b2b2b", 0) +
    `<div style="position:absolute;left:0;top:0;width:1080px;height:1920px">${bigCursor("s5-cur")}</div>`),
  beats: [["cam", "#s5-cam", 18.6, 4.8, { scale: 1.08 }, { scale: 1 }],
    ["morph", "#s5-m", 18.9, 0.5, [12, 12, 6], [300, 150, 75]],
    ["press", "#s5-cur", 19.9, 780, 1200, 635, 975, "#s5-m"],
    ["cam", "#s5-knob", 19.9, 0.3, { x: 0 }, { x: -150 }, "expo.out"], ["cam", "#s5-track", 19.9, 0.3, { opacity: 1 }, { opacity: 0 }, "power2.out"],
    ["morph", "#s5-m", 20.5, 0.65, [300, 150, 75], [800, 600, 44], "expo.out"],
    ["cam", "#s5-knob", 20.45, 0.18, { opacity: 1, scale: 1 }, { opacity: 0, scale: 0.6 }, "power2.in"],
    ["cam", "#s5-card", 20.85, 0.4, { opacity: 0, y: 14 }, { opacity: 1, y: 0 }, "expo.out"],
    ["grow", "#s5-b", 21.0, [100, 62.5]], ["roll", "#s5-n", 21.6, false]] });

// 6 · DARK→ stair cascade: each task seeds as a brand square, stretches into a bar, the text wipes in, the check stamps
add({ id: "s6", theme: "light", start: 23.4, tr: "zoom", zoomOut: 28.2,
  chunks: [["AI now does", 23.6], ["the {junior work}", 24.4]],
  html: (W) => blobs() + camWrap("s6-cam",
    stairItem("s6-i0", 110, 700, 70, "Write the tests") + stairItem("s6-i1", 170, 830, 70, "Fix routine bugs") +
    stairItem("s6-i2", 230, 960, 70, "Draft the docs") + stairItem("s6-i3", 290, 1090, 70, "Triage tickets") +
    spellWord("s6-ill", "Illustrative", 28, 1240, 500, "color:#73726d;letter-spacing:0.04em")),
  beats: [["cam", "#s6-cam", 23.4, 4.8, { y: 90, scale: 1.04 }, { y: -40, scale: 1 }, "power1.inOut"],
    ["stair", "#s6-i0", 24.9], ["unhl", "#s6-i0", 25.5], ["stair", "#s6-i1", 25.5], ["unhl", "#s6-i1", 26.1], ["stair", "#s6-i2", 26.1], ["unhl", "#s6-i2", 26.7], ["stair", "#s6-i3", 26.7], ["spell", "#s6-ill", 27.2, 0.02, 8]] });

// 7 · DARK · the sector still grew — a hub card, connectors draw out, their end dots seed into tiles; the camera pans to follow
add({ id: "s7", theme: "dark", start: 28.2, tr: "wipe",
  chunks: [["But the sector", 28.4], ["{still grew}", 29.2]],
  html: (W) => blobs() + camWrap("s7-cam",
    uiAt("s7-ui", 60, 230, 2.0, 820, `<div class="ui-slab"><div class="ui-label">India tech workforce</div><div class="ui-figrow" style="margin:6px 0 4px">${roll("s7-n", "58.2", "59.5")}<span class="ui-unit">lakh</span></div><div class="ui-sub">Nasscom · FY26</div></div>`) +
    `<svg class="lines" width="1080" height="1920" viewBox="0 0 1080 1920">${[700, 940, 1180].map((y, i) => `<path id="s7-p${i}" class="ln" pathLength="1" d="M520 940 L600 940 L600 ${y} L660 ${y}"/>`).join("")}</svg>` +
    [["+1.35 lakh", "jobs added", "var(--ui-ok)"], ["+2.3%", "workforce growth", "var(--ui-ok)"], ["−7,389", "big five, net", "var(--ui-err)"]].map(([a, b, c], i) =>
      pillCard(`s7-t${i}`, 660, [700, 940, 1180][i] - 70, 380, 140, `<div style="height:100%;border-radius:28px;background:#2b2b2b;box-shadow:0 0 0 1.5px rgba(255,255,255,.1);display:flex;flex-direction:column;justify-content:center;padding:0 30px;font-family:Inter,sans-serif"><span style="font-size:52px;font-weight:600;letter-spacing:-0.03em;color:${c}">${a}</span><span style="font-size:26px;color:#8f8f8f">${b}</span></div>`, "border-radius:28px")).join("") +
    spellWord("s7-src", "As reported by IANS, Apr 2026", 28, 1330, 400, "color:#8f8f8f;letter-spacing:0")),
  beats: [["cam", "#s7-cam", 28.2, 4.4, { x: 70, scale: 1.04 }, { x: -20, scale: 1 }, "power1.inOut"],
    ["uin", "#s7-ui", 28.5], ["roll", "#s7-n", 29.4, true],
    ["draw", "#s7-p0", 29.9, 0.5], ["draw", "#s7-p1", 30.0, 0.5], ["draw", "#s7-p2", 30.1, 0.5],
    ["seed", "#s7-t0", 30.35, 0.6], ["seed", "#s7-t1", 30.5, 0.6], ["seed", "#s7-t2", 30.65, 0.6], ["spell", "#s7-src", 31.1, 0.01, 6]] });

// 8 · LIGHT · a list drives a card carousel: the active dot steps, the cards scroll to match
add({ id: "s8", theme: "light", start: 32.6, tr: "zoom", zoomOut: 37.6,
  chunks: [["{10–15 million} people", 32.8], ["built a {middle class}", 34.0], ["now {the warning}", 35.6]],
  html: (W) => blobs() + camWrap("s8-cam",
    `<div class="lg-list" id="s8-l" style="left:80px;top:760px;font-size:42px;font-family:Inter,sans-serif"><span class="lg-dot"></span><span class="lg-i">The people</span><span class="lg-i">The letter</span><span class="lg-i">The quote</span></div>` +
    `<div class="lg-view" style="left:420px;top:640px;width:600px;height:640px;-webkit-mask-image:linear-gradient(transparent,#000 14%,#000 86%,transparent);mask-image:linear-gradient(transparent,#000 14%,#000 86%,transparent)"><div class="lg-track" id="s8-tr">` +
    [["10–15 million", "people in IT services and BPO — the jobs that built India’s middle class"], ["Open letter", "Bernstein wrote to PM Modi warning of a deepening employment crisis"], ["“Gen AI now challenges that template”", "Bernstein, as reported by CNBC, Apr 2026"]].map(([a, b], i) =>
      `<div style="height:380px;margin:${i ? 60 : 130}px 20px 0;border-radius:32px;background:#fff;box-shadow:0 0 0 1.5px rgba(23,24,26,.08),0 40px 80px -40px rgba(20,30,40,.25);padding:44px 40px;display:flex;flex-direction:column;justify-content:center;gap:18px;font-family:Inter,sans-serif"><span style="font-size:${i === 2 ? 44 : 64}px;font-weight:600;letter-spacing:-0.03em;color:#17181a;line-height:1.08">${a}</span><span style="font-size:28px;line-height:1.35;color:#73726d">${b}</span></div>`).join("") +
    `</div></div>`),
  beats: [["cam", "#s8-cam", 32.6, 5.0, { scale: 1.05 }, { scale: 1 }],
    ["uin", "#s8-l", 33.0], ["listgo", "#s8-l", 33.0, 0, 0, "#s8-tr", 440], ["listgo", "#s8-l", 34.8, 0, 1, "#s8-tr", 440], ["listgo", "#s8-l", 36.2, 1, 2, "#s8-tr", 440]] });

// 9 · LIGHT · the takeaway, typed; three steps seed in
add({ id: "s9", theme: "light", start: 37.6, tr: "zoom", zoomOut: 41.6,
  chunks: [],
  html: (W) => blobs() + camWrap("s9-cam",
    typeLine("s9-l1", "Build {with AI,}", 112, 470) + typeLine("s9-l2", "not against it.", 112, 600) +
    ["Ship one project with AI tools", "Go deep in one domain", "Learn to review AI’s output"].map((t, i) =>
      pillCard(`s9-p${i}`, 140, 830 + i * 130, 800, 100, `<div style="height:100%;border-radius:50px;background:#fff;box-shadow:0 0 0 1.5px rgba(23,24,26,.08);display:flex;align-items:center;gap:22px;padding:0 34px;font:500 36px Inter,sans-serif;color:#17181a;letter-spacing:-0.01em"><span style="width:44px;height:44px;border-radius:12px;background:var(--accent);color:#fff;display:grid;place-items:center">${glyph(G.check, 24)}</span>${t}</div>`, "border-radius:50px")).join("")),
  beats: [["cam", "#s9-cam", 37.6, 4.0, { scale: 1.1 }, { scale: 1 }, "power1.out"],
    ["type", "#s9-l1", 37.75, 22, -1], ["type", "#s9-l2", 38.55, 22, 1.2],
    ["seed", "#s9-p0", 39.6, 0.55], ["seed", "#s9-p1", 40.1, 0.55], ["seed", "#s9-p2", 40.6, 0.55]] });

// 10 · DARK · CTA — the line resolves over a brand swell; a pill seeds with rings; the cursor clicks it
add({ id: "s10", theme: "dark", start: 41.6, tr: "zoom",
  chunks: [],
  html: (W) => blobs() + `<div class="swell" id="s10-sw"></div>` + camWrap("s10-cam",
    spellWord("s10-a", "Is your job {next?}", 110, 560, 500, "color:#fff") +
    morphBox("s10-m", 540, 900, 640, 150, spellWord("s10-b", "Comment below", 52, "rel", 600, "position:absolute;inset:0;align-items:center"), "#2b2b2b", 3, 34) +
    `<div style="position:absolute;left:0;top:0;width:1080px;height:1920px">${bigCursor("s10-cur")}</div>`),
  beats: [["swell", "#s10-sw", 41.7, 1.4], ["cam", "#s10-cam", 41.6, 3.4, { scale: 1.08 }, { scale: 1 }],
    ["spell", "#s10-a", 41.8, 0.035, 20],
    ["morph", "#s10-m", 42.6, 0.6, [12, 12, 6], [600, 130, 65]], ["spell", "#s10-b", 42.85, 0.025, 12],
    ["press", "#s10-cur", 43.6, 820, 1180, 700, 935, "#s10-m"], ["lit", "#s10-m", 43.6]] });

// ---------- sound: viral-style SFX, one per visible action ----------
const SFX = [
  ["boom", -0.033, 0.55], ["typing", 0.12, 0.42], ["swoosh", 0.55, 0.4], ["typing", 0.85, 0.42], ["whoosh", 1.0, 0.32],
  ["pop", 4.65, 0.5], ["whoosh", 5.7, 0.38], ["ding", 6.9, 0.38],
  ["swoosh", 9.0, 0.42], ["shutter", 9.4, 0.45], ["scratch", 10.6, 0.55], ["hit", 11.4, 0.55],
  ["swoosh", 13.6, 0.42], ["pop", 15.4, 0.5], ["hit", 16.45, 0.5],
  ["whoosh", 18.6, 0.38], ["pop", 18.9, 0.45], ["key", 19.9, 0.5], ["swoosh", 20.5, 0.42], ["ping", 21.65, 0.4],
  ["glitch", 23.45, 0.3], ["key", 25.1, 0.45], ["key", 25.7, 0.45], ["key", 26.3, 0.45], ["key", 26.9, 0.45],
  ["swoosh", 28.2, 0.42], ["ping", 29.45, 0.38], ["whoosh", 29.9, 0.3], ["ding", 30.65, 0.36],
  ["whoosh", 32.6, 0.38], ["ding", 34.8, 0.36], ["ding", 36.2, 0.36],
  ["typing", 37.75, 0.42], ["typing", 38.55, 0.42], ["pop", 39.6, 0.45], ["pop", 40.1, 0.45], ["riser", 39.41, 0.45], ["pop", 40.6, 0.45],
  ["boom", 41.6, 0.6], ["pop", 42.6, 0.45], ["key", 43.6, 0.5], ["ding", 43.65, 0.36],
];

// ---------- assemble ----------
const DUR = Object.fromEntries(fs.readdirSync("assets/fx").map((n) => [n.replace(".wav", ""), 0]));
function timeWords(text, t0) {
  if (t0 < 0) return text.replace(/[{}]/g, "").split(" ").map(() => -1);
  let prev = t0 - 0.22;
  return text.replace(/[{}]/g, "").split(" ").map(() => (prev += 0.22));
}
const chunkSpec = [];
function chunksHtml(s, W) {
  if (!s.chunks.length) return "";
  let html = `<div class="chunks" style="width:${W}px">`;
  s.chunks.forEach(([text, t0], ci) => {
    const times = timeWords(text, t0);
    let wi = 0, inMark = false, markIdx = 0;
    const plain = text.replace(/[{}]/g, "");
    const size = plain.length > 24 ? 84 : plain.length > 16 ? 96 : 112; // 9:16 has the height: one step bigger than v2
    const cid = `${s.id}-k${ci}`;
    let inner = "";
    for (const tok of text.split(" ")) {
      const open = tok.startsWith("{"), close = /}[,.?!]?$/.test(tok);
      let w = tok;
      if (open) { inMark = true; inner += `<span class="mk" id="${cid}-m${markIdx++}">`; w = w.slice(1); }
      const trail = w.match(/}(.*)$/);
      const core = w.replace(/}.*$/, "");
      inner += `<span class="w${inMark ? " on" : ""}" data-t="${times[wi].toFixed(2)}">${core}</span>`;
      if (close && inMark) { inner += `</span>`; inMark = false; if (trail && trail[1]) inner += `<span class="w" data-t="${times[wi].toFixed(2)}">${trail[1]}</span>`; }
      wi++;
    }
    html += `<div class="chunk" id="${cid}" style="font-size:${size}px">${inner}</div>`;
    const next = s.chunks[ci + 1];
    chunkSpec.push({ sel: "#" + cid, leave: next ? timeWords(next[0], next[1])[0] : null });
  });
  return html + "</div>";
}

const screenSpec = [];
let screens = "";
S.forEach((s, i) => {
  const W = 1080;
  const next = S[i + 1];
  s.end = next ? (next.cut ? next.start : next.start + 0.5) : END;
  screens += `<div class="scr ${s.theme}" id="${s.id}" style="width:${W}px"><div class="push" id="${s.id}-push" style="transform-origin:540px 960px">
    <div class="frame"><i class="c tl"></i><i class="c tr"></i><i class="c bl"></i><i class="c br"></i></div>
    ${chunksHtml(s, W)}${s.html(W)}</div></div>\n`;
  screenSpec.push({ id: s.id, start: s.start, end: s.end, cut: !!s.cut, theme: s.theme, beats: s.beats });
});

// one <audio> per hit; slot = the trimmed file's own length
import { execFileSync } from "node:child_process";
const len = (n) => (DUR[n] ||= parseFloat(execFileSync("/Users/saurabhshrimali/bin/ffprobe", ["-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", `assets/fx/${n}.wav`]).toString()));
const laneEnd = []; // greedy lanes so no two sounds overlap on one track
const audio = SFX.slice().sort((a, b) => a[1] - b[1]).map(([n, t, v], i) => {
  const start = +(t + 0.033).toFixed(3), d = Math.min(len(n), END - start - 0.01);
  let lane = laneEnd.findIndex((e) => e <= start); if (lane < 0) lane = laneEnd.length; laneEnd[lane] = start + d + 0.01;
  return `      <audio id="sfx-${String(i + 1).padStart(2, "0")}-${n}" class="clip" src="assets/fx/${n}.wav" data-start="${start}" data-duration="${d.toFixed(3)}" data-track-index="${5 + lane}" data-volume="${v}"></audio>`;
}).join("\n");

const tpl = fs.readFileSync("template.tmpl", "utf8");
const out = tpl
  .replace("__TITLE__", TITLE)
  .replace("__RES__", "portrait").replaceAll("__W__", "1080").replaceAll("__H__", "1920").replaceAll("__PH__", "1920")
  .replace("__CT__", "230").replace("__CHH__", "400").replace("__ACCENT__", ACCENT)
  .replace("__MEDIA__", '      <div id="bgfill" style="position:absolute;inset:0;background:#000"></div>')
  .replaceAll("__END__", String(END))
  .replace("__SCREENS__", screens)
  .replace("__CAPS__", "")
  .replace("__TAG__", "")
  .replace("__AUDIO__", audio)
  .replace("__DATA__", JSON.stringify({ END, SPLIT_IN: 0, WIDEN: null, TAG: null, screens: screenSpec, chunks: chunkSpec, caps: [] }));
fs.writeFileSync("index.html", out);
console.log("index.html written:", S.length, "screens,", chunkSpec.length, "chunks,", SFX.length, "sound hits");
