---
name: editing-style-1-v3
description: 'Editing Style 1 v3 — the approved 16:9 Instagram split-panel edit (Editing Style 1 v2, "Nikhil D1") with its objects rebuilt as interactive UI from interactive-ui-reels (bencho.dev style). Use whenever the person says Editing Style 1, Style 1 v3, v2, "the Nikhil style", "split panel with UI", or gives a finished 16:9 cut (podcast clip full screen, then their face on the right with the left half black) and asks to explain it with visuals, keep the text very big, or "do it like last time"; also to storyboard a topic in this style. Overlay only: the cut''s picture and audio stay untouched. Bottom subtitles over full-screen footage; in the split, the black left panel fills with short screens that alternate dark (grid) and light (paper), with a wipe between takeaways, big 2–4-word captions with bold-only key words, newspaper clippings of verified facts, and every number, comparison and list shown as a UI component that does something on the spoken word (rolling figures, meters, bars, segmented controls, toasts, checklists, a demo cursor). Key words are bold only — never highlighted.'
---

# Editing Style 1 v3 — big-text split panel (16:9) with interactive UI

**What came from where.** Everything about the edit — format, workflow, panel, grounds, frame, captions, subtitles, wipe and push, clippings, stamps, logos, icons, fact-checking, render and mux — is **Editing Style 1 v2**, approved on **Nikhil D1** ("Why do inference companies get such high multiples?", 2026-10-24: *"I really like this editing style… everything else is perfect."*). The **UI** — every object in the visual area, its look and its interactions — is **interactive-ui-reels** (studied from bencho.dev). Where the two disagreed, v2 wins for the edit and the UI skill wins for the objects (details: `references/ui.md`).

Files: `template.tmpl` (one page for **16:9 split panel or 9:16 full screen**: CSS + runtime with the v2, UI and SaaS-motion beat sets; fill `__W__ __H__ __PH__ __CT__ __CHH__ __RES__ __MEDIA__ __AUDIO__ __ACCENT__`), `example-build.mjs` (16:9 AI-layoffs storyboard), `examples/ai-layoffs-9x16-saas-build.mjs` (the 9:16 full-screen reel built entirely with the SaaS motion beats and viral SFX — start here for a vertical reel), `examples/nikhil-d1-v2-build.mjs` (the original approved v2 build, still compatible), `references/saas-motion.md` (the motion grammar), `references/ui.md` (UI tokens and components for the panel), `references/beats.md` (every beat), `tools/` (panel edge, transcription, optional UI sound renderer), `assets/` (fonts, icons, logos, optional sfx).

## The one rule from feedback: no highlighted words

**Never put a box, marker, pill or background behind a word** — not in the panel captions, not in the subtitles. The creator: "when you add highlights on the words, it just becomes too distracting visually." A key phrase in `{braces}` is only **bold** (white #fff on dark, black #000 on light). This rule also covers UI: a chip may invert to show selection, but never behind a caption word.

## What the person hands over

A finished 16:9 cut (1920×1080, 30 fps) with music already mixed. Typical layout:
- **Full screen** at the start: the person's own face, then the podcast clip they react to.
- **Split** for the rest: left half pure black, their face on the right (it may widen once, e.g. 1078 → 1109 px).

They say "don't edit the clip": keep every frame and the whole audio track. Only add visuals. **No UI sounds by default** — the cut's mix is final. Add them only if the person asks (`references/ui.md` §Sound).

For a **storyboard** (no cut yet): write the script as timed chunks, use a placeholder `media/source.mp4` (full-frame silhouette, then black-left split) and snapshot each screen at its settled moment (`example-build.mjs` writes `work/board.json` with one shot time per screen).

## Workflow

1. **Look.** `ffprobe`; contact sheet (`fps=1/3,scale=480:-1,tile=8x7`); find the split: `crop=960:1080:0:0,blackdetect=d=0.1:pix_th=0.06`. Then `python3 tools/panel_edge.py VIDEO <split_start>` for the panel width and the exact frame of every width change. The panel must cover the black exactly and switch width with a `tl.set` on that frame (`WIDEN`).
2. **Transcribe.** faster-whisper `small.en` with word times: `python3 -m venv .whisper-env && .whisper-env/bin/pip install faster-whisper`, then `.whisper-env/bin/python tools/transcribe.py audio16k.wav work/transcript.json` (`ffmpeg -ac 1 -ar 16000`). Fix misheard names on screen and tell the person.
3. **Beat sheet.** One screen per idea (5–12 s); ~20 screens for ~150 s of split. Alternate **dark / light** every screen. A hard cut (no wipe) only where the footage itself cuts. For each screen pick **one hero**: a UI component when there is a number, comparison, list, choice, event or process; a clipping when there is a reported fact; v2 cards/logos when the idea is "these companies / these things".
4. **Fact-check before any clipping or any number in a UI component** (WebSearch), and credit the outlet in the clipping's footer or the component's sub-line ("IANS, Apr 2026"). Invented examples carry an `Illustrative` tag.
5. **Build.** Project = `index.html` (generated), `build.mjs`, `template.tmpl` (not `.html`), `assets/` (copy `assets/fonts|icons|logos`), `media/source.mp4` (symlink to the cut), `work/transcript.json`. Copy `example-build.mjs` → `build.mjs`, keep the helpers, replace the screens, `CAPS`, `TAG`, `SPLIT_IN`, `WIDEN`, `END`, `TITLE`. `node build.mjs`.
6. **Check + look.** `npx hyperframes check` (0 errors; `line_unread` warnings on speech-timed text are expected; the type-floor warning on zoomed UI is a false alarm — the checker reads the pre-zoom size, so look instead). `snapshot --at` one time per screen into `work/snap`, read the contact sheets, fix overlaps and anything inside the 36 px frame, re-snapshot.
7. **Preview** in Studio, then **render the picture** and put the original audio back untouched:
   ```
   npx hyperframes render --quality delivery -o renders/picture.mp4 .
   ffmpeg -i renders/picture.mp4 -i <cut>.mp4 -map 0:v:0 -map 1:a:0 -c:v copy -c:a copy -shortest -movflags +faststart <cut>-edited.mp4
   ```
   Then check the frame pairs at every layout change.

## The look

**Panel** (x 0 → panel width, 1080 tall), inside a thin frame inset 36 px with 4 px corner brackets.
- **Dark screen**: #202020, 54 px grid lines rgba(255,255,255,.035), soft white glow; caption text #ececec, words start #707070.
- **Light screen**: #f2f2ef, 32 px dot grid #d9d9d5, white pool; ink #18181a, words start #b4b4b8.
- **Captions in the panel**: one chunk of **2–4 words** at a time, centred in a band at top 96–346; **92 px** (≤16 chars), 80 px (≤24), 70 px (longer); Helvetica Now Display Regular, key words Bold. Words rise as they're said; the chunk leaves (fade + 18 px up, 0.14 s) just before the next chunk's first word.
- **Visual area** y ≈ 380–1010, x 36–1044: **UI components** (one slab per screen, presented with `zoom` 2.0–2.6 so the web-size proportions hold), plus v2 editorial objects: clippings, stamps, slots, fences, arrows drawn with `pathLength=1`, big type.
- **UI on the panel** (`references/ui.md`): slab #2b2b2b on dark / #fff on light, 1 px hairline, **no glow and no drop shadow**; Inter 400/500 inside the UI, sentence case, tabular figures; selected = inverted to the ink (white slab + black on dark, ink slab + white on light). v2 `card`, `chip`, `badge`, `layer`, `tile`, `step` keep their helpers but now render in these tokens.
- **Subtitles over full-screen footage**: Helvetica Now Display Bold **60 px**, white on a dark pill rgba(12,12,12,.8), centred, bottom 70 px, one sentence-chunk at a time, no highlighted words. A name tag (bold name + small uppercase role) when a known guest first speaks (`TAG`).

## Visual vocabulary

- **UI patterns** (new): stat slab with a rolling or counting figure + meter sliver; segmented control flipped by the demo cursor (FY25 → FY26, AI → Skills); two-bar comparisons that land short; toast stacks for a chain of events; checklists for steps/takeaways; an island for "up next"; chips that invert on their word. One state change per beat, on the spoken word.
- **Logos** (monochrome, `currentColor`): Simple Icons (`cdn.jsdelivr.net/npm/simple-icons@13.21.0/icons/<slug>.svg`), else Lobe Icons (`@lobehub/icons-static-svg@1.40.0/icons/<slug>.svg`) for AI brands; IBM only in `simple-icons@9.0.0`. Already in `assets/logos`: linux, redhat, ibm, google, openai, anthropic, meta, deepseek, gemma, googlegemini, groq, grok, oracle, x, nvidia.
- **Icons**: Lucide (`lucide-static@0.460.0/icons/<name>.svg`), inlined with stroke 1.6 at large sizes (2.2–2.6 inside small UI). 43 already in `assets/icons`.
- **Clippings**: cream paper (#fbf8f1), Playfair Display 900 headline, Source Serif kicker/date with a double rule, faux text lines, "As reported by <outlet>". **Real, checked facts only; no real masthead.** Drop in rotated (−3…+3°). Never overlapping a UI slab.
- v2 patterns still available: A → B cards with an arrow lighting in turn; dashed slots that logos pop into; fence + lock; counters; shrinking cost bars + filling stars; numbered steps; stamps; a 4×3 tile grid where only 2 survive; CTA cards.
- Exactly one thing lit at a time per screen, except a final payoff.

## Motion

**Default motion is the SaaS explainer grammar in `references/saas-motion.md`** (learned frame by frame from the creator's reference explainers): five acts (hook → reveal → features → result → CTA); a camera that never stops (push / pull / drift / 3D-tilted screens that flatten to read / pans that follow new content); typed hooks with an accent wake; letters that resolve out of blur; morphs that keep one container alive (dot → circle → pill → card with following rings, toggle → card, thumbnail → card, shared-element flights); cards that fly in with depth blur; stair cascades; list-driven carousels; soft accent blobs; zoom-through cuts. Build every scene from those beats first, then add the v2 editorial pieces (clippings, stamps, captions).

One paused GSAP timeline `window.__timelines["main"]`, built after `document.fonts.ready`; CustomEase registered for the UI eases (`settle .22,1,.36,1`, `pop .24,1.34,.38,1`, `digit .34,1.45,.64,1`, `glide .65,0,.2,1`, `cursor .33,.55,.2,1`, `drain .55,0,.75,.4`).
- **Edit motion (v2)**: panel and screens start hidden in **CSS**; screen in = `clipPath inset(0 0 0 100%) → inset(0 0 0 0%)`, 0.5 s `expo.inOut`, ~0.4 s before its first word; previous screen hidden when covered; each screen pushes 1 → 1.03 `sine.inOut` for its whole life; captions rise 26 px `power3.out`.
- **UI motion (interactive-ui-reels)**: objects arrive by rising a hair out of a 3 px blur and landing a touch past their mark (`pop`/`uin`); selection inverts in 0.16 s with a 4–5 % pulse; digits roll left → right 70 ms apart (from below when growing); bars fill on `settle` 60 ms apart; a press is a visible cursor travelling 0.55 s, pressing (scale .86), and the state changes on release.
- Beats: `[type, selector, t, ...args]`, listed in `references/beats.md`. Every element hidden before its beat starts hidden through the `fromTo` start values; later tweens on the same element use `immediateRender:false`.

## Gotchas

- Don't name a class `big` inside a card (`.big` is the absolute headline). `.num` is v2's big number; tabular UI figures use `.tab`.
- Clippings overlapping each other or a UI slab fail `check` (`content_overlap`); place them side by side.
- Keep chips, stamps and slabs inside the 36 px frame; the face starts right at the panel edge.
- Don't tween width/height/margin/padding on UI (the render stutters and lint fails): roll digits with `roll`, count with `count`, grow bars with `scaleX`, open the island with `clip-path`.
- Toast stacks: write the toasts oldest-first in the markup so the newest paints on top.
- Render ≈ real time. Mux with `-c:a copy` so the audio is bit-identical.
